################################################################
#                                                              #
# utilities                                                    #
#                                                              #
################################################################

package NLP::utilities;

use File::Spec;
use Time::HiRes qw(time);
use Time::Local;
use NLP::English;
use NLP::UTF8;

$utf8 = NLP::UTF8;
$englishPM = NLP::English;

%empty_ht = ();

use constant DEBUGGING => 0;

sub member {
   local($this,$elem,@array) = @_;

   my $a;
   if (defined($elem)) {
      foreach $a (@array) {
	 if (defined($a)) {
            return 1 if $elem eq $a;
	 } else {
	    $DB::single = 1; # debugger breakpoint
	    print STDERR "\nWarning: Undefined variable utilities::member::a\n";
	 }
      }
   } else {
      $DB::single = 1; # debugger breakpoint
      print STDERR "\nWarning: Undefined variable utilities::member::elem\n";
   }
   return 0;
}

sub dual_member {
   local($this,$elem1,$elem2,*array1,*array2) = @_;
   # returns 1 if there exists a position $n
   #   such that $elem1 occurs at position $n in @array1 
   #    and $elem2 occurs at same position $n in @array2

   return 0 unless defined($elem1) && defined($elem2);
   my $last_index = ($#array1 < $#array2) ? $#array1 : $#array2; #min
   my $a;
   my $b;
   foreach $i ((0 .. $last_index)) {
      return 1 if defined($a = $array1[$i]) && defined($b = $array2[$i]) && ($a eq $elem1) && ($b eq $elem2);
   }
   return 0;
}

sub sorted_list_equal {
   local($this,*list1,*list2) = @_;

   return 0 unless $#list1 == $#list2;
   foreach $i ((0 .. $#list1)) {
      return 0 unless $list1[$i] eq $list2[$i];
   }
   return 1;
}

sub trim {
   local($this, $s) = @_;

   $s =~ s/^\s*//;
   $s =~ s/\s*$//;
   $s =~ s/\s+/ /g;
   return $s;
}

sub trim2 {
   local($this, $s) = @_;

   $s =~ s/^\s*//;
   $s =~ s/\s*$//;
   return $s;
}

sub trim_left {
   local($this, $s) = @_;
   $s =~ s/^\s*//;
   return $s;
}

sub cap_member {
   local($this,$elem,@array) = @_;

   my $a;
   my $lc_elem = lc $elem;
   foreach $a (@array) {
      return $a if $lc_elem eq lc $a;
   }
   return "";
}

sub remove_elem {
   local($this,$elem,@array) = @_;

   return @array unless $this->member($elem, @array);
   @rm_list = ();
   foreach $a (@array) {
      push(@rm_list, $a) unless $elem eq $a;
   }
   return @rm_list;
}

sub intersect_p {
   local($this,*list1,*list2) = @_;

   foreach $elem1 (@list1) {
      if (defined($elem1)) {
         foreach $elem2 (@list2) {
	    if (defined($elem2)) {
	       return 1 if $elem1 eq $elem2;
	    } else {
	       $DB::single = 1; # debugger breakpoint
               print STDERR "\nWarning: Undefined variable utilities::intersect_p::elem2\n";
            }
         }
      } else {
	 $DB::single = 1; # debugger breakpoint
         print STDERR "\nWarning: Undefined variable utilities::intersect_p::elem1\n";
      }
   }
   return 0;
}

sub intersect_expl_p {
   local($this,*list1,@list2) = @_;

   foreach $elem1 (@list1) {
      foreach $elem2 (@list2) {
	 return 1 if $elem1 eq $elem2;
      }
   }
   return 0;
}

sub intersection {
   local($this,*list1,*list2) = @_;

   @intersection_list = ();
   foreach $elem1 (@list1) {
      foreach $elem2 (@list2) {
	 push(@intersection_list, $elem1) if ($elem1 eq $elem2) && ! $this->member($elem1, @intersection_list);
      }
   }
   return @intersection_list;
}

sub cap_intersect_p {
   local($this,*list1,*list2) = @_;

   foreach $elem1 (@list1) {
      $lc_elem1 = lc $elem1;
      foreach $elem2 (@list2) {
	 return 1 if $lc_elem1 eq lc $elem2;
      }
   }
   return 0;
}

sub subset_p {
   local($this,*list1,*list2) = @_;

   foreach $elem1 (@list1) {
      return 0 unless $this->member($elem1, @list2);
   }
   return 1;
}

sub cap_subset_p {
   local($this,*list1,*list2) = @_;

   foreach $elem1 (@list1) {
      return 0 unless $this->cap_member($elem1, @list2);
   }
   return 1;
}

sub unique {
   local($this, @list) = @_;

   my %seen = ();
   @uniq = ();
   foreach $item (@list) {
      push(@uniq, $item) unless $seen{$item}++;
   }
   return @uniq;
}

sub position {
   local($this,$elem,@array) = @_;
   $i = 0;
   foreach $a (@array) {
      return $i if $elem eq $a;
      $i++;
   }
   return -1;
}

sub positions {
   local($this,$elem,@array) = @_;
   $i = 0;
   @positions_in_list = ();
   foreach $a (@array) {
      push(@positions_in_list, $i) if $elem eq $a;
      $i++;
   }
   return @positions_in_list;
}

sub last_position {
   local($this,$elem,@array) = @_;

   $result = -1;
   $i = 0;
   foreach $a (@array) {
      $result = $i if $elem eq $a;
      $i++;
   }
   return $result;
}

sub rand_n_digit_number {
   local($this,$n) = @_;

   return 0 unless $n =~ /^[1-9]\d*$/;
   $ten_power_n = 10 ** ($n - 1);
   return int(rand(9 * $ten_power_n)) + $ten_power_n;
}

# Consider File::Temp
sub new_tmp_filename {
   local($this,$filename) = @_;

   $loop_limit = 1000;
   ($dir,$simple_filename) = ($filename =~ /^(.+)\/([^\/]+)$/);
   $simple_filename = $filename unless defined($simple_filename);
   $new_filename = "$dir/tmp-" . $this->rand_n_digit_number(8) . "-$simple_filename";
   while ((-e $new_filename) && ($loop_limit-- >= 0)) {
      $new_filename = "$dir/tmp-" . $this->rand_n_digit_number(8) . "-$simple_filename";
   }
   return $new_filename;
}

# support sorting order: "8", "8.0", "8.5", "8.5.1.", "8.10", "10", "10-12"

sub compare_complex_numeric {
   local($this,$a,$b) = @_;

   (my $a_num,my $a_rest) = ($a =~ /^(\d+)\D*(.*)$/);
   (my $b_num,my $b_rest) = ($b =~ /^(\d+)\D*(.*)$/);

   if (defined($a_rest) && defined($b_rest)) {
      return ($a_num <=> $b_num)
	  || $this->compare_complex_numeric($a_rest,$b_rest);
   } else {
      return $a cmp $b;
   }
}

# support sorting order: "lesson8-ps-v1.9.xml", "Lesson 10_ps-v_1.11.xml"
# approach: segment strings into alphabetic and numerical sections and compare pairwise

sub compare_mixed_alpha_numeric {
   local($this,$a,$b) = @_;

   ($a_alpha,$a_num,$a_rest) = ($a =~ /^(\D*)(\d[-\d\.]*)(.*)$/);
   ($b_alpha,$b_num,$b_rest) = ($b =~ /^(\D*)(\d[-\d\.]*)(.*)$/);

   ($a_alpha) = ($a =~ /^(\D*)/) unless defined $a_alpha;
   ($b_alpha) = ($b =~ /^(\D*)/) unless defined $b_alpha;

   # ignore non-alphabetic characters in alpha sections
   $a_alpha =~ s/\W|_//g;
   $b_alpha =~ s/\W|_//g;

   if ($alpha_cmp = lc $a_alpha cmp lc $b_alpha) {
      return $alpha_cmp;
   } elsif (defined($a_rest) && defined($b_rest)) {
      return $this->compare_complex_numeric($a_num,$b_num)
	  || $this->compare_mixed_alpha_numeric ($a_rest,$b_rest);
   } else {
      return (defined($a_num) <=> defined($b_num)) || ($a cmp $b);
   }
}

# @sorted_lessons = sort { NLP::utilities->compare_mixed_alpha_numeric($a,$b) } @lessons;

sub html_guarded_p {
   local($this,$string) = @_;

   return 0 if $string =~ /[<>"]/;
   $string .= " ";
   @segs = split('&',$string);
   shift @segs;
   foreach $seg (@segs) {
      next if $seg =~ /^[a-z]{2,6};/i;
    # next if $seg =~ /^amp;/;
    # next if $seg =~ /^quot;/;
    # next if $seg =~ /^nbsp;/;
    # next if $seg =~ /^gt;/;
    # next if $seg =~ /^lt;/;
      next if $seg =~ /^#(\d+);/;
      next if $seg =~ /^#x([0-9a-fA-F]+);/;
      return 0;
   }
   return 1;
}

sub guard_tooltip_text {
   local($this,$string) = @_;

   $string =~ s/\xCB\x88/'/g;
   return $string;
}

sub guard_html {
   local($this,$string,$control_string) = @_;

   return "" unless defined($string);
   my $guarded_string;
   $control_string = "" unless defined($control_string);
   return $string if ($string =~ /&/) 
		       && (! ($control_string =~ /\bstrict\b/))
		       && $this->html_guarded_p($string);
   $guarded_string = $string;
   $guarded_string =~ s/&/&amp;/g;
   if ($control_string =~ /slash quote/) {
      $guarded_string =~ s/"/\\"/g;
   } elsif ($control_string =~ /keep quote/) {
   } else {
      $guarded_string =~ s/\"/&quot;/g;
   }
   if ($control_string =~ /escape-slash/) {
      $guarded_string =~ s/\//&x2F;/g;
   }
   $guarded_string =~ s/>/&gt;/g;
   $guarded_string =~ s/</&lt;/g;
   return $guarded_string;
}

sub unguard_html {
   local($this,$string) = @_;

   return undef unless defined($string);
   $string=~ s[&(\S*?);]{
      local $_ = $1;
      /^amp$/i        ? "&" :
      /^quot$/i       ? '"' :
      /^apos$/i       ? "'" :
      /^gt$/i         ? ">" :
      /^lt$/i         ? "<" :
      /^x2F$/i        ? "/" :
      /^nbsp$/i       ? "\xC2\xA0" :
      /^#(\d+)$/      ? $this->chr($1) :
      /^#x([0-9a-f]+)$/i ? $this->chr(hex($1)) :
      $_
      }gex;
   return $string;
}

sub unguard_html_r {
   local($this,$string) = @_;

   return undef unless defined($string);

   $string =~ s/&amp;/&/g;
   $string =~ s/&quot;/'/g;
   $string =~ s/&lt;/</g;
   $string =~ s/&gt;/>/g;

   ($d) = ($string =~ /&#(\d+);/);
   while (defined($d)) {
      $c = $this->chr($d);
      $string =~ s/&#$d;/$c/g;
      ($d) = ($string =~ /&#(\d+);/);
   }
   ($x) = ($string =~ /&#x([0-9a-f]+);/i);
   while (defined($x)) {
      $c = $this->chr(hex($x));
      $string =~ s/&#x$x;/$c/g;
      ($x) = ($string =~ /&#x([0-9a-f]+);/i);
   }
   $string0 = $string;
   ($x) = ($string =~ /(?:https?|www|\.com)\S*\%([0-9a-f]{2,2})/i);
   while (defined($x)) {
      $c = $this->chr("%" . hex($x));
      $string =~ s/\%$x/$c/g;
      ($x) = ($string =~ /(?:https?|www|\.com)\S*\%([0-9a-f]{2,2})/i);
   }
   return $string;
}

sub unguard_html_l {
   local($caller,$string) = @_;

   return undef unless defined($string);

   my $pre;
   my $core;
   my $post;
   my $repl;
   my $s = $string;
   if (($pre,$core,$post) = ($s =~ /^(.*)&(amp|quot|lt|gt|#\d+|#x[0-9a-f]+);(.*)$/i)) {
      $repl = "?";
      $repl = "&" if $core =~ /^amp$/i;
      $repl = "'" if $core =~ /^quot$/i;
      $repl = "<" if $core =~ /^lt$/i;
      $repl = ">" if $core =~ /^gt$/i;
      if ($core =~ /^#\d+$/i) {
	 $core2 = substr($core,1);
         $repl = $caller->chr($core2);
      }
      $repl = $caller->chr(hex(substr($core,2))) if $core =~ /^#x[0-9a-f]+$/i;
      $s = $pre . $repl . $post;
   }
   return $s;
}

sub guard_html_quote {
   local($caller,$string) = @_;

   $string =~ s/"/&quot;/g;
   return $string;
}

sub unguard_html_quote {
   local($caller,$string) = @_;

   $string =~ s/&quot;/"/g;
   return $string;
}

sub uri_encode {
   local($caller,$string) = @_;

   $string =~ s/([^^A-Za-z0-9\-_.!~*()'])/ sprintf "%%%02x", ord $1 /eg;
   return $string;
}

sub uri_decode {
   local($caller,$string) = @_;

   $string =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/eg;
   return $string;
}

sub remove_xml_tags {
   local($caller,$string) = @_;

   $string =~ s/<\/?[a-zA-Z][-_:a-zA-Z0-9]*(\s+[a-zA-Z][-_:a-zA-Z0-9]*=\"[^"]*\")*\s*\/?>//g;
   return $string;
}

sub remove_any_tokenization_at_signs_around_xml_tags {
   local($caller,$string) = @_;

   $string =~ s/(?:\@ \@)?(<[^<>]+>)(?:\@ \@)?/$1/g;
   $string =~ s/\@?(<[^<>]+>)\@?/$1/g;
   return $string;
}

sub remove_xml_tags_and_any_bordering_at_signs {
   # at-signs from tokenization
   local($caller,$string) = @_;

   $string =~ s/\@?<\/?[a-zA-Z][-_:a-zA-Z0-9]*(\s+[a-zA-Z][-_:a-zA-Z0-9]*=\"[^"]*\")*\s*\/?>\@?//g;
   return $string;
}

sub chr {
   local($caller,$i) = @_;

   return undef unless $i =~ /^\%?\d+$/;
   if ($i =~ /^%/) {
      $i =~ s/^\%//;
      return chr($i)                                  if $i < 128;
      return "\x80" | chr($i - 128)                   if $i < 256;
   } else {
      return chr($i)                                  if $i < 128;
      return ("\xC0" | chr(($i / 64) % 32)) 
	   . ("\x80" | chr($i % 64))                  if $i < 2048;
      return ("\xE0" | chr(int($i / 4096) % 16)) 
	   . ("\x80" | chr(int($i / 64) % 64)) 
	   . ("\x80" | chr($i % 64))                  if $i < 65536;
      return ("\xF0" | chr(int($i / 262144) % 8)) 
	   . ("\x80" | chr(int($i / 4096) % 64)) 
	   . ("\x80" | chr(int($i / 64) % 64)) 
	   . ("\x80" | chr($i % 64))                  if $i < 2097152;
   }
   return "?";
}

sub guard_cgi {
   local($caller, $string) = @_;

   $guarded_string = $string;
   if ($string =~ /[\x80-\xFF]/) {
      $guarded_string = "";
      while ($string ne "") {
	 $char = substr($string, 0, 1);
         $string = substr($string, 1);
         if ($char =~ /^[\\ ;\#\&\:\=\"\'\+\?\x00-\x1F\x80-\xFF]$/) {
	    $hex = sprintf("%2.2x",ord($char));
	    $guarded_string .= uc "%$hex";
	 } else {
	    $guarded_string .= $char;
	 }
      }
   } else {
      $guarded_string = $string;
      $guarded_string =~ s/%/%25/g;
      $guarded_string =~ s/\n/%5Cn/g;
      $guarded_string =~ s/\t/%5Ct/g;
      $guarded_string =~ s/ /%20/g;
      $guarded_string =~ s/"/%22/g;
      $guarded_string =~ s/#/%23/g;
      $guarded_string =~ s/&/%26/g;
      $guarded_string =~ s/'/%27/g;
      $guarded_string =~ s/\+/%2B/g;
      $guarded_string =~ s/\//%2F/g;
      $guarded_string =~ s/:/%3A/g;
      $guarded_string =~ s/;/%3B/g;
      $guarded_string =~ s/</%3C/g;
      $guarded_string =~ s/=/%3D/g;
      $guarded_string =~ s/>/%3E/g;
      $guarded_string =~ s/\?/%3F/g;
   }
   return $guarded_string;
}

sub repair_cgi_guard {
   local($caller,$string) = @_;
   # undo second cgi-guard, e.g. "Jo%25C3%25ABlle_Aubron" -> "Jo%C3%ABlle_Aubron"

   $string =~ s/(%)25([CD][0-9A-F]%)25([89AB][0-9A-F])/$1$2$3/g;
   $string =~ s/(%)25(E[0-9A-F]%)25([89AB][0-9A-F]%)25([89AB][0-9A-F])/$1$2$3$4/g;
   return $string;
}

sub unguard_cgi {
   local($caller,$string) = @_;

   $unguarded_string = $string;
   $unguarded_string =~ s/%5Cn/\n/g;
   $unguarded_string =~ s/%5Ct/\t/g;
   $unguarded_string =~ s/%20/ /g;
   $unguarded_string =~ s/%23/#/g;
   $unguarded_string =~ s/%26/&/g;
   $unguarded_string =~ s/%2B/+/g;
   $unguarded_string =~ s/%2C/,/g;
   $unguarded_string =~ s/%3A/:/g;
   $unguarded_string =~ s/%3D/=/g;
   $unguarded_string =~ s/%3F/?/g;
   $unguarded_string =~ s/%C3%A9/\xC3\xA9/g;

   # more general
   ($code) = ($unguarded_string =~ /%([0-9A-F]{2,2})/);
   while (defined($code)) {
      $percent_code = "%" . $code;
      $hex_code = sprintf("%c", hex($code));
      $unguarded_string =~ s/$percent_code/$hex_code/g;
      ($code) = ($unguarded_string =~ /%([0-9A-F]{2,2})/);
   }

   return $unguarded_string;
}

sub regex_guard {
   local($caller,$string) = @_;

   $guarded_string = $string;
   $guarded_string =~ s/([\\\/\^\|\(\)\{\}\$\@\*\+\?\.\[\]])/\\$1/g
      if $guarded_string =~ /[\\\/\^\|\(\)\{\}\$\@\*\+\?\.\[\]]/;

   return $guarded_string;
}

sub g_regex_spec_tok_p {
   local($this,$string) = @_;

   # specials: ( ) (?: ) [ ]
   return ($string =~ /^(\(\?:|[()\[\]])$/);
}

sub regex_guard_norm {
   local($this,$string) = @_;

   return $string unless $string =~ /[\[\]\\()$@?+]/;
   my $rest = $string;
   my @stack = ("");
   while ($rest ne "") {
      # specials: ( ) (?: ) [ ] ? +
      if (($pre, $special, $post) = ($rest =~ /^((?:\\.|[^\[\]()?+])*)(\(\?:|[\[\]()?+])(.*)$/)) {
       # print STDERR "Special: $pre *$special* $post\n";
	 unless ($pre eq "") {
	    push(@stack, $pre);
	    while (($#stack >= 1) && (! $this->g_regex_spec_tok_p($stack[$#stack-1]))
	                          && (! $this->g_regex_spec_tok_p($stack[$#stack]))) {
	       $s1 = pop @stack;
	       $s2 = pop @stack;
	       push(@stack, "$s2$s1");
	    }
	 }
	 if ($special =~ /^[?+]$/) {
	    push(@stack, "\\") if ($stack[$#stack] eq "") 
	                       || ($this->g_regex_spec_tok_p($stack[$#stack]) && ($stack[$#stack] ne "["));
	    push(@stack, $special);
	 } elsif ($special eq "]") {
	    if (($#stack >= 1) && ($stack[$#stack-1] eq "[") && ! $this->g_regex_spec_tok_p($stack[$#stack])) {
	       $char_expression = pop @stack;
	       pop @stack;
	       push(@stack, "[$char_expression]");
	    } else {
	       push(@stack, $special);
	    }
	 } elsif (($special =~ /^[()]/) && (($stack[$#stack] eq "[")
	                                 || (($#stack >= 1)
				          && ($stack[$#stack-1] eq "[")
					  && ! $this->g_regex_spec_tok_p($stack[$#stack])))) {
	    push(@stack, "\\$special");
	 } elsif ($special eq ")") {
	    if (($#stack >= 1) && ($stack[$#stack-1] =~ /^\((\?:)?$/) && ! $this->g_regex_spec_tok_p($stack[$#stack])) {
	       $alt_expression = pop @stack;
	       $open_para = pop @stack;
	       if ($open_para eq "(") {
	          push(@stack, "(?:$alt_expression)");
	       } else {
	          push(@stack, "$open_para$alt_expression)");
	       }
	    } else {
	       push(@stack, $special);
	    }
	 } else {
	    push(@stack, $special);
	 }
	 while (($#stack >= 1) && (! $this->g_regex_spec_tok_p($stack[$#stack-1])) 
	                       && (! $this->g_regex_spec_tok_p($stack[$#stack]))) {
	    $s1 = pop @stack;
	    $s2 = pop @stack;
	    push(@stack, "$s2$s1");
	 }
	 $rest = $post;
      } else {
	 push(@stack, $rest);
	 $rest = "";
      }
   }
 # print STDERR "Stack: " . join(";", @stack) . "\n";
   foreach $i ((0 .. $#stack)) {
      $stack_elem = $stack[$i];
      if ($stack_elem =~ /^[()\[\]]$/) {
         $stack[$i] = "\\" . $stack[$i]; 
      }
   }
   return join("", @stack);
}

sub string_guard {
   local($caller,$string) = @_;

   return "" unless defined($string);
   $guarded_string = $string;
   $guarded_string =~ s/([\\"])/\\$1/g
      if $guarded_string =~ /[\\"]/;

   return $guarded_string;
}

sub guard_javascript_arg {
   local($caller,$string) = @_;

   return "" unless defined($string);
   $guarded_string = $string;
   $guarded_string =~ s/\\/\\\\/g;
   $guarded_string =~ s/'/\\'/g;
   return $guarded_string;
}

sub guard_substitution_right_hand_side {
   # "$1x" => "$1 . \"x\""
   local($caller,$string) = @_;

   my $result = "";
   ($pre,$var,$post) = ($string =~ /^([^\$]*)(\$\d)(.*)$/);
   while (defined($var)) {
      $result .= " . " if $result;
      $result .= "\"$pre\" . " unless $pre eq "";
      $result .= $var;
      $string = $post;
      ($pre,$var,$post) = ($string =~ /^([^\$]*)(\$\d)(.*)$/);
   }
   $result .= " . \"$string\"" if $string;
   return $result;
}

sub string_starts_with_substring {
   local($caller,$string,$substring) = @_;

   $guarded_substring = $caller->regex_guard($substring);
   return $string =~ /^$guarded_substring/;
}

sub one_string_starts_with_the_other {
   local($caller,$s1,$s2) = @_;

   return ($s1 eq $s2)
       || $caller->string_starts_with_substring($s1,$s2)
       || $caller->string_starts_with_substring($s2,$s1);
}

sub string_ends_in_substring {
   local($caller,$string,$substring) = @_;

   $guarded_substring = $caller->regex_guard($substring);
   return $string =~ /$guarded_substring$/;
}

sub string_equal_ignore_leading_multiple_or_trailing_blanks {
   local($caller,$string1,$string2) = @_;

   return 1 if $string1 eq $string2;
   $string1 =~ s/\s+/ /;
   $string2 =~ s/\s+/ /;
   $string1 =~ s/^\s+//;
   $string2 =~ s/^\s+//;
   $string1 =~ s/\s+$//;
   $string2 =~ s/\s+$//;

   return $string1 eq $string2;
}

sub strip_substring_from_start_of_string {
   local($caller,$string,$substring,$error_code) = @_;

   $error_code = "ERROR" unless defined($error_code);
   my $reg_surf = $caller->regex_guard($substring);
   if ($string =~ /^$guarded_substring/) {
      $string =~ s/^$reg_surf//;
      return $string;
   } else {
      return $error_code;
   }
}

sub strip_substring_from_end_of_string {
   local($caller,$string,$substring,$error_code) = @_;

   $error_code = "ERROR" unless defined($error_code);
   my $reg_surf = $caller->regex_guard($substring);
   if ($string =~ /$reg_surf$/) {
      $string =~ s/$reg_surf$//;
      return $string;
   } else {
      return $error_code;
   }
}

# to be deprecated
sub lang_code {
   local($caller,$language) = @_;

   $langPM = NLP::Language->new();
   return $langPM->lang_code($language);
}

sub full_language {
   local($caller,$lang_code) = @_;

   return "Arabic"       if $lang_code eq "ar";
   return "Chinese"      if $lang_code eq "zh";
   return "Czech"        if $lang_code eq "cs";
   return "Danish"       if $lang_code eq "da";
   return "Dutch"        if $lang_code eq "nl";
   return "English"      if $lang_code eq "en";
   return "Finnish"      if $lang_code eq "fi";
   return "French"       if $lang_code eq "fr";
   return "German"       if $lang_code eq "de";
   return "Greek"        if $lang_code eq "el";
   return "Hebrew"       if $lang_code eq "he";
   return "Hindi"        if $lang_code eq "hi";
   return "Hungarian"    if $lang_code eq "hu";
   return "Icelandic"    if $lang_code eq "is";
   return "Indonesian"   if $lang_code eq "id";
   return "Italian"      if $lang_code eq "it";
   return "Japanese"     if $lang_code eq "ja";
   return "Kinyarwanda"  if $lang_code eq "rw";
   return "Korean"       if $lang_code eq "ko";
   return "Latin"        if $lang_code eq "la";
   return "Malagasy"     if $lang_code eq "mg";
   return "Norwegian"    if $lang_code eq "no";
   return "Pashto"       if $lang_code eq "ps";
   return "Persian"      if $lang_code eq "fa";
   return "Polish"       if $lang_code eq "pl";
   return "Portuguese"   if $lang_code eq "pt";
   return "Romanian"     if $lang_code eq "ro";
   return "Russian"      if $lang_code eq "ru";
   return "Spanish"      if $lang_code eq "es";
   return "Swedish"      if $lang_code eq "sv";
   return "Turkish"      if $lang_code eq "tr";
   return "Urdu"         if $lang_code eq "ur";
   return "";
}

# to be deprecated
sub short_lang_name {
   local($caller,$lang_code) = @_;

   $langPM = NLP::Language->new();
   return $langPM->shortname($lang_code);
}

sub ml_dir {
   local($caller,$language,$type) = @_;

   $type = "MSB" unless defined($type);
   $lang_code = $langPM->lang_code($language);
   return $caller->ml_dir($lang_code, "lex") . "/corpora" if $type eq "corpora";
   return "" unless defined($rc);
   $ml_home = $rc->ml_home_dir();
   return File::Spec->catfile($ml_home, "arabic")
      if ($lang_code eq "ar-iq") && ! $caller->member(lc $type,"lex","onto","dict");
   $langPM = NLP::Language->new();
   $lexdir = $langPM->lexdir($lang_code);
   return $lexdir if defined($lexdir);
   return "";
}

sub language_lex_filename {
   local($caller,$language,$type) = @_;

   $langPM = NLP::Language->new();
   if (($lang_code = $langPM->lang_code($language))
    && ($ml_dir = $caller->ml_dir($lang_code,$type))
    && ($norm_language = $caller->short_lang_name($lang_code))) {
      return "$ml_dir/$norm_language-lex" if ($type eq "lex");
      return "$ml_dir/onto" if ($type eq "onto");
      return "$ml_dir/$norm_language-english-dict" if ($type eq "dict") && !($lang_code eq "en");
      return "";
   } else {
      return "";
   }
}

# filename_without_path is obsolete - replace with
#   use File::Basename;
#   basename($filename)
sub filename_without_path {
   local($caller,$filename) = @_;

   $filename =~ s/^.*\/([^\/]+)$/$1/;
   return $filename;
}

sub option_string {
   local($caller,$input_name,$default,*values,*labels) = @_;

   my $s = "<select id=\"$input_name\" name=\"$input_name\" size=\"1\">";
   for $i (0 .. $#values) {
     my $value = $values[$i];
     my $label = $labels[$i];
     my $selected_clause = ($default eq $value) ? "selected" : "";
     $s .= "<option $selected_clause value=\"$value\">$label</option>";
   }
   $s .= "</select>";
   return $s;
}

sub pes_subseq_surf {
   local($this,$start,$length,$langCode,@pes) = @_;

   my $surf = "";
   if ($start+$length-1 <= $#pes) {
      foreach $i ($start .. $start + $length - 1) {
	 my $pe = $pes[$i];
	 $surf .= $pe->get("surf","");
	 $surf .= " " if $langCode =~ /^(ar|en|fr)$/;
      }
   }
   $surf =~ s/\s+$//;
   return $surf;
}

sub copyList {
   local($this,@list) = @_;

   @copy_list = ();
   foreach $elem (@list) {
      push(@copy_list,$elem);
   }
   return @copy_list;
}

sub list_with_same_elem {
   local($this,$size,$elem) = @_;

   @list = ();
   foreach $i (0 .. $size-1) {
      push(@list,$elem);
   }
   return @list;
}

sub count_occurrences {
   local($this,$s,$substring) = @_;

   $occ = 0;
   $new = $s;
   $guarded_substring = $this->regex_guard($substring);
   $new =~ s/$guarded_substring//;
   while ($new ne $s) {
      $occ++;
      $s = $new;
      $new =~ s/$guarded_substring//;
   }
   return $occ;
}

sub position_of_nth_occurrence {
   local($this,$s,$substring,$occ) = @_;

   return -1 unless $occ > 0;
   my $pos = 0;
   while (($pos = index($s, $substring, $pos)) >= 0) {
      return $pos if $occ == 1;
      $occ--;
      $pos = $pos + length($substring);
   }
   return -1;
}

sub has_diff_elements_p {
   local($this,@array) = @_;

   return 0 if $#array < 1;
   $elem = $array[0];

   foreach $a (@array) {
      return 1 if $elem ne $a;
   }
   return 0;
}

sub init_log {
   local($this,$logfile, $control) = @_;

   $control = "" unless defined($control);
   if ((DEBUGGING || ($control =~ /debug/i)) && $logfile) {
      system("rm -f $logfile");
      system("date > $logfile; chmod 777 $logfile");
   }
}

sub time_stamp_log {
   local($this,$logfile, $control) = @_;

   $control = "" unless defined($control);
   if ((DEBUGGING || ($control =~ /debug/i)) && $logfile) {
      system("date >> $logfile; chmod 777 $logfile");
   }
}

sub log {
   local($this,$message,$logfile,$control) = @_;

   $control = "" unless defined($control);
   if ((DEBUGGING || ($control =~ /debug/i)) && $logfile) {
      $this->init_log($logfile, $control) unless -w $logfile;
      if ($control =~ /timestamp/i) {
	 $this->time_stamp_log($logfile, $control);
      }
      $guarded_message = $message;
      $guarded_message =~ s/"/\\"/g;
      system("echo \"$guarded_message\" >> $logfile");
   }
}

sub month_name_to_month_number {
   local($this,$month_name) = @_;

   $month_name_init = lc substr($month_name,0,3);
   return $this->position($month_name_init, "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec") + 1;
}

my @short_month_names = ("Jan.","Febr.","March","April","May","June","July","Aug.","Sept.","Oct.","Nov.","Dec.");
my @full_month_names = ("January","February","March","April","May","June","July","August","September","October","November","December");

sub month_number_to_month_name {
   local($this,$month_number, $control) = @_;

   $month_number =~ s/^0//;
   if ($month_number =~ /^([1-9]|1[0-2])$/) {
      return ($control && ($control =~ /short/i))
	 ? $short_month_names[$month_number-1]
	 : $full_month_names[$month_number-1];
   } else {
      return "";
   }
}

sub leap_year {
   local($this,$year) = @_;

   return 0 if $year %   4 != 0;
   return 1 if $year % 400 == 0;
   return 0 if $year % 100 == 0;
   return 1;
}

sub datetime {
   local($this,$format,$time_in_secs, $command) = @_;

   $command = "" unless defined($command);
   $time_in_secs = time unless defined($time_in_secs) && $time_in_secs;
   @time_vector = ($command =~ /\b(gm|utc)\b/i) ? gmtime($time_in_secs) : localtime($time_in_secs);
   ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=@time_vector;
   $thisyear = $year + 1900;
   $thismon=(Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec)[$mon];
   $thismon2=("Jan.","Febr.","March","April","May","June","July","Aug.","Sept.","Oct.","Nov.","Dec.")[$mon];
   $thismonth = $mon + 1;
   $thisday=(Sun,Mon,Tue,Wed,Thu,Fri,Sat)[$wday];
   $milliseconds = int(($time_in_secs - int($time_in_secs)) * 1000);
   $date="$thisday $thismon $mday, $thisyear";
   $sdate="$thismon $mday, $thisyear";
   $dashedDate = sprintf("%04d-%02d-%02d",$thisyear,$thismonth,$mday);
   $slashedDate = sprintf("%02d/%02d/%04d",$mday,$thismonth,$thisyear);
   $time=sprintf("%02d:%02d:%02d",$hour,$min,$sec);
   $shorttime=sprintf("%d:%02d",$hour,$min);
   $shortdatetime = "$thismon2 $mday, $shorttime";

   if ($date =~ /undefined/) {
      return "";
   } elsif ($format eq "date at time") {
      return "$date at $time";
   } elsif ($format eq "date") {
      return "$date";
   } elsif ($format eq "sdate") {
      return "$sdate";
   } elsif ($format eq "ddate") {
      return "$dashedDate";
   } elsif ($format eq "time") {
      return "$time";
   } elsif ($format eq "dateTtime+ms") {
      return $dashedDate . "T" . $time . "." . $milliseconds;
   } elsif ($format eq "dateTtime") {
      return $dashedDate . "T" . $time;
   } elsif ($format eq "yyyymmdd") {
      return sprintf("%04d%02d%02d",$thisyear,$thismonth,$mday);
   } elsif ($format eq "short date at time") {
      return $shortdatetime;
   } else {
      return "$date at $time";
   }
}

sub datetime_of_last_file_modification {
   local($this,$format,$filename) = @_;
 
   return $this->datetime($format,(stat($filename))[9]);
}

sub add_1sec {
   local($this,$datetime) = @_;

   if (($year,$month,$day,$hour,$minute,$second) = ($datetime =~ /^(\d\d\d\d)-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)$/)) {
      $second++;
      if ($second >= 60) { $second -= 60; $minute++; }
      if ($minute >= 60) { $minute -= 60; $hour++;   }
      if ($hour   >= 24) { $hour   -= 24; $day++;    }
      if ($month =~ /^(01|03|05|07|08|10|12)$/) {
         if ($day >  31) { $day    -= 31; $month++;  }
      } elsif ($month =~ /^(04|06|09|11)$/) {
         if ($day >  30) { $day    -= 30; $month++;  }
      } elsif (($month eq "02") && $this->leap_year($year)) {
         if ($day >  29) { $day    -= 29; $month++;  }
      } elsif ($month eq "02") {
         if ($day >  28) { $day    -= 28; $month++;  }
      }
      if ($month  >  12) { $month  -= 12; $year++;   }
      return sprintf("%04d-%02d-%02dT%02d:%02d:%02d", $year,$month,$day,$hour,$minute,$second);
   } else {
      return "";
   }
}

sub stopwatch {
   local($this, $function, $id, *ht, *OUT) = @_;
   # function: start|stop|count|report; start|stop times are absolute (in secs.)

   my $current_time = time;
 # print OUT "Point S stopwatch $function $id $current_time\n";
   if ($function eq "start") {
      if ($ht{STOPWATCH_START}->{$id}) {
	 $ht{STOPWATCH_N_RESTARTS}->{$id} = ($ht{STOPWATCH_N_RESTARTS}->{$id} || 0) + 1;
      } else {
         $ht{STOPWATCH_START}->{$id} = $current_time;
      }
   } elsif ($function eq "end") {
      if ($start_time = $ht{STOPWATCH_START}->{$id}) {
         $ht{STOPWATCH_TIME}->{$id} = ($ht{STOPWATCH_TIME}->{$id} || 0) + ($current_time - $start_time);
         $ht{STOPWATCH_START}->{$id} = "";
      } else {
	 $ht{STOPWATCH_N_DEAD_ENDS}->{$id} = ($ht{STOPWATCH_N_DEAD_ENDS}->{$id} || 0) + 1;
      }
   } elsif ($function eq "count") {
      $ht{STOPWATCH_COUNT}->{$id} = ($ht{STOPWATCH_COUNT}->{$id} || 0) + 1;
   } elsif ($function eq "report") {
      my $id2;
      foreach $id2 (keys %{$ht{STOPWATCH_START}}) {
         if ($start_time = $ht{STOPWATCH_START}->{$id2}) {
	    $ht{STOPWATCH_TIME}->{$id2} = ($ht{STOPWATCH_TIME}->{$id2} || 0) + ($current_time - $start_time);
	    $ht{STOPWATCH_START}->{$id2} = $current_time;
	 }
      }
      print OUT "Time report:\n";
      foreach $id2 (sort { $ht{STOPWATCH_TIME}->{$b} <=> $ht{STOPWATCH_TIME}->{$a} }
			 keys %{$ht{STOPWATCH_TIME}}) {
	 my $stopwatch_time = $ht{STOPWATCH_TIME}->{$id2};
	 $stopwatch_time = $this->round_to_n_decimal_places($stopwatch_time, 3);
	 my $n_restarts = $ht{STOPWATCH_N_RESTARTS}->{$id2};
	 my $n_dead_ends = $ht{STOPWATCH_N_DEAD_ENDS}->{$id2};
         my $start_time = $ht{STOPWATCH_START}->{$id2};
	 print OUT "   $id2: $stopwatch_time seconds";
	 print OUT " with $n_restarts restart(s)" if $n_restarts;
	 print OUT " with $n_dead_ends dead end(s)" if $n_dead_ends;
	 print OUT " (active)" if $start_time;
	 print OUT "\n";
      }
      foreach $id2 (sort { $ht{STOPWATCH_COUNT}->{$b} <=> $ht{STOPWATCH_COUNT}->{$a} }
                         keys %{$ht{STOPWATCH_COUNT}}) {
         $count = $ht{STOPWATCH_COUNT}->{$id2};
	 print OUT " C $id2: $count\n";
      }
   }
}

sub print_html_banner {
   local($this,$text,$bgcolor,*OUT,$control) = @_;

   $control = "" unless defined($control);
   $bgcolor = "#BBCCFF" unless defined($bgcolor);
   print OUT "<table width=\"100%\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\"><tr bgcolor=\"$bgcolor\"><td>";
   print OUT "&nbsp; " unless $text =~ /^\s*<(table|nobr)/;
   print OUT $text;
   print OUT "</td></tr></table>\n";
   print OUT "<br />\n" unless $control =~ /nobr/i;
}

sub print_html_head {
   local($this, $title, *OUT, $control, $onload_fc, $add_javascript) = @_;

   $control = "" unless defined($control);
   $onload_fc = "" unless defined($onload_fc);
   $onload_clause = ($onload_fc) ? " onload=\"$onload_fc\"" : "";
   $add_javascript = "" unless defined($add_javascript);
   $max_age_clause = "";
   $max_age_clause = "<meta http-equiv=\"cache-control\" content=\"max-age=3600\" \/>"; # if $control =~ /\bexp1hour\b/;
   $css_clause = "";
   $css_clause = "\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"https://www.isi.edu/~ulf/css/handheld/default.css\" media=\"handheld\"\/>" if $control =~ /css/;
   $css_clause .= "\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"https://www.isi.edu/~ulf/css/handheld/default.css\" media=\"only screen and (max-device-width:480px)\"\/>" if $control =~ /css/;
   $css_clause = "\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"https://www.isi.edu/~ulf/css/handheld/default.css\">" if $control =~ /css-handheld/;
   $icon_clause = "";
   $icon_clause .= "\n   <link rel=\"shortcut icon\" href=\"https://www.isi.edu/~ulf/amr/images/AMR-favicon.ico\">" if $control =~ /\bAMR\b/i;
   $icon_clause .= "\n   <link rel=\"shortcut icon\" href=\"https://www.isi.edu/~ulf/croom/images/CRE-favicon.ico\">" if $control =~ /\bCRE\b/i;
   print OUT "\xEF\xBB\xBF\n" unless $control =~ /\bno-bom\b/; # utf8 marker byte order mark
   print OUT<<END_OF_HEADER1;
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    $max_age_clause
    <title>$title</title>$css_clause$icon_clause
END_OF_HEADER1
;

   unless ($control =~ /no javascript/) {
   print OUT<<END_OF_HEADER2;
    <script type="text/javascript">
    <!--
    function toggle(id) {
       if ((s = document.getElementById(id)) != null) {
          if (s.style.display == 'none') {
             s.style.display = 'inline';
          } else {
             s.style.display = 'none';
          }
       }
    }

    function toggle_group(group_id, url, new_search_help_id) {
       if (((s = document.getElementById('new_search_on_next_click_p')) == null) || (s.value == 0)) {          
          i = 1;         
          id = group_id + '_' + i;
          while ((s = document.getElementById(id)) != null) {
             if (s.style.display == 'none') {
                s.style.display = 'inline';
             } else {
                s.style.display = 'none';
             }
             i = i + 1;
             id = group_id + '_' + i;
          }
       }

       if ((s = document.getElementById('new_search_on_next_click_p')) != null) {
          new_search_value = s.value;
          s.value = 0;
          if ((new_search_help_id != 0) && ((s2 = document.getElementById(new_search_help_id)) != null)) {
             s2.style.display = 'none';
          }
          if ((new_search_value == 1) && (url != 0)) {
             popUpBottom(url,750,400);
          }
       }
    }

    function set_group_display(group_id, value) {
       i = 1;         
       id = group_id + '_' + i;
       while ((s = document.getElementById(id)) != null) {
          s.style.display = value;
          i = i + 1;
          id = group_id + '_' + i;
       }
    }

    function popUpBottom(URL,width,height) {
       day = new Date();
       id = day.getTime();
       eval("myWindow = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=" + width + ",height=" + height + "');");
    }

    function popUpWarning(warning) {
       newwindow=window.open('','Warning','height=160,width=400,resizable=1,scrollbars=1,toolbar=0,statusbar=0,menubar=0');
       var tmp = newwindow.document;
       tmp.write('<html>\\n');
       tmp.write('  <head><title>AMR Editor Warning</title></head>\\n');
       tmp.write('  <body' + ' style="background-color:#FFFFEE;">\\n');
       tmp.write('    <h3>Warning</h3>\\n');
       tmp.write('    ' + warning + '\\n');
       tmp.write('    <p>\\n');
       tmp.write('    <input type=\"submit\" title=\"Close this window.\" value=\"OK\" onclick=\"self.close();\">\\n');
       tmp.write('  </body>\\n');
       tmp.write('</html>\\n');
       tmp.close();
    }

    function new_search_on_next_click(new_search_help_id) {
       if ((s = document.getElementById(new_search_help_id)) != null) {
          s.style.display = 'inline';
       }
       if ((s = document.getElementById('new_search_on_next_click_p')) != null) {
          s.value = 1;
       }
    }

    function set(id, value) {
       if ((s = document.getElementById(id)) != null) {
	  s.value = value;
       }
    }

    function set_group_pairwise(snt_id, odd_value, even_value) {
       gi = 0;
       group_id = snt_id + '_' + gi;
       i = 1;
       id = group_id + '_' + i;
       while (((s = document.getElementById(id)) != null) || (gi == 0)) {
          while ((s = document.getElementById(id)) != null) {
	     s.style.display = odd_value;
             i = i + 1;
	     id = group_id + '_' + i;
	     if ((s = document.getElementById(id)) != null) {
	        s.style.display = even_value;
	     }
             i = i + 1;
	     id = group_id + '_' + i;
          }
          gi = gi + 1;
          group_id = snt_id + '_' + gi;
          i = 1;
          id = group_id + '_' + i;
       }
    }

    function clear(id) {
       if (s = document.getElementById(id)) {
          s.value = '';
       }
    }

    function goto_page_loc(hash, id, y) {
       var s ;
       var page_dynamically_created_p = 0;
       if (page_dynamically_created_p) {
          if ((s = document.getElementById(id)) != null) {
             s.checked = "true";
             s.focus();
             if (document.body.scrollTop > 0) {
               document.body.scrollTop += y;
             } else {
               // document.body.scrollTop = document.body.scrollHeight;
               // s.focus();
             }
          } 
       } else {
          window.location.hash = hash;
          if ((s = document.getElementById(id)) != null) {
             s.checked = "true";
          }
       }
    }

    function redirect(url) {
       window.location = url;
    }

    $add_javascript
    -->
    </script>
END_OF_HEADER2
;
   }

   print OUT<<END_OF_HEADER3;
  </head>
  <body bgcolor="#FFFFEE"$onload_clause>
END_OF_HEADER3
;
}


sub print_html_foot {
   local($this, *OUT) = @_;

   print OUT "   </body>\n";
   print OUT "</html>\n";
}

sub print_html_page {
   local($this, *OUT, $s) = @_;

   print OUT "\xEF\xBB\xBF\n";
   print OUT "<html>\n";
   print OUT "   <head>\n";
   print OUT "      <title>DEBUG</title>\n";
   print OUT "      <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" \/>\n";
   print OUT "      <meta http-equiv=\"cache-control\" content=\"max-age=30\" \/>\n";
   print OUT "   </head>\n";
   print OUT "   <body>\n";
   print OUT "      $s\n";
   print OUT "   </body>\n";
   print OUT "</html>\n";
}

sub http_catfile {
   local($this, @path) = @_;

   $result = File::Spec->catfile(@path);
   $result =~ s/(https?):\/([a-zA-Z])/$1:\/\/$2/;
   return $result;
}

sub underscore_to_space {
   local($this, $s) = @_;

   return "" unless defined($s);

   $s =~ s/_+/ /g;
   return $s;
}

sub space_to_underscore {
   local($this, $s) = @_;

   return "" unless defined($s);

   $s =~ s/ /_/g;
   return $s;
}

sub remove_spaces {
   local($this, $s) = @_;

   $s =~ s/\s//g;
   return $s;
}

sub is_punctuation_string_p {
   local($this, $s) = @_;

   return "" unless $s;
   $s = $this->normalize_string($s) if $s =~ /[\x80-\xBF]/;
   return $s =~ /^[-_,;:.?!\/\@+*"()]+$/;
}

sub is_rare_punctuation_string_p {
   local($this, $s) = @_;

   return 0 unless $s =~ /^[\x21-\x2F\x3A\x40\x5B-\x60\x7B-\x7E]{2,}$/;
   return 0 if $s =~ /^(\.{2,3}|-{2,3}|\*{2,3}|::|\@?[-\/:]\@?)$/;
   return 1;
}

sub simplify_punctuation {
   local($this, $s) = @_;

   $s =~ s/\xE2\x80\x92/-/g;
   $s =~ s/\xE2\x80\x93/-/g;
   $s =~ s/\xE2\x80\x94/-/g;
   $s =~ s/\xE2\x80\x95/-/g;
   $s =~ s/\xE2\x80\x98/`/g;
   $s =~ s/\xE2\x80\x99/'/g;
   $s =~ s/\xE2\x80\x9A/`/g;
   $s =~ s/\xE2\x80\x9C/"/g;
   $s =~ s/\xE2\x80\x9D/"/g;
   $s =~ s/\xE2\x80\x9E/"/g;
   $s =~ s/\xE2\x80\x9F/"/g;
   $s =~ s/\xE2\x80\xA2/*/g;
   $s =~ s/\xE2\x80\xA4/./g;
   $s =~ s/\xE2\x80\xA5/../g;
   $s =~ s/\xE2\x80\xA6/.../g;
   return $s;
}

sub latin_plus_p {
   local($this, $s, $control) = @_;

   $control = "" unless defined($control);
   return $s =~ /^([\x20-\x7E]|\xC2[\xA1-\xBF]|[\xC3-\xCC][\x80-\xBF]|\xCA[\x80-\xAF]|\xE2[\x80-\xAF][\x80-\xBF])+$/;
}

sub nth_line_in_file {
   local($this, $filename, $n) = @_;

   return "" unless $n =~ /^[1-9]\d*$/;
   open(IN, $filename) || return "";
   my $line_no = 0;
   while (<IN>) {
      $line_no++;
      if ($n == $line_no) {
	 $_ =~ s/\s+$//;
         close(IN);
	 return $_;
      }
   }
   close(IN);
   return "";
}

sub read_file {
   local($this, $filename) = @_;

   my $file_content = "";
   open(IN, $filename) || return "";
   while (<IN>) {
      $file_content .= $_;
   }
   close(IN);
   return $file_content;
}

sub cap_list {
   local($this, @list) = @_;

   @cap_list = ();
   foreach $l (@list) {
      ($premod, $core) = ($l =~ /^(a|an) (\S.*)$/);
      if (defined($premod) && defined($core)) {
         push(@cap_list, "$premod \u$core");
      } elsif ($this->cap_member($l, "US")) {
	 push(@cap_list, uc $l);
      } else {
         push(@cap_list, "\u$l");
      }
   }
   return @cap_list;
}

sub integer_list_with_commas_and_ranges {
   local($this, @list) = @_;

   my $in_range_p = 0;
   my $last_value = 0;
   my $result = "";
   while (@list) {
      $elem = shift @list;
      if ($elem =~ /^\d+$/) {
         if ($in_range_p) {
	    if ($elem == $last_value + 1) {
	       $last_value = $elem;
	    } else {
	       $result .= "-$last_value, $elem";
	       if (@list && ($next = $list[0]) && ($elem =~ /^\d+$/) && ($next =~ /^\d+$/)
			 && ($next == $elem + 1)) {
		  $last_value = $elem;
		  $in_range_p = 1;
	       } else {
		  $in_range_p = 0;
	       }
	    }
         } else {
	    $result .= ", $elem";
	    if (@list && ($next = $list[0]) && ($elem =~ /^\d+$/) && ($next =~ /^\d+$/)
		      && ($next == $elem + 1)) {
	       $last_value = $elem;
	       $in_range_p = 1;
	    }
	 }
      } else {
	 if ($in_range_p) {
	    $result .= "-$last_value, $elem";
	    $in_range_p = 0;
	 } else {
	    $result .= ", $elem";
	 }
      }
   }
   if ($in_range_p) {
      $result .= "-$last_value";
   }
   $result =~ s/^,\s*//;
   return $result;
}

sub comma_append {
   local($this, $a, $b) = @_;

   if (defined($a) && ($a =~ /\S/)) {
      if (defined($b) && ($b =~ /\S/)) {
	 return "$a,$b";
      } else {
	 return $a;
      }
   } else {
      if (defined($b) && ($b =~ /\S/)) {
	 return $b;
      } else {
	 return "";
      }
   }
}

sub version {
   return "3.17";
}

sub print_stderr {
   local($this, $message, $verbose) = @_;

   $verbose = 1 unless defined($verbose);
   print STDERR $message if $verbose;
   return 1;
}

sub print_log {
   local($this, $message, *LOG, $verbose) = @_;

   $verbose = 1 unless defined($verbose);
   print LOG $message if $verbose;
   return 1;
}

sub compare_alignment {
   local($this, $a, $b, $delimiter) = @_;

   $delimiter = "-" unless $delimiter;
   my @a_list = split($delimiter, $a);
   my @b_list = split($delimiter, $b);

   while (@a_list && @b_list) {
      $a_head = shift @a_list;
      $b_head = shift @b_list;
      next if $a_head eq $b_head;
      return $a_head <=> $b_head if ($a_head =~ /^\d+$/) && ($b_head =~ /^\d+$/);
      return $a_head cmp $b_head;
   }
   return -1 if @a_list;
   return 1 if @b_list;
   return 0;
}

sub normalize_string {
   # normalize punctuation, full-width characters (to ASCII)
   local($this, $s, $control) = @_;

   $control = "" unless defined($control);

   $norm_s = $s;
   $norm_s =~ tr/A-Z/a-z/;

   $norm_s =~ s/ \@([-:\/])/ $1/g; # non-initial left  @
   $norm_s =~ s/^\@([-:\/])/$1/;   #     initial left  @
   $norm_s =~ s/([-:\/])\@ /$1 /g; # non-initial right @
   $norm_s =~ s/([-:\/])\@$/$1/;   #     initial right @
   $norm_s =~ s/([\(\)"])([,;.?!])/$1 $2/g;
   $norm_s =~ s/\bcannot\b/can not/g;

   $norm_s =~ s/\xC2\xAD/-/g; # soft hyphen

   $norm_s =~ s/\xE2\x80\x94/-/g; # em dash
   $norm_s =~ s/\xE2\x80\x95/-/g; # horizontal bar
   $norm_s =~ s/\xE2\x80\x98/`/g; # grave accent
   $norm_s =~ s/\xE2\x80\x99/'/g; # apostrophe
   $norm_s =~ s/\xE2\x80\x9C/"/g; # left double quote mark
   $norm_s =~ s/\xE2\x80\x9D/"/g; # right double quote mark
   $norm_s =~ s/\xE2\x94\x80/-/g; # box drawings light horizontal
   $norm_s =~ s/\xE2\x94\x81/-/g; # box drawings heavy horizontal
   $norm_s =~ s/\xE3\x80\x81/,/g; # ideographic comma
   $norm_s =~ s/\xE3\x80\x82/./g; # ideographic full stop
   $norm_s =~ s/\xE3\x80\x88/"/g; # left angle bracket
   $norm_s =~ s/\xE3\x80\x89/"/g; # right angle bracket
   $norm_s =~ s/\xE3\x80\x8A/"/g; # left double angle bracket
   $norm_s =~ s/\xE3\x80\x8B/"/g; # right double angle bracket
   $norm_s =~ s/\xE3\x80\x8C/"/g; # left corner bracket
   $norm_s =~ s/\xE3\x80\x8D/"/g; # right corner bracket
   $norm_s =~ s/\xE3\x80\x8E/"/g; # left white corner bracket
   $norm_s =~ s/\xE3\x80\x8F/"/g; # right white corner bracket
   $norm_s =~ s/\xE3\x83\xBB/\xC2\xB7/g; # katakana middle dot -> middle dot
   $norm_s =~ s/\xEF\xBB\xBF//g; # UTF8 marker

   if ($control =~ /\bzh\b/i) {
      # de-tokenize Chinese
      unless ($control =~ /\bpreserve-tok\b/) {
         while ($norm_s =~ /[\xE0-\xEF][\x80-\xBF][\x80-\xBF] [\xE0-\xEF][\x80-\xBF][\x80-\xBF]/) {
            $norm_s =~ s/([\xE0-\xEF][\x80-\xBF][\x80-\xBF]) ([\xE0-\xEF][\x80-\xBF][\x80-\xBF])/$1$2/g;
         }
         $norm_s =~ s/([\xE0-\xEF][\x80-\xBF][\x80-\xBF]) ([\x21-\x7E])/$1$2/g;
         $norm_s =~ s/([\x21-\x7E]) ([\xE0-\xEF][\x80-\xBF][\x80-\xBF])/$1$2/g;
      }

      # fullwidth characters
      while ($norm_s =~ /\xEF\xBC[\x81-\xBF]/) {
         ($pre,$fullwidth,$post) = ($norm_s =~ /^(.*)(\xEF\xBC[\x81-\xBF])(.*)$/);
         $fullwidth =~ s/^\xEF\xBC//;
         $fullwidth =~ tr/[\x81-\xBF]/[\x21-\x5F]/;
         $norm_s = "$pre$fullwidth$post";
      }
      while ($norm_s =~ /\xEF\xBD[\x80-\x9E]/) {
         ($pre,$fullwidth,$post) = ($norm_s =~ /^(.*)(\xEF\xBD[\x80-\x9E])(.*)$/);
         $fullwidth =~ s/^\xEF\xBD//;
         $fullwidth =~ tr/[\x80-\x9E]/[\x60-\x7E]/;
         $norm_s = "$pre$fullwidth$post";
      }
      $norm_s =~ tr/A-Z/a-z/ unless $control =~ /\bpreserve-case\b/;

      unless ($control =~ /\bpreserve-tok\b/) {
         while ($norm_s =~ /[\x21-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E] [\x21-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E]/) {
            $norm_s =~ s/([\x21-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E]) ([\x21-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E])/$1$2/g;
         }
         $norm_s =~ s/([\x21-\x7E]) ([\x21-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E])/$1$2/g;
         $norm_s =~ s/([\x21-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E]) ([\x21-\x7E])/$1$2/g;
         $norm_s =~ s/ (\xC2\xA9|\xC2\xB7|\xC3\x97) /$1/g; # copyright sign, middle dot, multiplication sign
      }
   }

   if (($control =~ /\bzh\b/i) && ($control =~ /\bnorm-char\b/)) {
       $norm_s =~ s/\xE6\x96\xBC/\xE4\xBA\x8E/g; # feng1 (first char. of Chin. "lie low", line 1308)
       $norm_s =~ s/\xE6\xAD\xA7/\xE5\xB2\x90/g; # qi2 (second char. of Chin. "difference", line 1623)
       $norm_s =~ s/\xE8\x82\xB2/\xE6\xAF\x93/g; # yu4 (second char. of Chin. "sports", line 440)
       $norm_s =~ s/\xE8\x91\x97/\xE7\x9D\x80/g; # zhao (second char. of Chin. "prominent", line 4)
       $norm_s =~ s/\xE9\x81\x87/\xE8\xBF\x82/g; # yu4 (second char. of Chin. "good luck", line 959)
   }

   if ($control =~ /\bspurious-punct\b/) {
      $norm_s =~ s/^\s*[-_\." ]+//;
      $norm_s =~ s/[-_\." ]+\s*$//;
      $norm_s =~ s/\(\s+end\s+\)\s*$//i;
      $norm_s =~ s/^\s*null\s*$//i;
   }

   $norm_s =~ s/^\s+//;
   $norm_s =~ s/\s+$//;
   $norm_s =~ s/\s+/ /g;

   return $norm_s;
}

sub normalize_extreme_string {
   local($this, $s, $control) = @_;

   $control = "" unless defined($control);

   $norm_s = $s;
   $norm_s =~ s/\xE2\xA9\xBE/\xE2\x89\xA5/g; # slanted greater than or equal to

   return $norm_s;
}

sub increase_ht_count {
   local($this, *ht, $incr, @path) = @_;

   if ($#path == 0) {
      $ht{($path[0])} = ($ht{($path[0])} || 0) + $incr;
   } elsif ($#path == 1) {
         $ht{($path[0])}->{($path[1])}
      = ($ht{($path[0])}->{($path[1])} || 0) + $incr;
   } elsif ($#path == 2) {
         $ht{($path[0])}->{($path[1])}->{($path[2])} 
      = ($ht{($path[0])}->{($path[1])}->{($path[2])} || 0) + $incr;
   } elsif ($#path == 3) {
         $ht{($path[0])}->{($path[1])}->{($path[2])}->{($path[3])} 
      = ($ht{($path[0])}->{($path[1])}->{($path[2])}->{($path[3])} || 0) + $incr;
   } elsif ($#path == 4) {
         $ht{($path[0])}->{($path[1])}->{($path[2])}->{($path[3])}->{($path[4])}
      = ($ht{($path[0])}->{($path[1])}->{($path[2])}->{($path[3])}->{($path[4])} || 0) + $incr;
   } else {
      print STDERR "increase_ht_count unsupported for path of length " . ($#path + 1) . "\n";
   }
}

sub adjust_numbers {
   # non-negative integers
   local($this, $s, $delta) = @_;

   $result = "";
   while ($s =~ /\d/) {
      ($pre,$i,$post) = ($s =~ /^([^0-9]*)(\d+)([^0-9].*|)$/);
      $result .= $pre . ($i + $delta);
      $s = $post;
   }
   $result .= $s;
   return $result;
}

sub first_defined {
   local($this, @list) = @_;

   foreach $elem (@list) {
      return $elem if defined($elem);
   }
   return "";
}

sub first_defined_non_empty {
   local($this, @list) = @_;

   foreach $item (@list) {
      return $item if defined($item) && ($item ne "");
   }
   return "";
}

sub elem_after_member_list {
   local($this,$elem,@array) = @_;

   my @elem_after_member_list = ();
   foreach $i ((0 .. ($#array - 1))) {
      push(@elem_after_member_list, $array[$i+1]) if $elem eq $array[$i];
   }
   return join(" ", @elem_after_member_list);
}

sub add_value_to_list {
   local($this,$s,$value,$sep) = @_;

   $s = "" unless defined($s);
   $sep = "," unless defined($sep);
   return ($s =~ /\S/) ? "$s$sep$value" : $value;
}

sub add_new_value_to_list {
   local($this,$s,$value,$sep) = @_;

   $s = "" unless defined($s);
   $sep = "," unless defined($sep);
   my @values = split(/$sep/, $s);
   push(@values, $value) if defined($value) && ! $this->member($value, @values);

   return join($sep, @values);
}

sub add_new_hash_value_to_list {
   local($this,*ht,$key,$value,$sep) = @_;

   $sep = "," unless defined($sep);
   my $value_s = $ht{$key};
   if (defined($value_s)) {
      my @values = split(/$sep/, $value_s);
      push(@values, $value) unless $this->member($value, @values);
      $ht{$key} = join($sep, @values);
   } else {
      $ht{$key} = $value;
   }
}

sub ip_info {
   local($this, $ip_address) = @_;
    
   my %ip_map = ();
   $ip_map{"128.9.208.69"}  = "Ulf Hermjakob (bach.isi.edu)";
   $ip_map{"128.9.208.169"} = "Ulf Hermjakob (brahms.isi.edu)";
   $ip_map{"128.9.184.148"} = "Ulf Hermjakob (beethoven.isi.edu ?)";
   $ip_map{"128.9.184.162"} = "Ulf Hermjakob (beethoven.isi.edu)";
   $ip_map{"128.9.176.39"}  = "Kevin Knight";
   $ip_map{"128.9.184.187"} = "Kevin Knight";
   $ip_map{"128.9.216.56"}  = "Kevin Knight";
   $ip_map{"128.9.208.155"} = "cage.isi.edu";

   return ($ip_name = $ip_map{$ip_address}) ? "$ip_address - $ip_name" : $ip_address;
}

# from standalone de-accent.pl
sub de_accent_string {
   local($this, $s) = @_;

   $s =~ tr/A-Z/a-z/;
   unless (0) {
      # Latin-1
      if ($s =~ /\xC3[\x80-\xBF]/) {
         $s =~ s/(À|Á|Â|Ã|Ä|Å)/A/g;
         $s =~ s/Æ/Ae/g;
         $s =~ s/Ç/C/g;
         $s =~ s/Ð/D/g;
         $s =~ s/(È|É|Ê|Ë)/E/g;
         $s =~ s/(Ì|Í|Î|Ï)/I/g;
         $s =~ s/Ñ/N/g;
         $s =~ s/(Ò|Ó|Ô|Õ|Ö|Ø)/O/g;
         $s =~ s/(Ù|Ú|Û|Ü)/U/g;
         $s =~ s/Þ/Th/g;
         $s =~ s/Ý/Y/g;
         $s =~ s/(à|á|â|ã|ä|å)/a/g;
         $s =~ s/æ/ae/g;
         $s =~ s/ç/c/g;
         $s =~ s/(è|é|ê|ë)/e/g;
         $s =~ s/(ì|í|î|ï)/i/g;
         $s =~ s/ð/d/g;
         $s =~ s/ñ/n/g;
         $s =~ s/(ò|ó|ô|õ|ö)/o/g;
         $s =~ s/ß/ss/g;
         $s =~ s/þ/th/g;
         $s =~ s/(ù|ú|û|ü)/u/g;
         $s =~ s/(ý|ÿ)/y/g;
      }
      # Latin Extended-A
      if ($s =~ /[\xC4-\xC5][\x80-\xBF]/) {
         $s =~ s/(Ā|Ă|Ą)/A/g;
         $s =~ s/(ā|ă|ą)/a/g;
         $s =~ s/(Ć|Ĉ|Ċ|Č)/C/g;
         $s =~ s/(ć|ĉ|ċ|č)/c/g;
         $s =~ s/(Ď|Đ)/D/g;
         $s =~ s/(ď|đ)/d/g;
         $s =~ s/(Ē|Ĕ|Ė|Ę|Ě)/E/g;
         $s =~ s/(ē|ĕ|ė|ę|ě)/e/g;
         $s =~ s/(Ĝ|Ğ|Ġ|Ģ)/G/g;
         $s =~ s/(ĝ|ğ|ġ|ģ)/g/g;
         $s =~ s/(Ĥ|Ħ)/H/g;
         $s =~ s/(ĥ|ħ)/h/g;
         $s =~ s/(Ĩ|Ī|Ĭ|Į|İ)/I/g;
         $s =~ s/(ĩ|ī|ĭ|į|ı)/i/g;
         $s =~ s/Ĳ/Ij/g;
         $s =~ s/ĳ/ij/g;
         $s =~ s/Ĵ/J/g;
         $s =~ s/ĵ/j/g;
         $s =~ s/Ķ/K/g;
         $s =~ s/(ķ|ĸ)/k/g;
         $s =~ s/(Ĺ|Ļ|Ľ|Ŀ|Ł)/L/g;
         $s =~ s/(ļ|ľ|ŀ|ł)/l/g;
         $s =~ s/(Ń|Ņ|Ň|Ŋ)/N/g;
         $s =~ s/(ń|ņ|ň|ŉ|ŋ)/n/g;
         $s =~ s/(Ō|Ŏ|Ő)/O/g;
         $s =~ s/(ō|ŏ|ő)/o/g;
         $s =~ s/Œ/Oe/g;
         $s =~ s/œ/oe/g;
         $s =~ s/(Ŕ|Ŗ|Ř)/R/g;
         $s =~ s/(ŕ|ŗ|ř)/r/g;
         $s =~ s/(Ś|Ŝ|Ş|Š)/S/g;
         $s =~ s/(ś|ŝ|ş|š|ſ)/s/g;
         $s =~ s/(Ţ|Ť|Ŧ)/T/g;
         $s =~ s/(ţ|ť|ŧ)/t/g;
         $s =~ s/(Ũ|Ū|Ŭ|Ů|Ű|Ų)/U/g;
         $s =~ s/(ũ|ū|ŭ|ů|ű|ų)/u/g;
         $s =~ s/Ŵ/W/g;
         $s =~ s/ŵ/w/g;
         $s =~ s/(Ŷ|Ÿ)/Y/g;
         $s =~ s/ŷ/y/g;
         $s =~ s/(Ź|Ż|Ž)/Z/g;
         $s =~ s/(ź|ż|ž)/z/g;
      }
      # Latin Extended-B
      if ($s =~ /[\xC7-\xC7][\x80-\xBF]/) {
	 $s =~ s/(\xC7\x8D)/A/g;
	 $s =~ s/(\xC7\x8E)/a/g;
	 $s =~ s/(\xC7\x8F)/I/g;
	 $s =~ s/(\xC7\x90)/i/g;
	 $s =~ s/(\xC7\x91)/O/g;
	 $s =~ s/(\xC7\x92)/o/g;
	 $s =~ s/(\xC7\x93)/U/g;
	 $s =~ s/(\xC7\x94)/u/g;
	 $s =~ s/(\xC7\x95)/U/g;
	 $s =~ s/(\xC7\x96)/u/g;
	 $s =~ s/(\xC7\x97)/U/g;
	 $s =~ s/(\xC7\x98)/u/g;
	 $s =~ s/(\xC7\x99)/U/g;
	 $s =~ s/(\xC7\x9A)/u/g;
	 $s =~ s/(\xC7\x9B)/U/g;
	 $s =~ s/(\xC7\x9C)/u/g;
      }
      # Latin Extended Additional
      if ($s =~ /\xE1[\xB8-\xBF][\x80-\xBF]/) {
          $s =~ s/(ḁ|ạ|ả|ấ|ầ|ẩ|ẫ|ậ|ắ|ằ|ẳ|ẵ|ặ|ẚ)/a/g;
          $s =~ s/(ḃ|ḅ|ḇ)/b/g;
          $s =~ s/(ḉ)/c/g;
          $s =~ s/(ḋ|ḍ|ḏ|ḑ|ḓ)/d/g;
          $s =~ s/(ḕ|ḗ|ḙ|ḛ|ḝ|ẹ|ẻ|ẽ|ế|ề|ể|ễ|ệ)/e/g;
          $s =~ s/(ḟ)/f/g;
          $s =~ s/(ḡ)/g/g;
          $s =~ s/(ḣ|ḥ|ḧ|ḩ|ḫ)/h/g;
          $s =~ s/(ḭ|ḯ|ỉ|ị)/i/g;
          $s =~ s/(ḱ|ḳ|ḵ)/k/g;
          $s =~ s/(ḷ|ḹ|ḻ|ḽ)/l/g;
          $s =~ s/(ḿ|ṁ|ṃ)/m/g;
          $s =~ s/(ṅ|ṇ|ṉ|ṋ)/m/g;
          $s =~ s/(ọ|ỏ|ố|ồ|ổ|ỗ|ộ|ớ|ờ|ở|ỡ|ợ|ṍ|ṏ|ṑ|ṓ)/o/g;
          $s =~ s/(ṕ|ṗ)/p/g;
          $s =~ s/(ṙ|ṛ|ṝ|ṟ)/r/g;
          $s =~ s/(ṡ|ṣ|ṥ|ṧ|ṩ|ẛ)/s/g;
          $s =~ s/(ṫ|ṭ|ṯ|ṱ)/t/g;
          $s =~ s/(ṳ|ṵ|ṷ|ṹ|ṻ|ụ|ủ|ứ|ừ|ử|ữ|ự)/u/g;
          $s =~ s/(ṽ|ṿ)/v/g;
          $s =~ s/(ẁ|ẃ|ẅ|ẇ|ẉ|ẘ)/w/g;
          $s =~ s/(ẋ|ẍ)/x/g;
          $s =~ s/(ẏ|ỳ|ỵ|ỷ|ỹ|ẙ)/y/g;
          $s =~ s/(ẑ|ẓ|ẕ)/z/g;
          $s =~ s/(Ḁ|Ạ|Ả|Ấ|Ầ|Ẩ|Ẫ|Ậ|Ắ|Ằ|Ẳ|Ẵ|Ặ)/A/g;
          $s =~ s/(Ḃ|Ḅ|Ḇ)/B/g;
          $s =~ s/(Ḉ)/C/g;
          $s =~ s/(Ḋ|Ḍ|Ḏ|Ḑ|Ḓ)/D/g;
          $s =~ s/(Ḕ|Ḗ|Ḙ|Ḛ|Ḝ|Ẹ|Ẻ|Ẽ|Ế|Ề|Ể|Ễ|Ệ)/E/g;
          $s =~ s/(Ḟ)/F/g;
          $s =~ s/(Ḡ)/G/g;
          $s =~ s/(Ḣ|Ḥ|Ḧ|Ḩ|Ḫ)/H/g;
          $s =~ s/(Ḭ|Ḯ|Ỉ|Ị)/I/g;
          $s =~ s/(Ḱ|Ḳ|Ḵ)/K/g;
          $s =~ s/(Ḷ|Ḹ|Ḻ|Ḽ)/L/g;
          $s =~ s/(Ḿ|Ṁ|Ṃ)/M/g;
          $s =~ s/(Ṅ|Ṇ|Ṉ|Ṋ)/N/g;
          $s =~ s/(Ṍ|Ṏ|Ṑ|Ṓ|Ọ|Ỏ|Ố|Ồ|Ổ|Ỗ|Ộ|Ớ|Ờ|Ở|Ỡ|Ợ)/O/g;
          $s =~ s/(Ṕ|Ṗ)/P/g;
          $s =~ s/(Ṙ|Ṛ|Ṝ|Ṟ)/R/g;
          $s =~ s/(Ṡ|Ṣ|Ṥ|Ṧ|Ṩ)/S/g;
          $s =~ s/(Ṫ|Ṭ|Ṯ|Ṱ)/T/g;
          $s =~ s/(Ṳ|Ṵ|Ṷ|Ṹ|Ṻ|Ụ|Ủ|Ứ|Ừ|Ử|Ữ|Ự)/U/g;
          $s =~ s/(Ṽ|Ṿ)/V/g;
          $s =~ s/(Ẁ|Ẃ|Ẅ|Ẇ|Ẉ)/W/g;
          $s =~ s/(Ẍ)/X/g;
          $s =~ s/(Ẏ|Ỳ|Ỵ|Ỷ|Ỹ)/Y/g; 
          $s =~ s/(Ẑ|Ẓ|Ẕ)/Z/g;
      }
      # Greek letters
      if ($s =~ /\xCE[\x86-\xAB]/) {
          $s =~ s/ά/α/g;
          $s =~ s/έ/ε/g;
          $s =~ s/ί/ι/g;
          $s =~ s/ϊ/ι/g;
          $s =~ s/ΐ/ι/g;
          $s =~ s/ό/ο/g;
          $s =~ s/ύ/υ/g;
          $s =~ s/ϋ/υ/g;
          $s =~ s/ΰ/υ/g;
          $s =~ s/ώ/ω/g;
          $s =~ s/Ά/Α/g;
          $s =~ s/Έ/Ε/g;
          $s =~ s/Ή/Η/g;
          $s =~ s/Ί/Ι/g;
          $s =~ s/Ϊ/Ι/g;
          $s =~ s/Ύ/Υ/g;
          $s =~ s/Ϋ/Υ/g;
          $s =~ s/Ώ/Ω/g;
      }
      # Cyrillic letters
      if ($s =~ /\xD0[\x80-\xAF]/) {
          $s =~ s/Ѐ/Е/g;
          $s =~ s/Ё/Е/g;
          $s =~ s/Ѓ/Г/g;
          $s =~ s/Ќ/К/g;
          $s =~ s/Ѝ/И/g;
          $s =~ s/Й/И/g;
          $s =~ s/ѐ/е/g;
          $s =~ s/ё/е/g;
          $s =~ s/ѓ/г/g;
          $s =~ s/ќ/к/g;
          $s =~ s/ѝ/и/g;
          $s =~ s/й/и/g;
      }
   }
   return $s;
}

sub read_de_accent_case_resource {
   local($this, $filename, *ht, *LOG, $verbose) = @_;
   # e.g. data/char-de-accent-lc.txt

   if (open(IN, $filename)) {
      my $mode = "de-accent";
      my $line_number = 0;
      my $n_de_accent_targets = 0;
      my $n_de_accent_sources = 0;
      my $n_case_entries = 0;
      while (<IN>) {
	 s/^\xEF\xBB\xBF//;
	 s/\s*$//;
	 $line_number++;
	 if ($_ =~ /^#+\s*CASE\b/) {
	    $mode = "case";
	 } elsif ($_ =~ /^#+\s*PUNCTUATION NORMALIZATION\b/) {
	    $mode = "punctuation-normalization";
	 } elsif ($_ =~ /^#/) {
	    # ignore comment
	 } elsif ($_ =~ /^\s*$/) {
	    # ignore empty line
         } elsif (($mode eq "de-accent") && (($char_without_accent, @chars_with_accent) = split(/\s+/, $_))) {
	    if (keys %{$ht{DE_ACCENT_INV}->{$char_without_accent}}) {
	       print LOG "Ignoring duplicate de-accent line for target $char_without_accent in l.$line_number in $filename\n" unless $char_without_accent eq "--";
	    } elsif (@chars_with_accent) {
	       $n_de_accent_targets++;
	       foreach $char_with_accent (@chars_with_accent) {
		  my @prev_target_chars = keys %{$ht{DE_ACCENT}->{$char_with_accent}};
		  print LOG "Accent character $char_with_accent has duplicate target $char_without_accent (besides @prev_target_chars) in l.$line_number in $filename\n" if @prev_target_chars && (! ($char_without_accent =~ /^[aou]e$/i));
		  $char_without_accent = "" if $char_without_accent eq "--";
	          $ht{DE_ACCENT}->{$char_with_accent}->{$char_without_accent} = 1;
	          $ht{DE_ACCENT1}->{$char_with_accent} = $char_without_accent 
		     if (! defined($ht{DE_ACCENT1}->{$char_with_accent}))
		     && ($char_without_accent =~ /^.[\x80-\xBF]*$/);
	          $ht{DE_ACCENT_INV}->{$char_without_accent}->{$char_with_accent} = 1;
	          $ht{UPPER_CASE_OR_ACCENTED}->{$char_with_accent} = 1;
		  $n_de_accent_sources++;
	       }
	    } else {
	       print LOG "Empty de-accent list for $char_without_accent in l.$line_number in $filename\n";
	    } 
	 } elsif (($mode eq "punctuation-normalization") && (($norm_punct, @unnorm_puncts) = split(/\s+/, $_))) {
	    if (keys %{$ht{NORM_PUNCT_INV}->{$norm_punct}}) {
	       print LOG "Ignoring duplicate punctuation-normalization line for target $norm_punct in l.$line_number in $filename\n";
	    } elsif (@unnorm_puncts) {
	       foreach $unnorm_punct (@unnorm_puncts) {
		  my $prev_norm_punct = $ht{NORM_PUNCT}->{$unnorm_punct};
		  if ($prev_norm_punct) {
		     print LOG "Ignoring duplicate punctuation normalization $unnorm_punct -> $norm_punct (besides $prev_norm_punct) in l.$line_number in $filename\n";
		  }
	          $ht{NORM_PUNCT}->{$unnorm_punct} = $norm_punct;
	          $ht{NORM_PUNCT_INV}->{$norm_punct}->{$unnorm_punct} = 1;
	          $ht{LC_DE_ACCENT_CHAR_NORM_PUNCT}->{$unnorm_punct} = $norm_punct;
	       }
	    }
	 } elsif (($mode eq "case") && (($uc_char, $lc_char) = ($_ =~ /^(\S+)\s+(\S+)\s*$/))) {
	    $ht{UPPER_TO_LOWER_CASE}->{$uc_char} = $lc_char;
	    $ht{LOWER_TO_UPPER_CASE}->{$lc_char} = $uc_char;
	    $ht{UPPER_CASE_P}->{$uc_char} = 1;
	    $ht{LOWER_CASE_P}->{$lc_char} = 1;
	    $ht{UPPER_CASE_OR_ACCENTED}->{$uc_char} = 1;
	    $n_case_entries++;
	 } else {
	    print LOG "Unrecognized l.$line_number in $filename\n";
	 }
      }
      foreach $char (keys %{$ht{UPPER_CASE_OR_ACCENTED}}) {
	 my $lc_char = $ht{UPPER_TO_LOWER_CASE}->{$char};
	 $lc_char = $char unless defined($lc_char);
         my @de_accend_char_results = sort keys %{$ht{DE_ACCENT}->{$lc_char}};
	 my $new_char = (@de_accend_char_results) ? $de_accend_char_results[0] : $lc_char;
	 $ht{LC_DE_ACCENT_CHAR}->{$char} = $new_char;
	 $ht{LC_DE_ACCENT_CHAR_NORM_PUNCT}->{$char} = $new_char;
      }
      close(IN);
      print LOG "Found $n_case_entries case entries, $n_de_accent_sources/$n_de_accent_targets source/target entries in $line_number lines in file $filename\n" if $verbose;
   } else {
      print LOG "Can't open $filename\n";
   }
}

sub de_accent_char {
   local($this, $char, *ht, $default) = @_;

   @de_accend_char_results = sort keys %{$ht{DE_ACCENT}->{$char}};
   return (@de_accend_char_results) ? @de_accend_char_results : ($default);
}

sub lower_case_char {
   local($this, $char, *ht, $default) = @_;
   
   return (defined($lc = $ht{UPPER_TO_LOWER_CASE}->{$char})) ? $lc : $default;
}

sub lower_case_and_de_accent_char {
   local($this, $char, *ht) = @_;

   my $lc_char = $this->lower_case_char($char, *ht, $char);
   return $this->de_accent_char($lc_char, *ht, $lc_char);
}

sub lower_case_and_de_accent_string {
   local($this, $string, *ht, $control) = @_;

 # $this->stopwatch("start", "lower_case_and_de_accent_string", *ht, *LOG);
   my $norm_punct_p = ($control && ($control =~ /norm-punct/i));
   my @chars = $this->split_into_utf8_characters($string);
   my $result = "";
   foreach $char (@chars) {
      my @lc_de_accented_chars = $this->lower_case_and_de_accent_char($char, *ht);
      if ($norm_punct_p
       && (! @lc_de_accented_chars)) {
	 my $norm_punct = $ht{NORM_PUNCT}->{$char};
         @lc_de_accented_chars = ($norm_punct) if $norm_punct;
      }
      $result .= ((@lc_de_accented_chars) ? $lc_de_accented_chars[0] : $char);
   }
 # $this->stopwatch("end", "lower_case_and_de_accent_string", *ht, *LOG);
   return $result;
}

sub lower_case_and_de_accent_norm_punct {
   local($this, $char, *ht) = @_;

   my $new_char = $ht{LC_DE_ACCENT_CHAR_NORM_PUNCT}->{$char};
   return (defined($new_char)) ? $new_char : $char;
}

sub lower_case_and_de_accent_string2 {
   local($this, $string, *ht, $control) = @_;

   my $norm_punct_p = ($control && ($control =~ /norm-punct/i));
 # $this->stopwatch("start", "lower_case_and_de_accent_string2", *ht, *LOG);
   my $s = $string;
   my $result = "";
   while (($char, $rest) = ($s =~ /^(.[\x80-\xBF]*)(.*)$/)) {
      my $new_char = $ht{LC_DE_ACCENT_CHAR}->{$char};
      if (defined($new_char)) {
         $result .= $new_char;
      } elsif ($norm_punct_p && defined($new_char = $ht{NORM_PUNCT}->{$char})) {
	 $result .= $new_char;
      } else {
         $result .= $char;
      }
      $s = $rest;
   }
 # $this->stopwatch("end", "lower_case_and_de_accent_string2", *ht, *LOG);
   return $result;
}

sub lower_case_string {
   local($this, $string, *ht, $control) = @_;

   my $norm_punct_p = ($control && ($control =~ /norm-punct/i));
   my $s = $string;
   my $result = "";
   while (($char, $rest) = ($s =~ /^(.[\x80-\xBF]*)(.*)$/)) {
      my $lc_char = $ht{UPPER_TO_LOWER_CASE}->{$char};
      if (defined($lc_char)) {
         $result .= $lc_char;
      } elsif ($norm_punct_p && defined($new_char = $ht{NORM_PUNCT}->{$char})) {
	 $result .= $new_char;
      } else {
         $result .= $char;
      }
      $s = $rest;
   }
   return $result;
}

sub round_to_n_decimal_places {
   local($this, $x, $n, $fill_decimals_p) = @_;

   $fill_decimals_p = 0 unless defined($fill_decimals_p);
   unless (defined($x)) {
      return $x;
   }
   if (($x =~ /^-?\d+$/) && (! $fill_decimals_p)) {
      return $x;
   }
   $factor = 1;
   foreach $i ((1 .. $n)) {
      $factor *= 10;
   }
   my $rounded_number;
   if ($x > 0) {
      $rounded_number = (int(($factor * $x) + 0.5) / $factor);
   } else {
      $rounded_number = (int(($factor * $x) - 0.5) / $factor);
   }
   if ($fill_decimals_p) {
      ($period, $decimals) = ($rounded_number =~ /^-?\d+(\.?)(\d*)$/);
      $rounded_number .= "." unless $period || ($n == 0);
      foreach ((1 .. ($n - length($decimals)))) {
	 $rounded_number .= 0;
      }
   }
   return $rounded_number;
}

sub commify {
   local($caller,$number) = @_;

   my $text = reverse $number;
   $text =~ s/(\d\d\d)(?=\d)(?!\d*\.)/$1,/g;
   return scalar reverse $text;
}

sub add_javascript_functions {
 local($caller,@function_names) = @_;

 $add_javascript_function_s = "";
 foreach $function_name (@function_names) {

  if ($function_name eq "highlight_elems") {
     $add_javascript_function_s .= "
    function highlight_elems(group_id, value) {
       if (group_id != '') {
          i = 1;
          id = group_id + '-' + i;
          while ((s = document.getElementById(id)) != null) {
             if (! s.origColor) {
                if (s.style.color) {
                   s.origColor = s.style.color;
                } else {
                   s.origColor = '#000000';
                }
             }
             if (value == '1') {
                s.style.color = '#0000FF';
                if (s.innerHTML == '-') {
                   s.style.innerHtml = s.innerHTML;
                   s.innerHTML = '- &nbsp; &#x2190; <i>here</i>';
                   s.style.fontWeight = 900;
                } else {
                   s.style.fontWeight = 'bold';
                }
             } else {
                s.style.fontWeight = 'normal';
                s.style.color = s.origColor;
                if (s.style.innerHtml != null) {
                   s.innerHTML = s.style.innerHtml;
                }
             }
             i = i + 1;
             id = group_id + '-' + i;
          }
       }
    }
";
  } elsif ($function_name eq "set_style_for_ids") {
   $add_javascript_function_s .= "
   function set_style_for_ids(style,id_list) {
      var ids = id_list.split(/\\s+/);
      var len = ids.length;
      var s;
      for (var i=0; i<len; i++) {
	 var id = ids[i];
	 if ((s = document.getElementById(id)) != null) {
	    s.setAttribute(\"style\", style);
	    s.style.cssText = style;
	 }
      }
   }
";
  } elsif ($function_name eq "reset_style_for_ids") {
   $add_javascript_function_s .= "
   function reset_style_for_ids(default_style,id_list) {
      var ids = id_list.split(/\\s+/);
      var len = ids.length;
      var s;
      for (var i=0; i<len; i++) {
	 var id = ids[i];
	 if ((s = document.getElementById(id)) != null) {
	    var ostyle = default_style;
	    if (s.hasAttribute(\"ostyle\")) {
	       ostyle = s.getAttribute(\"ostyle\");
	    }
	    s.setAttribute(\"style\", ostyle);
	    s.style.cssText = ostyle;
	 }
      }
   }
";
  } elsif ($function_name eq "underline_ids") {
   $add_javascript_function_s .= "
   function underline_ids(id_list) {
      var ids = id_list.split(/\\s+/);
      var len = ids.length;
      var s;
      for (var i=0; i<len; i++) {
	 var id = ids[i];
	 if ((s = document.getElementById(id)) != null) {
	    s.style.textDecoration = 'underline';
	 }
      }
   }
";
  } elsif ($function_name eq "bold_ids") {
   $add_javascript_function_s .= "
   function bold_ids(id_list) {
      var ids = id_list.split(/\\s+/);
      var len = ids.length;
      var s;
      for (var i=0; i<len; i++) {
	 var id = ids[i];
	 if ((s = document.getElementById(id)) != null) {
	    s.style.fontWeight = 'bold';
	 }
      }
   }
";
  } elsif ($function_name eq "no_textdeco_ids") {
   $add_javascript_function_s .= "
   function no_textdeco_ids(id_list) {
      var ids = id_list.split(/\\s+/);
      var len = ids.length;
      var s;
      for (var i=0; i<len; i++) {
	 var id = ids[i];
	 if ((s = document.getElementById(id)) != null) {
	    s.style.textDecoration = 'none';
	    if (s.hasAttribute(\"ostyle\")) {
	       ostyle = s.getAttribute(\"ostyle\");
	       s.setAttribute(\"style\", ostyle);
	       s.style.cssText = ostyle;
	    }
	 }
      }
   }
";
  } elsif ($function_name eq "no_fontweight_ids") {
   $add_javascript_function_s .= "
   function no_fontweight_ids(id_list) {
      var ids = id_list.split(/\\s+/);
      var len = ids.length;
      var s;
      for (var i=0; i<len; i++) {
	 var id = ids[i];
	 if ((s = document.getElementById(id)) != null) {
	    s.style.fontWeight = 'normal';
	    if (s.hasAttribute(\"ostyle\")) {
	       ostyle = s.getAttribute(\"ostyle\");
	       s.setAttribute(\"style\", ostyle);
	       s.style.cssText = ostyle;
	    }
	 }
      }
   }
";
  } elsif ($function_name eq "popUpBottom") {
   $add_javascript_function_s .= "
    function popUpBottom(URL,width,height) {
       day = new Date();
       id = day.getTime();
       eval(\"myWindow = window.open(URL, '\" + id + \"', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=\" + width + \",height=\" + height + \"');\");
    }
";
  }
 }
 return $add_javascript_function_s;
}

sub append_to_file {
   local($caller, $filename, $s, $mod) = @_;

   my $result = "";
   if (-e $filename) {
      if (open(OUT, ">>$filename")) {
	 print OUT $s;
	 close(OUT);
	 $result = "Appended";
      } else {
	 $result = "Can't append";
      }
   } else {
      if (open(OUT, ">$filename")) {
	 print OUT $s;
	 close(OUT);
	 $result = "Wrote";
      } else {
	 $result = "Can't write";
      }
   }
   chmod($mod, $filename) if defined($mod) && -e $filename;
   return $result;
}

sub square {
   local($caller, $x) = @_;

   return $x * $x;
}

sub mutual_info {
   local($caller, $ab_count, $a_count, $b_count, $total_count, $smoothing) = @_;

   $smoothing = 1 unless defined($smoothing);
   $ab_count = 0 unless defined($ab_count);
   return 0 unless $a_count && $b_count && $total_count;

   my $p_ab = $ab_count / $total_count;
   my $p_a  = $a_count / $total_count;
   my $p_b  = $b_count / $total_count;
   my $expected_ab = $p_a * $p_b * $total_count;

   return -99 unless $expected_ab || $smoothing;

   return CORE::log(($ab_count + $smoothing) / ($expected_ab + $smoothing));
}

sub mutual_info_multi {
   local($caller, $multi_count, $total_count, $smoothing, @counts) = @_;

   return 0 unless $total_count;
   my $p_indivuals = 1;
   foreach $count (@counts) {
      return 0 unless $count;
      $p_indivuals *= ($count / $total_count);
   }
   my $expected_multi_count = $p_indivuals * $total_count;
   # print STDERR "actual vs. expected multi_count($multi_count, $total_count, $smoothing, @counts) = $multi_count vs. $expected_multi_count\n";

   return -99 unless $expected_multi_count || $smoothing;

   return CORE::log(($multi_count + $smoothing) / ($expected_multi_count + $smoothing));
}

sub precision_recall_fmeasure {
   local($caller, $n_gold, $n_test, $n_shared, $pretty_print_p) = @_;
   
   unless (($n_gold =~ /^[1-9]\d*$/) && ($n_test =~ /^[1-9]\d*$/)) {
      $zero = ($pretty_print_p) ? "0%" : 0;
      if ($n_gold =~ /^[1-9]\d*$/) {
	 return ("n/a", $zero, $zero);
      } elsif ($n_test =~ /^[1-9]\d*$/) {
	 return ($zero, "n/a", $zero);
      } else {
         return ("n/a", "n/a", "n/a");
      }
   }
   my $precision = $n_shared / $n_test;
   my $recall    = $n_shared / $n_gold;
   my $f_measure = ($precision * $recall * 2) / ($precision + $recall);

   return ($precision, $recall, $f_measure) unless $pretty_print_p;

   my $pretty_precision = $caller->round_to_n_decimal_places(100*$precision, 1) . "%";
   my $pretty_recall    = $caller->round_to_n_decimal_places(100*$recall,    1) . "%";
   my $pretty_f_measure = $caller->round_to_n_decimal_places(100*$f_measure, 1) . "%";

   return ($pretty_precision, $pretty_recall, $pretty_f_measure);
}

sub recapitalize_named_entity {
   local($caller, $s) = @_;

   my @comps = ();
   foreach $comp (split(/\s+/, $s)) {
      if ($comp =~ /^(and|da|for|of|on|the|van|von)$/) {
	 push(@comps, $comp);
      } elsif ($comp =~ /^[a-z]/) {
	 push(@comps, ucfirst $comp);
      } else {
	 push(@comps, $comp);
      }
   }
   return join(" ", @comps);
}

sub slot_value_in_double_colon_del_list {
   local($this, $s, $slot, $default) = @_;

   $default = "" unless defined($default);
   if (($value) = ($s =~ /::$slot\s+(\S.*\S|\S)\s*$/)) {
      $value =~ s/\s*::\S.*\s*$//;
      return $value;
   } else {
      return $default;
   }
}

sub synt_in_double_colon_del_list {
   local($this, $s) = @_;

   ($value) = ($s =~ /::synt\s+(\S+|\S.*?\S)(?:\s+::.*)?$/);
   return (defined($value)) ? $value : "";
}

sub form_in_double_colon_del_list {
   local($this, $s) = @_;

   ($value) = ($s =~ /::form\s+(\S+|\S.*?\S)(?:\s+::.*)?$/);
   return (defined($value)) ? $value : "";
}

sub lex_in_double_colon_del_list {
   local($this, $s) = @_;

   ($value) = ($s =~ /::lex\s+(\S+|\S.*?\S)(?:\s+::.*)?$/);
   return (defined($value)) ? $value : "";
}

sub multi_slot_value_in_double_colon_del_list {
   # e.g. when there are multiple slot/value pairs in a line, e.g. ::eng ... :eng ...
   local($this, $s, $slot) = @_;

   @values = ();
   while (($value, $rest) = ($s =~ /::$slot\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) {
      push(@values, $value);
      $s = $rest;
   }
   return @values;
}

sub remove_slot_in_double_colon_del_list {
   local($this, $s, $slot) = @_;

   $s =~ s/::$slot(?:|\s+\S|\s+\S.*?\S)(\s+::\S.*|\s*)$/$1/;
   $s =~ s/^\s*//;
   return $s;
}

sub extract_split_info_from_split_dir {
   local($this, $dir, *ht) = @_;

   my $n_files = 0;
   my $n_snt_ids = 0;
   if (opendir(DIR, $dir)) {
      my @filenames = sort readdir(DIR);
      closedir(DIR);
      foreach $filename (@filenames) {
	 next unless $filename =~ /\.txt$/;
	 my $split_class;
	 if (($split_class) = ($filename =~ /-(dev|training|test)-/)) {
	    my $full_filename = "$dir/$filename";
	    if (open(IN, $full_filename)) {
	      my $old_n_snt_ids = $n_snt_ids;
	      while (<IN>) {
		 if (($snt_id) = ($_ =~ /^#\s*::id\s+(\S+)/)) {
		    if ($old_split_class = $ht{SPLIT_CLASS}->{$snt_id}) {
		       unless ($old_split_class eq $split_class) {
		          print STDERR "Conflicting split class for $snt_id: $old_split_class $split_class\n";
		       }
		    } else {
		       $ht{SPLIT_CLASS}->{$snt_id} = $split_class;
		       $ht{SPLIT_CLASS_COUNT}->{$split_class} = ($ht{SPLIT_CLASS_COUNT}->{$split_class} || 0) + 1;
		       $n_snt_ids++;
		    }
		 }
	      }
	      $n_files++ unless $n_snt_ids == $old_n_snt_ids;
	      close(IN);
	    } else {
	       print STDERR "Can't open file $full_filename";
	    }
	 } else {
	    print STDERR "Skipping file $filename when extracting split info from $dir\n"; 
	 }
      }
      print STDERR "Extracted $n_snt_ids split classes from $n_files files.\n";
   } else {
      print STDERR "Can't open directory $dir to extract split info.\n";
   }
}

sub extract_toks_for_split_class_from_dir {
   local($this, $dir, *ht, $split_class, $control) = @_;

   $control = "" unless defined($control);
   $print_snt_id_p = ($control =~ /\bwith-snt-id\b/);
   my $n_files = 0;
   my $n_snts = 0;
   if (opendir(DIR, $dir)) {
      my @filenames = sort readdir(DIR);
      closedir(DIR);
      foreach $filename (@filenames) {
	 next unless $filename =~ /^alignment-release-.*\.txt$/;
	 my $full_filename = "$dir/$filename";
	 if (open(IN, $full_filename)) {
	    my $old_n_snts = $n_snts;
	    my $snt_id = "";
	    while (<IN>) {
	       if (($s_value) = ($_ =~ /^#\s*::id\s+(\S+)/)) {
		  $snt_id = $s_value;
		  $proper_split_class_p
	              = ($this_split_class = $ht{SPLIT_CLASS}->{$snt_id})
		     && ($this_split_class eq $split_class);
	       } elsif (($tok) = ($_ =~ /^#\s*::tok\s+(\S|\S.*\S)\s*$/)) {
		  if ($proper_split_class_p) {
		     print "$snt_id " if $print_snt_id_p;
		     print "$tok\n";
		     $n_snts++;
		  }
	       }
	    }
	    $n_files++ unless $n_snts == $old_n_snts;
	    close(IN);
	 } else {
	    print STDERR "Can't open file $full_filename";
	 }
      }
      print STDERR "Extracted $n_snts tokenized sentences ($split_class) from $n_files files.\n";
   } else {
      print STDERR "Can't open directory $dir to extract tokens.\n";
   }
}

sub load_relevant_tok_ngram_corpus {
   local($this, $filename, *ht, $max_lex_rule_span, $ngram_count_min, $optional_ngram_output_filename) = @_;

   $ngram_count_min = 1 unless $ngram_count_min;
   $max_lex_rule_span = 10 unless $max_lex_rule_span;
   my $n_ngram_instances = 0;
   my $n_ngram_types = 0;
   if (open(IN, $filename)) {
      while (<IN>) {
	 s/\s*$//;
	 @tokens = split(/\s+/, $_);
	 foreach $from_token_index ((0 .. $#tokens)) {
	    foreach $to_token_index (($from_token_index .. ($from_token_index + $max_lex_rule_span -1))) {
	       last if $to_token_index > $#tokens;
	       my $ngram = join(" ", @tokens[$from_token_index .. $to_token_index]);
	       $ht{RELEVANT_NGRAM}->{$ngram} = ($ht{RELEVANT_NGRAM}->{$ngram} || 0) + 1;
	    }
	 }
      }
      close(IN);
      if ($optional_ngram_output_filename && open(OUT, ">$optional_ngram_output_filename")) {
	 foreach $ngram (sort keys %{$ht{RELEVANT_NGRAM}}) {
	    $count = $ht{RELEVANT_NGRAM}->{$ngram};
	    next unless $count >= $ngram_count_min;
	    print OUT "($count) $ngram\n";
	    $n_ngram_types++;
	    $n_ngram_instances += $count;
	 }
	 close(OUT);
         print STDERR "Extracted $n_ngram_types ngram types, $n_ngram_instances ngram instances.\n";
         print STDERR "Wrote ngram stats to $optional_ngram_output_filename\n";
      }
   } else {
      print STDERR "Can't open relevant tok ngram corpus $filename\n";
   }
}

sub load_relevant_tok_ngrams {
   local($this, $filename, *ht) = @_;

   my $n_entries = 0;
   if (open(IN, $filename)) {
      while (<IN>) {
	 s/\s*$//;
	 if (($count, $ngram) = ($_ =~ /^\((\d+)\)\s+(\S|\S.*\S)\s*$/)) {
	    $lc_ngram = lc $ngram;
	    $ht{RELEVANT_NGRAM}->{$lc_ngram} = ($ht{RELEVANT_NGRAM}->{$lc_ngram} || 0) + $count;
	    $ht{RELEVANT_LC_NGRAM}->{$lc_ngram} = ($ht{RELEVANT_LC_NGRAM}->{$lc_ngram} || 0) + $count;
	    $n_entries++;
	 }
      }
      close(IN);
      print STDERR "Read in $n_entries entries from $filename\n";
   } else {
      print STDERR "Can't open relevant tok ngrams from $filename\n";
   }
}

sub snt_id_sort_function {
   local($this, $a, $b) = @_;

   if ((($core_a, $index_a) = ($a =~ /^(\S+)\.(\d+)$/))
    && (($core_b, $index_b) = ($b =~ /^(\S+)\.(\d+)$/))) {
      return ($core_a cmp $core_b) || ($index_a <=> $index_b);
   } else {
      return $a cmp $b;
   }
}

sub count_value_sort_function {
   local($this, $a_count, $b_count, $a_value, $b_value, $control) = @_;

   # normalize fractions such as "1/2"
   if ($a_count > $b_count) {
      return ($control eq "decreasing") ? -1 : 1;
   } elsif ($b_count > $a_count) {
      return ($control eq "decreasing") ? 1 : -1;
   }
   $a_value = $num / $den if ($num, $den) = ($a_value =~ /^([1-9]\d*)\/([1-9]\d*)$/);
   $b_value = $num / $den if ($num, $den) = ($b_value =~ /^([1-9]\d*)\/([1-9]\d*)$/);
   $a_value =~ s/:/\./ if $a_value =~ /^\d+:\d+$/;
   $b_value =~ s/:/\./ if $b_value =~ /^\d+:\d+$/;
   if (($a_value =~ /^-?\d+(\.\d+)?$/)
    && ($b_value =~ /^-?\d+(\.\d+)?$/)) {
      return $a_value <=> $b_value;
   } elsif ($a_value =~ /^-?\d+(\.\d+)?$/) {
      return 1;
   } elsif ($b_value =~ /^-?\d+(\.\d+)?$/) {
      return -1;
   } else {
      return $a_value cmp $b_value;
   }
}

sub undef_to_blank {
   local($this, $x) = @_;

   return (defined($x)) ? $x : "";
}

sub en_lex_amr_list {
   local($this, $s) = @_;

   $bpe = qr{ \( (?: (?> [^()]+ ) | (??{ $bpe }))* \) }x; # see Perl Cookbook 2nd ed. p. 218
   @en_lex_amr_list = ();
   my $amr_s;
   my $lex;
   my $test;
   while ($s =~ /\S/) {
      $s =~ s/^\s*//;
      if (($s =~ /^\([a-z]\d* .*\)/)
       && (($amr_s, $rest) = ($s =~ /^($bpe)(\s.*|)$/))) {
	 push(@en_lex_amr_list, $amr_s);
	 $s = $rest;
      } elsif (($lex, $rest) = ($s =~ /^\s*(\S+)(\s.*|)$/)) {
	 push(@en_lex_amr_list, $lex);
	 $s = $rest;
      } else {
	 print STDERR "en_lex_amr_list can't process: $s\n";
	 $s = "";
      }
   }
   return @en_lex_amr_list;
}

sub make_sure_dir_exists {
   local($this, $dir, $umask) = @_;

   mkdir($dir, $umask) unless -d $dir;
   chmod($umask, $dir);
}

sub pretty_percentage {
   local($this, $numerator, $denominator) = @_;

   return ($denominator == 0) ? "n/a" : ($this->round_to_n_decimal_places(100*$numerator/$denominator, 2) . "%");
}

sub html_color_nth_line {
   local($this, $s, $n, $color, $delimiter) = @_;

   $delimiter = "<br>" unless defined($delimiter);
   @lines = split($delimiter, $s);
   $lines[$n] = "<font color=\"$color\">" . $lines[$n] . "</font>" if ($n =~ /^\d+$/) && ($n <= $#lines);
   return join($delimiter, @lines);
}

sub likely_valid_url_format {
   local($this, $url) = @_;
    
   $url = lc $url;
   return 0 if $url =~ /\s/;
   return 0 if $url =~ /[@]/;
   return 1 if $url =~ /^https?:\/\/.+\.[a-z]+(\?.+)?$/;
   return 1 if $url =~ /[a-z].+\.(com|edu|gov|net|org)$/;
   return 0;
}

# see also EnglMorph->special_token_type
$common_file_suffixes = "aspx?|bmp|cgi|docx?|gif|html?|jpeg|jpg|mp3|mp4|pdf|php|png|pptx?|stm|svg|txt|xml";
$common_top_domain_suffixes = "museum|info|cat|com|edu|gov|int|mil|net|org|ar|at|au|be|bg|bi|br|ca|ch|cn|co|cz|de|dk|es|eu|fi|fr|gr|hk|hu|id|ie|il|in|ir|is|it|jp|ke|kr|lu|mg|mx|my|nl|no|nz|ph|pl|pt|ro|rs|ru|rw|se|sg|sk|so|tr|tv|tw|tz|ua|ug|uk|us|za";

sub token_is_url_p {
   local($this, $token) = @_;

   return 1 if $token =~ /^www(\.[a-z0-9]([-a-z0-9_]|\xC3[\x80-\x96\x98-\xB6\xB8-\xBF])+)+\.([a-z]{2,2}|$common_top_domain_suffixes)(\/(\.{1,3}|[a-z0-9]([-a-z0-9_%]|\xC3[\x80-\x96\x98-\xB6\xB8-\xBF])+))*(\/[a-z0-9_][-a-z0-9_]+\.($common_file_suffixes))?$/i;
   return 1 if $token =~ /^https?:\/\/([a-z]\.)?([a-z0-9]([-a-z0-9_]|\xC3[\x80-\x96\x98-\xB6\xB8-\xBF])+\.)+[a-z]{2,}(\/(\.{1,3}|([-a-z0-9_%]|\xC3[\x80-\x96\x98-\xB6\xB8-\xBF])+))*(\/[a-z_][-a-z0-9_]+\.($common_file_suffixes))?$/i;
   return 1 if $token =~ /^[a-z][-a-z0-9_]+(\.[a-z][-a-z0-9_]+)*\.($common_top_domain_suffixes)(\/[a-z0-9]([-a-z0-9_%]|\xC3[\x80-\x96\x98-\xB6\xB8-\xBF])+)*(\/[a-z][-a-z0-9_]+\.($common_file_suffixes))?$/i;
   return 0;
}

sub token_is_email_p {
   local($this, $token) = @_;

   return ($token =~ /^[a-z][-a-z0-9_]+(\.[a-z][-a-z0-9_]+)*\@[a-z][-a-z0-9_]+(\.[a-z][-a-z0-9_]+)*\.($common_top_domain_suffixes)$/i);
}

sub token_is_filename_p {
   local($this, $token) = @_;

   return 1 if $token =~ /\.($common_file_suffixes)$/;
   return 0; 
}

sub token_is_xml_token_p {
   local($this, $token) = @_;

   return ($token =~ /^&(amp|apos|gt|lt|nbsp|quot|&#\d+|&#x[0-9A-F]+);$/i);
}

sub token_is_handle_p {
   local($this, $token) = @_;

   return ($token =~ /^\@[a-z][_a-z0-9]*[a-z0-9]$/i);
}

sub min {
   local($this, @list) = @_;

   my $min = "";
   foreach $item (@list) {
      $min = $item if ($item =~ /^-?\d+(?:\.\d*)?$/) && (($min eq "") || ($item < $min));
   }
   return $min;
}

sub max {
   local($this, @list) = @_;

   my $max = "";
   foreach $item (@list) {
      $max = $item if defined($item) && ($item =~ /^-?\d+(?:\.\d*)?(e[-+]\d+)?$/) && (($max eq "") || ($item > $max));
   }
   return $max;
}

sub split_tok_s_into_tokens {
   local($this, $tok_s) = @_;

   @token_list = ();
   while (($pre, $link_token, $post) = ($tok_s =~ /^(.*?)\s*(\@?<[^<>]+>\@?)\s*(.*)$/)) {
      # generate dummy token for leading blank(s)
      if (($tok_s =~ /^\s/) && ($pre eq "") && ($#token_list < 0)) {
	 push(@token_list, "");
      } else {
         push(@token_list, split(/\s+/, $pre));
      }
      push(@token_list, $link_token);
      $tok_s = $post;
   }
   push(@token_list, split(/\s+/, $tok_s));
   return @token_list;
}

sub shuffle {
   local($this, @list) = @_;

   @shuffle_list = ();
   while (@list) {
      $len = $#list + 1;
      $rand_position = int(rand($len));
      push(@shuffle_list, $list[$rand_position]);
      splice(@list, $rand_position, 1);
   }
   $s = join(" ", @shuffle_list);
   return @shuffle_list;
}

sub timestamp_to_seconds {
   local($this, $timestamp) = @_;

   my $epochtime;
   if (($year, $month, $day, $hour, $minute, $second) = ($timestamp =~ /^(\d\d\d\d)-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)$/)) {
      $epochtime = timelocal($second, $minute, $hour, $day, $month-1, $year);
   } elsif (($year, $month, $day) = ($timestamp =~ /^(\d\d\d\d)-(\d\d)-(\d\d)$/)) {
      $epochtime = timelocal(0, 0, 0, $day, $month-1, $year);
   } elsif (($year, $month, $day, $hour, $minute, $second, $second_fraction) = ($timestamp =~ /^(\d\d\d\d)-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)\.(\d+)$/)) {
      $epochtime = timelocal($second, $minute, $hour, $day, $month-1, $year) + ($second_fraction / (10 ** length($second_fraction)));
   } else {
      $epochtime = 0;
   }
   return $epochtime;
}

sub timestamp_diff_in_seconds {
   local($this, $timestamp1, $timestamp2) = @_;

   my $epochtime1 = $this->timestamp_to_seconds($timestamp1);
   my $epochtime2 = $this->timestamp_to_seconds($timestamp2);
   return $epochtime2 - $epochtime1;
}

sub dirhash {
   # maps string to hash of length 4 with characters [a-z2-8] (shorter acc. to $len)
   local($this, $s, $len) = @_;

   $hash = 9999;
   $mega = 2 ** 20;
   $mega1 = $mega - 1;
   $giga = 2 ** 26;
   foreach $c (split //, $s) {
      $hash = $hash*33 + ord($c);
      $hash = ($hash >> 20) ^ ($hash & $mega1) if $hash >= $giga;
   }
   while ($hash >= $mega) {
      $hash = ($hash >> 20) ^ ($hash & $mega1);
   }
   $result = "";
   while ($hash) {
      $c = $hash & 31;
      $result .= CORE::chr($c + (($c >= 26) ? 24 : 97));
      $hash = $hash >> 5;
   }
   while (length($result) < 4) {
      $result .= "8";
   }
   return substr($result, 0, $len) if $len;
   return $result;
}

sub full_path_python {

   foreach $bin_path (split(":", "/usr/sbin:/usr/bin:/bin:/usr/local/bin")) {
      return $python if -x ($python = "$bin_path/python");
   }
   return "python";
}

sub string_contains_unbalanced_paras {
   local($this, $s) = @_;

   return 0 unless $s =~ /[(){}\[\]]/;
   $rest = $s;
   while (($pre,$left,$right,$post) = ($rest =~ /^(.*)([({\[]).*?([\]})])(.*)$/)) {
      return 1 unless (($left eq "(") && ($right eq ")"))
                   || (($left eq "[") && ($right eq "]"))
                   || (($left eq "{") && ($right eq "}"));
      $rest = "$pre$post";
   } 
   return 1 if $rest =~ /[(){}\[\]]/;
   return 0;
}

sub dequote_string {
   local($this, $s) = @_;

   if ($s =~ /^".*"$/)  {
      $s = substr($s, 1, -1);
      $s =~ s/\\"/"/g;
      return $s;
   } elsif ($s =~ /^'.*'$/)  {
      $s = substr($s, 1, -1);
      $s =~ s/\\'/'/g;
      return $s;
   } else {
      return $s;
   }
}

sub defined_non_space {
   local($this, $s) = @_;

   return (defined($s) && ($s =~ /\S/));
}

sub default_if_undefined {
   local($this, $s, $default) = @_;

   return (defined($s) ? $s : $default);
}

sub remove_empties {
   local($this, @list) = @_;

   @filtered_list = ();
   foreach $elem (@list) {
      push(@filtered_list, $elem) if defined($elem) && (! ($elem =~ /^\s*$/)) && (! $this->member($elem, @filtered_list));
   }

   return @filtered_list;
}

# copied from AMRexp.pm
sub new_var_for_surf_amr {
   local($this, $amr_s, $s) = @_;

   my $letter = ($s =~ /^[a-z]/i) ? lc substr($s, 0, 1) : "x";
   return $letter unless ($amr_s =~ /:\S+\s+\($letter\s+\//)
                      || ($amr_s =~ /\s\($letter\s+\//)
                      || ($amr_s =~ /^\s*\($letter\s+\//); # )))
   my $i = 2;
   while (($amr_s =~ /:\S+\s+\($letter$i\s+\//)
       || ($amr_s =~ /\s+\($letter$i\s+\//)
       || ($amr_s =~ /^\s*\($letter$i\s+\//)) { # )))
      $i++;
   }
   return "$letter$i";
}

# copied from AMRexp.pm
sub new_vars_for_surf_amr {
   local($this, $amr_s, $ref_amr_s) = @_;

   my $new_amr_s = "";
   my %new_var_ht = ();
   my $remaining_amr_s = $amr_s;
   my $pre; my $var; my $concept; my $post;
   while (($pre, $var, $concept, $post) = ($remaining_amr_s =~ /^(.*?\()([a-z]\d*)\s+\/\s+([^ ()\s]+)(.*)$/s)) {
      $new_var = $this->new_var_for_surf_amr("$ref_amr_s $new_amr_s", $concept);
      $new_var_ht{$var} = $new_var;
      $new_amr_s .= "$pre$new_var / $concept";
      $remaining_amr_s = $post;
   }
   $new_amr_s .= $remaining_amr_s;

   # also update any reentrancy variables
   $remaining_amr_s = $new_amr_s;
   $new_amr_s2 = "";
   while (($pre, $var, $post) = ($remaining_amr_s =~ /^(.*?:\S+\s+)([a-z]\d*)([ ()\s].*)$/s)) {
      $new_var = $new_var_ht{$var} || $var;
      $new_amr_s2 .= "$pre$new_var";
      $remaining_amr_s = $post;
   }
   $new_amr_s2 .= $remaining_amr_s;

   return $new_amr_s2;
}

sub update_inner_span_for_id {
   local($this, $html_line, $slot, $new_value) = @_;
   # e.g. slot: workset-language-name value: Uyghur

   if (defined($new_value)
    && (($pre, $old_value, $post) = ($html_line =~ /^(.*<span\b[^<>]* id="$slot"[^<>]*>)([^<>]*)(<\/span\b[^<>]*>.*)$/i))
    && ($old_value ne $new_value)) {
      # print STDERR "Inserting new $slot $old_value -> $new_value\n";
      return $pre . $new_value . $post . "\n";
   } else {
      # no change
      return $html_line;
   } 
}

sub levenshtein_distance {
   local($this, $s1, $s2) = @_;

   my $i; 
   my $j;
   my @distance;
   my @s1_chars = $utf8->split_into_utf8_characters($s1, "return only chars", *empty_ht);
   my $s1_length = $#s1_chars + 1;
   my @s2_chars = $utf8->split_into_utf8_characters($s2, "return only chars", *empty_ht);
   my $s2_length = $#s2_chars + 1;
   for ($i = 0; $i <= $s1_length; $i++) {
      $distance[$i][0] = $i;
   }
   for ($j = 1; $j <= $s2_length; $j++) {
      $distance[0][$j] = $j;
   }
   for ($j = 1; $j <= $s2_length; $j++) {
      for ($i = 1; $i <= $s1_length; $i++) {
	 my $substitution_cost = ($s1_chars[$i-1] eq $s2_chars[$j-1]) ? 0 : 1;
         $distance[$i][$j] = $this->min($distance[$i-1][$j] + 1,
				        $distance[$i][$j-1] + 1,
				        $distance[$i-1][$j-1] + $substitution_cost);
	 # print STDERR "SC($i,$j) = $substitution_cost\n";
	 # $d = $distance[$i][$j];
	 # print STDERR "D($i,$j) = $d\n";
      }
   }
   return $distance[$s1_length][$s2_length];
}

sub markup_parts_of_string_in_common_with_ref {
   local($this, $s, $ref, $start_markup, $end_markup, $deletion_markup, $verbose) = @_;

   # \x01 temporary start-markup
   # \x02 temporary end-markup
   # \x03 temporary deletion-markup
   $s =~ s/[\x01-\x03]//g;
   $ref =~ s/[\x01-\x03]//g;
   my $i; 
   my $j;
   my @distance;
   my @s_chars = $utf8->split_into_utf8_characters($s, "return only chars", *empty_ht);
   my $s_length = $#s_chars + 1;
   my @ref_chars = $utf8->split_into_utf8_characters($ref, "return only chars", *empty_ht);
   my $ref_length = $#ref_chars + 1;
   $distance[0][0] = 0;
   $del_ins_subst_op[0][0] = "-";
   for ($i = 1; $i <= $s_length; $i++) {
      $distance[$i][0] = $i;
      $del_ins_subst_op[$i][0] = 0;
   }
   for ($j = 1; $j <= $ref_length; $j++) {
      $distance[0][$j] = $j;
      $del_ins_subst_op[0][$j] = 1;
   }
   for ($j = 1; $j <= $ref_length; $j++) {
      for ($i = 1; $i <= $s_length; $i++) {
	 my $substitution_cost = (($s_chars[$i-1] eq $ref_chars[$j-1])) ? 0 : 1;
	 my @del_ins_subst_list = ($distance[$i-1][$j] + 1,
	                           $distance[$i][$j-1] + 1,
			           $distance[$i-1][$j-1] + $substitution_cost);
         my $min = $this->min(@del_ins_subst_list);
	 my $del_ins_subst_position = $this->position($min, @del_ins_subst_list);
	 $distance[$i][$j] = $min;
	 $del_ins_subst_op[$i][$j] = $del_ins_subst_position;
      }
   }
   $d = $distance[$s_length][$ref_length];
   print STDERR "markup_parts_of_string_in_common_with_ref LD($s,$ref) = $d\n" if $verbose;
   for ($j = 0; $j <= $ref_length; $j++) {
      for ($i = 0; $i <= $s_length; $i++) {
	 $d = $distance[$i][$j];
	 $op = $del_ins_subst_op[$i][$j];
	 print STDERR "$d($op) " if $verbose;
      }
      print STDERR "\n" if $verbose;
   }
   my $result = "";
   my $i_end = $s_length;
   my $j_end = $ref_length;
   my $cost = $distance[$i_end][$j_end];
   $i = $i_end;
   $j = $j_end;
   while (1) {
      $result2 = $result;
      $result2 =~ s/\x01/$start_markup/g;
      $result2 =~ s/\x02/$end_markup/g;
      $result2 =~ s/\x03/$deletion_markup/g;
      print STDERR "i:$i i-end:$i_end  j:$j j-end:$j_end  r: $result2\n" if $verbose;
      # matching characters
      if ($i && $j && ($del_ins_subst_op[$i][$j] == 2) && ($distance[$i-1][$j-1] == $distance[$i][$j])) {
	 $i--;
	 $j--;
      } else {
         # previously matching characters
	 if (($i < $i_end) && ($j < $j_end)) {
	    my $sub_s = join("", @s_chars[$i .. $i_end-1]);
	    $result = "\x01" . $sub_s . "\x02" . $result;
	 }
         # character substitution
         if ($i && $j && ($del_ins_subst_op[$i][$j] == 2)) {
	    $i--;
	    $j--;
	    $result = $s_chars[$i] . $result;
	 } elsif ($i && ($del_ins_subst_op[$i][$j] == 0)) {
	    $i--;
	    $result = $s_chars[$i] . $result;
	 } elsif ($j && ($del_ins_subst_op[$i][$j] == 1)) {
	    $j--;
	    $result = "\x03" . $result;
	 } else {
	    last;
	 }
	 $i_end = $i;
	 $j_end = $j;
      }
   }
   $result2 = $result;
   $result2 =~ s/\x01/$start_markup/g;
   $result2 =~ s/\x02/$end_markup/g;
   $result2 =~ s/\x03/$deletion_markup/g;
   print STDERR "i:$i i-end:$i_end  j:$j j-end:$j_end  r: $result2 *\n" if $verbose;
   $result =~ s/(\x02)\x03+(\x01)/$1$deletion_markup$2/g;
   $result =~ s/(\x02)\x03+$/$1$deletion_markup/g;
   $result =~ s/^\x03+(\x01)/$deletion_markup$1/g;
   $result =~ s/\x03//g;
   $result =~ s/\x01/$start_markup/g;
   $result =~ s/\x02/$end_markup/g;
   return $result;
}

sub env_https {
   my $https = $ENV{'HTTPS'};
   return 1 if $https && ($https eq "on");

   my $http_via = $ENV{'HTTP_VIA'};
   return 1 if $http_via && ($http_via =~ /\bHTTPS\b.* \d+(?:\.\d+){3,}:443\b/); # tmp for beta.isi.edu

   return 0;
}

sub env_http_host {
   return $ENV{'HTTP_HOST'} || "";
}

sub env_script_filename {
   return $ENV{'SCRIPT_FILENAME'} || "";
}

sub cgi_mt_app_root_dir {
   local($this, $target) = @_;
   my $s;
   if ($target =~ /filename/i) {
      $s = $ENV{'SCRIPT_FILENAME'} || "";
   } else {
      $s = $ENV{'SCRIPT_NAME'} || "";
   }
   return "" unless $s;
   return $d if ($d) = ($s =~ /^(.*?\/(?:amr-editor|chinese-room-editor|utools|romanizer\/version\/[-.a-z0-9]+|romanizer))\//);
   return $d if ($d) = ($s =~ /^(.*)\/(?:bin|src|scripts?)\/[^\/]*$/);
   return $d if ($d) = ($s =~ /^(.*)\/[^\/]*$/);
   return "";
}

sub parent_dir {
   local($this, $dir) = @_;

   $dir =~ s/\/[^\/]+\/?$//;
   return $dir || "/";
}

sub span_start {
   local($this, $span, $default) = @_;

   $default = "" unless defined($default);
   return (($start) = ($span =~ /^(\d+)-\d+$/)) ? $start : $default;
}

sub span_end {
   local($this, $span, $default) = @_;

   $default = "" unless defined($default);
   return (($end) = ($span =~ /^\d+-(\d+)$/)) ? $end : $default;
}

sub oct_mode {
   local($this, $filename) = @_;

   @stat = stat($filename);
   return "" unless @stat;
   $mode = $stat[2];
   $oct_mode = sprintf("%04o", $mode & 07777);
   return $oct_mode;
}

sub csv_to_list {
   local($this, $s, $control_string) = @_;
   # Allow quoted string such as "Wait\, what?" as element with escaped comma inside.

   $control_string = "" unless defined($control_string);
   $strip_p = ($control_string =~ /\bstrip\b/);
   $allow_simple_commas_in_quote = ($control_string =~ /\bsimple-comma-ok\b/);
   $ignore_empty_elem_p = ($control_string =~ /\bno-empty\b/);
   @cvs_list = ();
   while ($s ne "") {
      if ((($elem, $rest) = ($s =~ /^"((?:\\[,\"]|[^,\"][\x80-\xBF]*)*)"(,.*|)$/))
       || ($allow_simple_commas_in_quote
        && (($elem, $rest) = ($s =~ /^"((?:\\[,\"]|[^\"][\x80-\xBF]*)*)"(,.*|)$/)))
       || (($elem, $rest) = ($s =~ /^([^,]*)(,.*|\s*)$/))
       || (($elem, $rest) = ($s =~ /^(.*)()$/))) {
	 if ($strip_p) { 
	    $elem =~ s/^\s*//; 
	    $elem =~ s/\s*$//;
	 }
	 push(@cvs_list, $elem) unless $ignore_empty_elem_p && ($elem eq "");
	 $rest =~ s/^,//;
	 $s = $rest;
      } else {
	 print STDERR "Error in csv_to_list processing $s\n";
	 last;
      }
   }
   return @cvs_list;
}

sub kl_divergence {
   local($this, $distribution_id, $gold_distribution_id, *ht, $smoothing) = @_;

   my $total_count = $ht{DISTRIBUTION_TOTAL_COUNT}->{$distribution_id};
   my $total_gold_count = $ht{DISTRIBUTION_TOTAL_COUNT}->{$gold_distribution_id};
   return unless $total_count && $total_gold_count;

   my @values = keys %{$ht{DISTRIBUTION_VALUE_COUNT}->{$gold_distribution_id}};
   my $n_values = $#values + 1;

   my $min_total_count = $this->min($total_count, $total_gold_count);
   $smoothing = 1 - (10000/((100+$min_total_count)**2)) unless defined($smoothing);
   return unless $smoothing;
   my $smoothed_n_values = $smoothing * $n_values;
   my $divergence = 0;
   foreach $value (@values) {
      my $count = $ht{DISTRIBUTION_VALUE_COUNT}->{$distribution_id}->{$value} || 0;
      my $gold_count = $ht{DISTRIBUTION_VALUE_COUNT}->{$gold_distribution_id}->{$value};
      my $p = ($count + $smoothing) / ($total_count + $smoothed_n_values);
      my $q = ($gold_count + $smoothing) / ($total_gold_count + $smoothed_n_values);
      if ($p == 0) {
         # no impact on divergence
      } elsif ($q) {
         my $incr = $p * CORE::log($p/$q);
         $divergence += $incr;
	 my $incr2 = $this->round_to_n_decimal_places($incr, 5);
	 my $p2    = $this->round_to_n_decimal_places($p, 5);
	 my $q2    = $this->round_to_n_decimal_places($q, 5);
	 $incr2 = "+" . $incr2 if $incr > 0;
         $log = "    value: $value count: $count gold_count: $gold_count p: $p2 q: $q2 $incr2\n";
         $ht{KL_DIVERGENCE_LOG}->{$distribution_id}->{$gold_distribution_id}->{$value} = $log;
         $ht{KL_DIVERGENCE_INCR}->{$distribution_id}->{$gold_distribution_id}->{$value} = $incr;
      } else {
         $divergence += 999;
      }
   }
   return $divergence;
}

sub read_ISO_8859_named_entities {
   local($this, *ht, $filename, $verbose) = @_;
   # e.g. from /nfs/isd/ulf/arabic/data/ISO-8859-1-HTML-named-entities.txt
   # <!ENTITY quot   CDATA "&#34;"   -- quotation mark, =apl quote, u+0022 ISOnum -->
   # <!ENTITY nbsp   CDATA "&#160;"  -- no-break space -->
   # <!ENTITY eacute CDATA "&#233;"  -- small e, acute accent -->
   # <!ENTITY Alpha  CDATA "&#913;"  -- greek capital letter alpha,  u+0391 -->
   # <!ENTITY alpha  CDATA "&#945;"  -- greek small letter alpha, u+03B1 ISOgrk3 -->
   # <!ENTITY dagger CDATA "&#8224;" -- dagger, u+2020 ISOpub -->

   my $n = 0;
   if (open(IN, $filename)) {
      while (<IN>) {
	 s/^\xEF\xBB\xBF//;
	 if (($name, $dec_unicode) = ($_ =~ /^<!ENTITY\s+([a-z]{2,6})\s+CDATA\s+"&#(\d{1,5});"/)) {
	    $ht{HTML_ENTITY_NAME_TO_DECUNICODE}->{$name} = $dec_unicode;
	    $ht{HTML_ENTITY_DECUNICODE_TO_NAME}->{$dec_unicode} = $name;
	    $ht{HTML_ENTITY_NAME_TO_UTF8}->{$name} = $utf8->unicode2string($dec_unicode);
	    $n++;
	  # print STDERR "read_ISO_8859_named_entities $name $dec_unicode .\n" if $name =~ /dash/;
	 }
      }
      close(IN);
      print STDERR "Loaded $n entries from $filename\n" if $verbose;
   } else {
      print STDERR "Could not open $filename\n" if $verbose;
   }
}

sub neg {
   local($this, $x) = @_;

   # robust
   return (defined($x) && ($x =~ /^-?\d+(?:\.\d+)?$/)) ? (- $x) : $x;
}

sub read_ttable_gloss_data {
   local($this, $filename, $lang_code, *ht, $direction) = @_;
   # e.g. /nfs/isd/ulf/croom/oov-lanpairs/som-eng/som-eng-ttable-glosses.txt

   $direction = "f to e" unless defined($direction);
   if (open(IN, $filename)) {
      while (<IN>) {
	 if (($headword, $gloss) = ($_ =~ /^(.*?)\t(.*?)\s*$/)) {
	    if ($direction eq "e to f") {
               $ht{TTABLE_E_GLOSS}->{$lang_code}->{$headword} = $gloss;
	    } else {
               $ht{TTABLE_F_GLOSS}->{$lang_code}->{$headword} = $gloss;
	    }
	 }
      }
      close(IN);
   }
}

sub format_gloss_for_tooltop {
   local($this, $gloss) = @_;

   $gloss =~ s/^\s*/\t/;
   $gloss =~ s/\s*$//;
   $gloss =~ s/ /  /g;
   $gloss =~ s/\t/&#xA;  /g;
   return $gloss;
}

sub obsolete_tooltip {
   local($this, $s, $lang_code, *ht) = @_;

   return $gloss if defined($gloss = $ht{TTABLE_F_GLOSS}->{$lang_code}->{$s});
   @e_s = sort { $ht{T_TABLE_F_E_C}->{$lang_code}->{$s}->{$b}
            <=>  $ht{T_TABLE_F_E_C}->{$lang_code}->{$s}->{$a} }
               keys %{$ht{T_TABLE_F_E_C}->{$lang_code}->{$s}};
   if (@e_s) {
      $e = shift @e_s;
      $count = $ht{T_TABLE_F_E_C}->{$lang_code}->{$s}->{$e};
      $min_count = $this->max($count * 0.01, 1.0);
      $count =~ s/(\.\d\d)\d*$/$1/;
      $result = "$s:&#xA;  $e  ($count)";
      $n = 1;
      while (@e_s) {
         $e = shift @e_s;
         $count = $ht{T_TABLE_F_E_C}->{$lang_code}->{$s}->{$e};
	 last if $count < $min_count;
	 $count =~ s/(\.\d\d)\d*$/$1/;
	 $result .= "&#xA;  $e  ($count)";
	 $n++;
         last if $n >= 10;
      }
      $ht{TTABLE_F_GLOSS}->{$lang_code}->{$s} = $result;
      return $result;
   } else {
      return "";
   }
}

sub markup_html_line_init {
   local($this, $s, *ht, $id) = @_;

   my @chars = $utf8->split_into_utf8_characters($s, "return only chars", *empty_ht);
   $ht{S}->{$id} = $s;
}

sub markup_html_line_regex {
   local($this, $id, *ht, $regex, $m_slot, $m_value, *LOG) = @_;

   unless ($regex eq "") {
      my $s = $ht{S}->{$id};
      my $current_pos = 0;
      while (($pre, $match_s, $post) = ($s =~ /^(.*?)($regex)(.*)$/)) {
         $current_pos += $utf8->length_in_utf8_chars($pre);
         my $match_len = $utf8->length_in_utf8_chars($match_s);
         $ht{START}->{$id}->{$current_pos}->{$m_slot}->{$m_value} = 1;
         $ht{STOP}->{$id}->{($current_pos+$match_len)}->{$m_slot}->{$m_value} = 1;
         $current_pos += $match_len;
         $s = $post;
      }
   }
}

sub html_markup_line {
   local($this, $id, *ht, *LOG) = @_;

   my @titles = ();
   my @colors = ();
   my @text_decorations = ();

   my $s = $ht{S}->{$id};
 # print LOG "html_markup_line $id: $s\n";
   my @chars = $utf8->split_into_utf8_characters($s, "return only chars", *empty_ht);
   my $markedup_s = "";
 
   my $new_title = "";
   my $new_color = "";
   my $new_text_decoration = "";
   my $n_spans = 0;
   my $i;
   foreach $i ((0 .. ($#chars+1))) {
      my $stop_span_p = 0;
      foreach $m_slot (keys %{$ht{STOP}->{$id}->{$i}}) {
         foreach $m_value (keys %{$ht{STOP}->{$id}->{$i}->{$m_slot}}) {
	    if ($m_slot eq "title") {
	       my $last_positition = $this->last_position($m_value, @titles);
	       splice(@titles, $last_positition, 1) if $last_positition >= 0;
	       $stop_span_p = 1;
	    } elsif ($m_slot eq "color") {
	       my $last_positition = $this->last_position($m_value, @colors);
	       splice(@colors, $last_positition, 1) if $last_positition >= 0;
	       $stop_span_p = 1;
	    } elsif ($m_slot eq "text-decoration") {
	       my $last_positition = $this->last_position($m_value, @text_decorations);
	       splice(@text_decorations, $last_positition, 1) if $last_positition >= 0;
	       $stop_span_p = 1;
	    }
	 }
      }
      if ($stop_span_p) {
	 $markedup_s .= "</span>";
	 $n_spans--;
      }
      my $start_span_p = 0;
      foreach $m_slot (keys %{$ht{START}->{$id}->{$i}}) {
         foreach $m_value (keys %{$ht{START}->{$id}->{$i}->{$m_slot}}) {
	    if ($m_slot eq "title") {
	       push(@titles, $m_value);
               $start_span_p = 1;
	    } elsif ($m_slot eq "color") {
	       push(@colors, $m_value);
               $start_span_p = 1;
	    } elsif ($m_slot eq "text-decoration") {
	       push(@text_decorations, $m_value);
               $start_span_p = 1;
	    }
         }
      }
      if ($stop_span_p || $start_span_p) {
	 my $new_title = (@titles) ? $titles[$#titles] : "";
	 my $new_color = (@colors) ? $colors[$#colors] : "";
	 my $new_text_decoration = (@text_decorations) ? $text_decorations[$#text_decorations] : "";
	 if ($new_title || $new_color || $new_text_decoration) {
	    my $args = "";
	    if ($new_title) {
	       $g_title = $this->guard_html_quote($new_title);
	       $args .= " title=\"$g_title\"";
	    }
	    if ($new_color || $new_text_decoration) {
	       $g_color = $this->guard_html_quote($new_color);
	       $g_text_decoration = $this->guard_html_quote($new_text_decoration);
	       $color_clause = ($new_color) ? "color:$g_color;" : "";
	       $text_decoration_clause = ($new_text_decoration) ? "text-decoration:$g_text_decoration;" : "";
	       $text_decoration_clause =~ s/text-decoration:(border-bottom:)/$1/g;
	       $args .= " style=\"$color_clause$text_decoration_clause\"";
	    }
	    if ($n_spans) {
	       $markedup_s .= "</span>";
	       $n_spans--;
	    }
	    $markedup_s .= "<span$args>";
            $n_spans++;
         }
      }
      $markedup_s .= $chars[$i] if $i <= $#chars;
   }
   print LOG "Error in html_markup_line $id final no. of open spans: $n_spans\n" if $n_spans && $tokenization_log_verbose;
   return $markedup_s;
}

sub offset_adjustment {
   local($this, $g, $s, $offset, $snt_id, *ht, *LOG, $control) = @_;
   # s(tring)        e.g. "can't"
   # g(old string)   e.g. "can not"
   # Typically when s is a slight variation of g (e.g. with additional tokenization spaces in s)
   # returns mapping 0->0, 1->1, 2->2, 3->3, 6->4, 7->5

   $control = "" unless defined($control);
   my $verbose = ($control =~ /\bverbose\b/);
   my $s_offset = 0;
   my $g_offset = 0;
   my @s_chars = $utf8->split_into_utf8_characters($s, "return only chars", *ht);
   my @g_chars = $utf8->split_into_utf8_characters($g, "return only chars", *ht);
   my $s_len = $#s_chars + 1;
   my $g_len = $#g_chars + 1;
   $ht{OFFSET_MAP}->{$snt_id}->{$offset}->{$s_offset} = $g_offset;
   $ht{OFFSET_MAP}->{$snt_id}->{$offset}->{($s_offset+$s_len)} = $g_offset+$g_len;

   while (($s_offset < $s_len) && ($g_offset < $g_len)) {
      if ($s_chars[$s_offset] eq $g_chars[$g_offset]) {
	 $s_offset++;
	 $g_offset++;
	 $ht{OFFSET_MAP}->{$snt_id}->{$offset}->{$s_offset} = $g_offset;
      } else {
         my $best_gm = 0;
         my $best_sm = 0;
         my $best_match_len = 0;
         foreach $max_m ((1 .. 4)) {
            foreach $sm ((0 .. $max_m)) {
	       $max_match_len = 0;
	       while ((($s_index = $s_offset+$sm+$max_match_len) < $s_len)
	           && (($g_index = $g_offset+$max_m+$max_match_len) < $g_len)) {
	          if ($s_chars[$s_index] eq $g_chars[$g_index]) {
	             $max_match_len++;
	          } else {
	             last;
	          }
	       }
	       if ($max_match_len > $best_match_len) {
	          $best_match_len = $max_match_len;
	          $best_sm = $sm;
	          $best_gm = $max_m;
               }
	    }
            foreach $gm ((0 .. $max_m)) {
	       $max_match_len = 0;
	       while ((($s_index = $s_offset+$max_m+$max_match_len) < $s_len)
	           && (($g_index = $g_offset+$gm+$max_match_len) < $g_len)) {
	          if ($s_chars[$s_index] eq $g_chars[$g_index]) {
	             $max_match_len++;
	          } else {
	             last;
	          }
	       }
	       if ($max_match_len > $best_match_len) {
	          $best_match_len = $max_match_len;
	          $best_sm = $max_m;
	          $best_gm = $gm;
	       }
	    }
         }
	 if ($best_match_len) {
	    $s_offset += $best_sm;
	    $g_offset += $best_gm;
	    $ht{OFFSET_MAP}->{$snt_id}->{$offset}->{$s_offset} = $g_offset;
	 } else {
	    last;
	 }
      }
   }
   if ($verbose) {
      foreach $s_offset (sort { $a <=> $b }
			      keys %{$ht{OFFSET_MAP}->{$snt_id}->{$offset}}) {
         my $g_offset = $ht{OFFSET_MAP}->{$snt_id}->{$offset}->{$s_offset};
         print LOG "   OFFSET_MAP $snt_id.$offset $s/$g $s_offset -> $g_offset\n" if $tokenization_log_verbose;
      }
   }
}

# TOKENIZATION

my $tokenization_log_verbose = 0;
sub load_tokenization_file {
   local($this, *ht, $filename, *LOG, $verbose, $load_spelling_correction_p) = @_;

   # e.g. /nfs/isd/ulf/arabic/data/tokenization-general.txt
   #      /nfs/isd/ulf/arabic/data/tokenization-eng.txt
   #      /nfs/isd/ulf/arabic/data/tokenization-fra.txt

   if (open(IN, $filename)) {
      my $line_number = 0;
      my @patterns = ();
      my $n_token_patterns = 0;
      my $n_contraction_patterns = 0;
      my $n_l_contraction_patterns = 0;
      my $n_m_contraction_patterns = 0;
      my $n_r_contraction_patterns = 0;
      my $n_vulgarities = 0;
      my $n_character_normalizations = 0;
      my $n_contraction_markers = 0;
      my $n_encoding_corrections = 0;
      my $n_separable_prefixes = 0;
      my $n_currency_prefixes = 0;
      my $n_valid_clusters = 0;
      my $n_invalid_clusters = 0;
      my $n_misspellings = 0;
      my $n_misspelling_variations = 0;
      while (<IN>) {
	 s/^\xEF\xBB\xBF//;
         $line_number++;
	 my $line = $_;
	 $line =~ s/\s*$//;
	 $line =~ s/\s+#.*$//;
	 if ($line =~ /^\s*::/) {
	    if ($line =~ /^\s*::token\s+\S/) {
               $n_token_patterns++;
	       my $token = (($value) = ($line =~ /::token\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $alt_spelling_s = (($value) = ($line =~ /::alt-spelling\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my @alt_spellings = ($alt_spelling_s) ? split(/;\s*/, $alt_spelling_s) : ();
	       my $misspelling_s = (($value) = ($line =~ /::misspelling\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my @misspellings = ($misspelling_s) ? split(/;\s*/, $misspelling_s) : ();
	       my $lang_code = (($value) = ($line =~ /::lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $etym_lang_code = (($value) = ($line =~ /::etym-lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $plural_s = (($value) = ($line =~ /::plural\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my @raw_plurals = ($plural_s) ? split(/;\s*/, $plural_s) : ();
	       my @plurals = ();
	       foreach $raw_plural (@raw_plurals) {
	          my $plural = (($plural_suffix) = ($raw_plural =~ /^\+(\S+)$/)) ? "$token$plural_suffix" : $raw_plural;
	          push(@plurals, $plural);
	       }
	       my $type = (($value) = ($line =~ /::type\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $ne_type = (($value) = ($line =~ /::named-entity-type\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $abbrev_exp_s = (($value) = ($line =~ /::abbreviation-expansion\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $taxon = (($value) = ($line =~ /::taxon\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $eng_gloss = (($value) = ($line =~ /::eng\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $left_context = (($value) = ($line =~ /::left-context\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $right_context = (($value) = ($line =~ /::right-context\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $left_typed_context = (($value) = ($line =~ /::left-typed-context\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $right_typed_context = (($value) = ($line =~ /::right-typed-context\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $add_period_if_missing_p = ($line =~ /::add-period-if-missing\b/);
	       my $case_invariant_p = ($line =~ /::case-invariant\b/);
	       if (@alt_spellings && ($alt_spellings[0] eq "+hyphen")) {
		  my $hyphened_token = $token;
                  $hyphened_token =~ s/\s+/-/g;
		  if ($hyphened_token eq $token) {
		     shift @alt_spellings;
		  } else {
		     $alt_spellings[0] = $hyphened_token;
		  }
	       }
	       my @toks = ($token, @plurals, @alt_spellings, @misspellings);
	       my $token_without_period = "";
	       if ($add_period_if_missing_p && ($token =~ /.\.$/)) {
	          $token_without_period = $token;
		  $token_without_period =~ s/\.$//;
		  push(@toks, $token_without_period);
	       }
	       foreach $tok (@toks) {
		  my $lc_tok;
		  if ($this->member($tok, @misspellings)) {
		     $lc_tok = $this->register_li_token_affixes(*ht, $tok, *LOG, $lang_code, "SPELLING_CORRECTION");
		     $ht{TOKEN_CORRECTED_SPELLING}->{$lang_code}->{$lc_tok} = $token;
		  } elsif ($this->member($tok, @alt_spellings)) {
		     $lc_tok = $this->register_li_token_affixes(*ht, $tok, *LOG, $lang_code, "SPELLING_NORMALIZATION");
		     $ht{TOKEN_NORMALIZED_SPELLING}->{$lang_code}->{$lc_tok}->{$token} = 1;
		  } else {
		     $lc_tok = $this->register_li_token_affixes(*ht, $tok, *LOG, $lang_code, "LI_TOKEN_ENTRY_P");
		  }
	          $ht{LI_TOKEN_P}->{$lang_code}->{$lc_tok} = 1;
	          $ht{LI_TOKEN_TRUE_CASE}->{$lang_code}->{$lc_tok}->{$tok} = 1;
		  $ht{LI_TOKEN_ETYM}->{$lang_code}->{$lc_tok} = $etym_lang_code if $etym_lang_code;
		  $ht{LI_TOKEN_TYPE}->{$lang_code}->{$lc_tok} = $type if $type;
		  $ht{LI_TOKEN_NE_TYPE}->{$lang_code}->{$lc_tok} = $ne_type if $ne_type;
		  if ($abbrev_exp_s) {
                     $ht{IS_ABBREVIATION_LANG}->{$lang_code}->{$tok} = 1;
                     $ht{IS_LC_ABBREVIATION_LANG}->{$lang_code}->{$lc_tok} = 1;
		     my @abbrev_exps = split(/;\s*/, $abbrev_exp_s);
		     if ($#abbrev_exps >= 0) {
			my $abbrev_exp = $abbrev_exps[0];
		        $ht{LI_TOKEN_ABBREV_EXPANSION}->{$lang_code}->{$lc_tok} = $abbrev_exp;
		     }
		     foreach $abbrev_exp (@abbrev_exps) {
                        $ht{ABBREV_EXPANSION_LANG}->{$lang_code}->{$tok}->{$abbrev_exp} = 1;
                        $ht{ABBREV_EXPANSION_LANG_OF}->{$lang_code}->{$abbrev_exp}->{$tok} = 1;
                        $ht{LC_ABBREV_EXPANSION_LANG}->{$lang_code}->{$lc_tok}->{$abbrev_exp} = 1;
                        $ht{LC_ABBREV_EXPANSION_LANG_OF}->{$lang_code}->{$abbrev_exp}->{$lc_tok} = 1;
		     }
		  }
		  $ht{CASE_INVARIANT}->{$lang_code}->{$lc_tok}->{$token} = 1 if $case_invariant_p && defined($lc_tok);
		  $ht{LI_TOKEN_TAXON}->{$lang_code}->{$lc_tok} = $taxon if $taxon;
		  $ht{LI_TOKEN_GLOSS}->{$lang_code}->{"eng"}->{$lc_tok} = $eng_gloss if $eng_gloss;
		  $ht{LI_TOKEN_LEFT_CONTEXT}->{$lang_code}->{$lc_tok} = $this->pattern_string_to_pattern($left_context) if $left_context;
		  $ht{LI_TOKEN_RIGHT_CONTEXT}->{$lang_code}->{$lc_tok} = $this->pattern_string_to_pattern($right_context) if $right_context;
		  $ht{LI_TOKEN_LEFT_TYPED_CONTEXT}->{$lang_code}->{$lc_tok} = $this->pattern_string_to_pattern($left_typed_context) if $left_typed_context;
		  $ht{LI_TOKEN_RIGHT_TYPED_CONTEXT}->{$lang_code}->{$lc_tok} = $this->pattern_string_to_pattern($right_typed_context) if $right_typed_context;
		  $ht{LI_TOKEN_ADD_ABBREV_PERIOD_IF_MISSING_P}->{$lang_code}->{$lc_tok} = 1 if $add_period_if_missing_p && ($tok eq $token_without_period);
	       }
	       foreach $tok (@plurals) {
		  $ht{LI_TOKEN_SINGULAR}->{$lang_code}->{$tok}->{$token} = 1;
	       }
	    } elsif ($line =~ /^\s*::(?:[lmr]-)?contraction\s+\S/) {
	       my $contraction = (($value) = ($line =~ /::contraction\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $l_contraction = (($value) = ($line =~ /::l-contraction\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $m_contraction = (($value) = ($line =~ /::m-contraction\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $r_contraction = (($value) = ($line =~ /::r-contraction\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $norm = (($value) = ($line =~ /::norm\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $norm2 = (($value) = ($line =~ /::norm2\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $lang_code = (($value) = ($line =~ /::lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $alignment_s = (($value) = ($line =~ /::alignment\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       # HHERE load_tokenization_file
	       if ($contraction ne "") {
                  $n_contraction_patterns++;
		  $alignment_s = "" unless ($alignment_s eq "") || $this->contraction_alignment_is_valid($contraction, $norm, $alignment_s, *LOG, $filename, $line_number);
	          my $lc_tok = $this->register_li_token_affixes(*ht, $contraction, *LOG, $lang_code, "LI_TOKEN_ENTRY_P");
	          $ht{LI_CONTRACTION_CONTRACTION}->{$lang_code}->{$lc_tok} = $contraction;
	          $ht{LI_CONTRACTION_NORM}->{$lang_code}->{$lc_tok} = $norm;
	          $ht{LI_CONTRACTION_NORM2}->{$lang_code}->{$lc_tok} = $norm2 unless $norm2 eq "";
	          $ht{LI_CONTRACTION_ALIGNMENT_S}->{$lang_code}->{$lc_tok} = $alignment_s;
	          $ht{LI_TOKEN_TRUE_CASE}->{$lang_code}->{$lc_tok}->{$contraction} = 1;
	       } elsif ($l_contraction ne "") {
                  $n_l_contraction_patterns++;
	          my $lc_tok = $this->register_li_token_affixes(*ht, $l_contraction, *LOG, $lang_code, "LI_TOKEN_ENTRY_P");
	          $ht{LI_L_CONTRACTION_NORM}->{$lang_code}->{$lc_tok} = $norm;
	          $ht{LI_TOKEN_TRUE_CASE}->{$lang_code}->{$lc_tok}->{$l_contraction} = 1;
	       } elsif ($m_contraction ne "") {
                  $n_m_contraction_patterns++;
	          my $lc_tok = $this->register_li_token_affixes(*ht, $m_contraction, *LOG, $lang_code, "LI_TOKEN_ENTRY_P");
	          $ht{LI_M_CONTRACTION_NORM}->{$lang_code}->{$lc_tok} = $norm;
	          $ht{LI_TOKEN_TRUE_CASE}->{$lang_code}->{$lc_tok}->{$m_contraction} = 1;
	       } elsif ($r_contraction ne "") {
                  $n_r_contraction_patterns++;
	          my $lc_tok = $this->register_li_token_affixes(*ht, $r_contraction, *LOG, $lang_code, "LI_TOKEN_ENTRY_P");
	          $ht{LI_R_CONTRACTION_NORM}->{$lang_code}->{$lc_tok} = $norm;
	          $ht{LI_TOKEN_TRUE_CASE}->{$lang_code}->{$lc_tok}->{$r_contraction} = 1;
	       }
	       # support protecting norm-elems such as 't from being split into ' t
	       foreach $norm_elem (split(/[; ]+/, $norm)) {
		  if ($norm_elem =~ /[']/) {
                     my $lc_norm_elem = $this->register_li_token_affixes(*ht, $norm_elem, *LOG, $lang_code, "NORM_ELEM_ENTRY_P");
		  }
	       }
	    } elsif ($line =~ /^\s*::misspelling\s+\S/) {
	       my $misspelling = (($value) = ($line =~ /::misspelling\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $misspelling_type = (($value) = ($line =~ /::misspelling-type\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       next unless $load_spelling_correction_p || ($misspelling_type =~ /^(tokenizer)$/);
	       my $norm = (($value) = ($line =~ /::norm\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $lang_code = (($value) = ($line =~ /::lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $left_context = (($value) = ($line =~ /::left-context\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $right_context = (($value) = ($line =~ /::right-context\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $left_typed_context = (($value) = ($line =~ /::left-typed-context\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $right_typed_context = (($value) = ($line =~ /::right-typed-context\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $suffix_variation_s = (($value) = ($line =~ /::suffix-variations\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $replaceable_suffix = "";
	       my @suffixes = ();
	       if (($v1, $v2) = ($suffix_variation_s =~ (/^([^\/]*)\/([^\/]*)$/))) {
	          $replaceable_suffix = $v1;
		  @suffixes = split(/;\s*/, $v2);
	       } else {
		  @suffixes = split(/;\s*/, $suffix_variation_s);
	       }
	       my @misspellings = ($misspelling);
	       my @corrections = ($norm);
               $n_misspellings++;
	       foreach $suffix (@suffixes) {
	          my $misspelling2 = $misspelling;
	          my $correction2  = $norm;
		  $misspelling2 =~ s/$replaceable_suffix$/$suffix/;
		  $correction2  =~ s/$replaceable_suffix$/$suffix/;
	          push(@misspellings, $misspelling2);
	          push(@corrections,  $correction2);
                  $n_misspelling_variations++;
	       }
	       foreach $i ((0 .. $#misspellings)) {
	          my $misspelling2 = $misspellings[$i];
	          my $correction2  = $corrections[$i];
	          my $lc_tok = $this->register_li_token_affixes(*ht, $misspelling2, *LOG, $lang_code, "SPELLING_CORRECTION");
                  $ht{TOKEN_CORRECTED_SPELLING}->{$lang_code}->{$lc_tok} = $correction2;
		  $ht{LI_TOKEN_LEFT_CONTEXT}->{$lang_code}->{$lc_tok} = $this->pattern_string_to_pattern($left_context) if $left_context;
		  $ht{LI_TOKEN_RIGHT_CONTEXT}->{$lang_code}->{$lc_tok} = $this->pattern_string_to_pattern($right_context) if $right_context;
		  $ht{LI_TOKEN_LEFT_TYPED_CONTEXT}->{$lang_code}->{$lc_tok} = $this->pattern_string_to_pattern($left_typed_context) if $left_typed_context;
		  $ht{LI_TOKEN_RIGHT_TYPED_CONTEXT}->{$lang_code}->{$lc_tok} = $this->pattern_string_to_pattern($right_typed_context) if $right_typed_context;
	       }
	    } elsif ($line =~ /^\s*::alt-spelling\s+\S/) {
	       my $alt_spelling = (($value) = ($line =~ /::alt-spelling\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $norm = (($value) = ($line =~ /::norm\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $lang_code = (($value) = ($line =~ /::lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $suffix_variation_s = (($value) = ($line =~ /::suffix-variations\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $replaceable_suffix = "";
	       my @suffixes = ();
	       if (($v1, $v2) = ($suffix_variation_s =~ (/^([^\/]*)\/([^\/]*)$/))) {
	          $replaceable_suffix = $v1;
		  @suffixes = split(/;\s*/, $v2);
	       } else {
		  @suffixes = split(/;\s*/, $suffix_variation_s);
	       }
	       my @alt_spellings = ($alt_spelling);
	       my @corrections = ($norm);
               $n_alt_spellings++;
	       foreach $suffix (@suffixes) {
	          my $alt_spelling2 = $alt_spelling;
	          my $correction2  = $norm;
		  $alt_spelling2 =~ s/$replaceable_suffix$/$suffix/;
		  $correction2  =~ s/$replaceable_suffix$/$suffix/;
	          push(@alt_spellings, $alt_spelling2);
	          push(@corrections,  $correction2);
                  $n_alt_spelling_variations++;
	       }
	       foreach $i ((0 .. $#alt_spellings)) {
	          my $alt_spelling2 = $alt_spellings[$i];
	          my $correction2  = $corrections[$i];
	          my $lc_tok = $this->register_li_token_affixes(*ht, $alt_spelling2, *LOG, $lang_code, "SPELLING_NORMALIZATION");
                  $ht{TOKEN_NORMALIZED_SPELLING}->{$lang_code}->{$lc_tok}->{$correction2} = 1;
	       }
	    } elsif ($line =~ /^\s*::vulgarity\s+\S/) {
	       $n_vulgarities++;
	       my $vulgarity = (($value) = ($line =~ /::vulgarity\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $lang_code = (($value) = ($line =~ /::lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $grawlix_template_s = (($value) = ($line =~ /::grawlix-templates\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	    } elsif ($line =~ /^\s*::character\s+\S/) {
	       $n_character_normalizations++;
	       my $character = (($value) = ($line =~ /::character\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $lang_code = (($value) = ($line =~ /::lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $alt_spelling_s = (($value) = ($line =~ /::alt-spelling\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my @alt_spellings = ($alt_spelling_s) ? split(/;\s*/, $alt_spelling_s) : ();
	       foreach $alt_spelling (@alt_spellings) {
	          $ht{LI_CHAR_NORM_SPELLING}->{$lang_code}->{$alt_spelling} = $character;
		# print LOG "LI_CHAR_NORM_SPELLING $lang_code $alt_spelling = $character (CH)\n";
	       }
	    } elsif ($line =~ /^\s*::contraction-marker\s+\S/) {
	       $n_contraction_markers++;
	       my $contraction_marker = (($value) = ($line =~ /::contraction-marker\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $lang_code = (($value) = ($line =~ /::lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $alt_spelling_s = (($value) = ($line =~ /::alt-spelling\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my @alt_spellings = ($alt_spelling_s) ? split(/;\s*/, $alt_spelling_s) : ();
	       foreach $alt_spelling (@alt_spellings) {
	          $ht{LI_CHAR_NORM_SPELLING}->{$lang_code}->{$alt_spelling} = $contraction_marker;
		# print LOG "LI_CHAR_NORM_SPELLING $lang_code $alt_spelling = $contraction_marker (CM)\n";
	       }
            } elsif ($line =~ /^\s*::encoding-correction-from/) {
	       if (($incorrect, $correct) = ($line =~ /^::encoding-correction-from +(.*?) +::to +(.*?) +::/)) {
		  $ht{ENCODING_CORRECTION}->{$incorrect} = $correct;
		  $n_encoding_corrections++;
                  my @incorrect_chars = $utf8->split_into_utf8_characters($incorrect, "return only chars", *ht);
                  my $incorrect_suffix = "";
                  foreach $i ((0 .. $#incorrect_chars)) {
                     $incorrect_suffix = $incorrect_chars[$#incorrect_chars-$i] . $incorrect_suffix;
                     $ht{ENCODING_CORRECTION_SUFFIX_P}->{$incorrect_suffix} = 1;
                  }
	       }
            } elsif ($line =~ /^\s*::separable-prefix/) {
	       my $separable_prefix = (($value) = ($line =~ /::separable-prefix\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $lang_code = (($value) = ($line =~ /::lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       if ($separable_prefix) {
	          $ht{SEPARABLE_PREFIX}->{$lang_code}->{$separable_prefix} = 1;
                  $n_separable_prefixes++;
	       }
            } elsif ($line =~ /^\s*::currency-prefix/) {
	       my $currency_prefix = (($value) = ($line =~ /::currency-prefix\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $lang_code = (($value) = ($line =~ /::lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $abbrev_exp = (($value) = ($line =~ /::abbreviation-expansion\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $type = (($value) = ($line =~ /::type\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       if ($currency_prefix) {
	          $ht{CURRENCY_PREFIX}->{$lang_code}->{$currency_prefix} = 1;
	          $n_currency_prefixes++;
		  unless ($abbrev_exp eq "") {
                     $ht{ABBREV_EXPANSION_LANG}->{$lang_code}->{$currency_prefix}->{$abbrev_exp} = 1;
                     $ht{ABBREV_EXPANSION_LANG_OF}->{$lang_code}->{$abbrev_exp}->{$currency_prefix} = 1;
	          }
		  $ht{LI_TOKEN_TYPE}->{$lang_code}->{$currency_prefix} = $type if $type;
	       }
            } elsif ($line =~ /^\s*::valid-cluster/) {
	       # For clusters of short token, which can be indicative of tokenization problems; asserting them to be ok.
	       my $valid_cluster = (($value) = ($line =~ /::valid-cluster\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $lang_code = (($value) = ($line =~ /::lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       if ($valid_cluster) {
	          $ht{VALID_CLUSTER}->{$lang_code}->{$valid_cluster} = 1;
                  $n_valid_clusters++;
	       }
            } elsif ($line =~ /^\s*::invalid-cluster/) {
	       # e.g. https://
	       my $invalid_cluster = (($value) = ($line =~ /::invalid-cluster\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       my $lang_code = (($value) = ($line =~ /::lc\s+(\S|\S.*?\S)(\s+::\S.*|\s*)$/)) ? $value : "";
	       if ($invalid_cluster) {
	          $ht{INVALID_CLUSTER}->{$lang_code}->{$invalid_cluster} = 1;
                  $n_invalid_clusters++;
	       }
	    }
         }
      }
      print LOG "Loaded $filename $n_token_patterns token, $n_contraction_patterns  contr., $n_l_contraction_patterns l-contr., $n_m_contraction_patterns m-contr., $n_r_contraction_patterns r-contr. patterns; $n_vulgarities vulgarities, $n_character_normalizations character normalization(s), $n_contraction_markers contraction marker(s); $n_encoding_corrections encoding corrections; $n_misspellings misspellings (+ $n_misspelling_variations variations) $n_valid_clusters valid-clusters $n_invalid_clusters invalid-clusters\n" if $verbose;
   } else {
      print LOG "Could not open $filename\n";
   }
}

sub pattern_string_to_pattern {
   local($this, $pattern_string) = @_;
   # "/\s*\d/" -> "\s*\d"

   if (($pattern) = ($pattern_string =~ /^\/(.*)\/$/)) {
      return $pattern;
   } else {
      return $pattern_string;
   }
}

sub contraction_alignment_is_valid {
   local($this, $contraction, $norm, $alignment_s, *LOG, $filename, $line_number) = @_;

   unless ($alignment_s eq "") {
      my @alignment_segments = split(/;\s*/, $alignment_s);
      my @norm_segments = split(/\s+/, $norm);
      my $n_alignment_segments = $#alignment_segments + 1;
      my $n_norm_segments = $#norm_segments + 1;
      unless ($n_alignment_segments == $n_norm_segments) {
         print LOG "*** contraction alignment mismatch: $n_norm_segments contraction segments; $n_alignment_segments alignment segments (should be same; l. $line_number in $filename)\n";
         return 0;
      }
      my $span_start = 0;
      my $span_end = 0;
      foreach $alignment_segment (@alignment_segments) {
         if (($value1, $value2) = ($alignment_segment =~ /^(\d+)-(\d+)$/)) {
	    if ($value1 == $span_end) {
	       if ($value2 >= $value1) {
	          $span_end = $value2;
	       } else {
	          print LOG "*** contraction alignment segment error: $alignment_segment (bad span; l. $line_number in $filename)\n";
	          return 0;
	       }
	    } else {
	       print LOG "* contraction alignment segment warning: can't process span $alignment_segment (build on $span_start-$span_end; l. $line_number in $filename)\n";
	       return 0;
	    }
	 } else {
	    print LOG "*** contraction alignment segment error: $alignment_segment (not a span; l. $line_number in $filename)\n";
	    return 0;
	 }
      }
      my $contraction_length = $utf8->length_in_utf8_chars($contraction);
      unless (($span_start == 0) && ($span_end == $contraction_length)) {
	 print LOG "*** contraction alignment segment error: $span_start-$span_end incompatible with length($contraction) = $contraction_length (l. $line_number in $filename)\n";
	 return 0;
      }
   }
   return 1;
}

sub register_li_token_affixes {
   local($this, *ht, $tok, *LOG, $lang_code, $token_kw) = @_;
   # $token_kw: LI_TOKEN_ENTRY_P (e.g. for "sci-fi") 
   #         or NORM_ELEM_ENTRY_P (e.g. for "'t" to protect from splitting)
   #         or SPELLING_CORRECTION (e.g. for "ca n't" or "recieve")
   #         or SPELLING_NORMALIZATION (e.g. for British spellings "kilometre")

   my @tok_chars = $utf8->split_into_utf8_characters($tok, "return only chars", *ht);
   my @lc_tok_chars = ();
   foreach $char (@tok_chars) {
      $lc_char = $this->lower_case_char($char, *ht, $char);
      $lc_char = $norm_spelling_char
              if $norm_spelling_char = $ht{LI_CHAR_NORM_SPELLING}->{""}->{$lc_char}
                     || ($lang_code && $ht{LI_CHAR_NORM_SPELLING}->{""}->{$lc_char});
      push(@lc_tok_chars, $lc_char);
   }
   my $lc_tok_prefix = "";
   foreach $i ((0 .. $#lc_tok_chars)) {
      $lc_tok_prefix .= $lc_tok_chars[$i];
      $ht{LI_TOKEN_PREFIX_P}->{$lang_code}->{$lc_tok_prefix} = 1;
   }
   my $lc_tok_suffix = "";
   foreach $i ((0 .. $#lc_tok_chars)) {
      $lc_tok_suffix = $lc_tok_chars[$#lc_tok_chars-$i] . $lc_tok_suffix;
      $ht{LI_TOKEN_SUFFIX_P}->{$lang_code}->{$lc_tok_suffix} = 1;
    # print LOG "  reg. $lang_code suffix: $lc_tok_suffix :: $tok ::\n" if $tok =~ /^(ca)$/i;
   }
   $ht{$token_kw}->{$lang_code}->{$lc_tok_prefix} = 1;
 # print "Point JJ $token_kw $lang_code $lc_tok_prefix\n" if $lc_tok_prefix =~ /a.*f.*p/i;
   return $lc_tok_prefix;
}

sub length_in_utf8_chars {
   local($this, $s) = @_;

   $s =~ s/[\x80-\xBF]//g;
   $s =~ s/[\x00-\x7F\xC0-\xFF]/c/g;
   return length($s);
}

sub new_token_id {
   local($this, *ht, $text_id, $token_type) = @_;

   my $n = $ht{N_TOKENS_FOR_TYPE}->{$text_id}->{$token_type} || 0;
   $n++;
   $ht{N_TOKENS_FOR_TYPE}->{$text_id}->{$token_type} = $n;
   return "$token_type-$n";
}

sub new_html_id {
   local($this, *ht, $html_token_type) = @_;

   my $n = $ht{N_HTML_IDS_FOR_TOKEN_TYPE}->{$html_token_type} || 0;
   $n++;
   $ht{N_HTML_IDS_FOR_TOKEN_TYPE}->{$html_token_type} = $n;
   return "$html_token_type-$n";
}

sub reset_html_id_ht {
   local($this, *ht) = @_;

   foreach $html_token_type (keys %{$ht{N_HTML_IDS_FOR_TOKEN_TYPE}}) {
      $ht{N_HTML_IDS_FOR_TOKEN_TYPE}->{$html_token_type} = 0;
   }
}

sub script_char_type_description {
   local($this, *ht, $s) = @_;

   # print STDERR "Point A script_char_type_description $s\n";
   return "" if $s =~ /^[\x20-\x7E]*$/;
   return $script_descr if defined($script_descr = $ht{SCRIPT_CHAR_TYPE_DESCR}->{$s});
   my @chars = $this->split_into_utf8_characters($s, "return only chars", *empty_ht);
   my @char_types = ();
   my %char_type_count_ht = ();
   my $includes_ascii_p = 0;
   my $result = 0;
   foreach $char (@chars) {
      my $char_type = $this->cached_character_type($char, *ht);
      $char_type_count_ht{$char_type} = ($char_type_count_ht{$char_type} || 0) + 1;
      if ($char_type =~ /^ASCII/) {
         $includes_ascii_p = 1;
      } else {
         push(@char_types, $char_type) unless $this->member($char_type, @char_types);
      }
   }
   if (@char_types) {
      my @char_type_descriptions = ();
      foreach $char_type (@char_types) {
         my $count = $char_type_count_ht{$char_type};
         $char_type =~ s/^other /misc. /;
         $char_type .= " character" if $char_type =~ /(IPA|punctuation)$/i;
         $char_type .= " symbol" if $char_type =~ /(currency)$/i;
         $char_type .= "s" if ($char_type =~ /[a-z]$/) && ($count >= 2);
         push(@char_type_descriptions, "$count $char_type");
      }
      if ($includes_ascii_p) {
         $result = "includes " . join(", ", @char_type_descriptions);
      } else {
         $result = "consists of " . join(", ", @char_type_descriptions);
      }
   } else {
      $result = "";
   }
   $ht{SCRIPT_CHAR_TYPE_DESCR}->{$s} = $result;
   return $result;
}

sub register_markup {
   local($this, *ht, $text_id, $token_id, $token_type, $token_start, $token_end, $token_text, $verbose, $special_token_p, *LOG, $markup_prov, $start_end_norm_or_orig) = @_;
   # $verbose = 1;
   # e.g. (*ht, "Line2", "T1", "URL", 20, 38, "https://www.isi.edu", 0, 1, *LOG)

   my $orig_token_start;
   my $orig_token_end;
   if ($start_end_norm_or_orig eq "orig") {
      $orig_token_start = $token_start;
      $orig_token_end   = $token_end;
      $token_start = $ht{ORIG_TO_NORM_VERTEX_MAP_R}->{$text_id}->{$token_start};
      $token_end   = $ht{ORIG_TO_NORM_VERTEX_MAP_L}->{$text_id}->{$token_end};
      if ($verbose) {
         $token_start = "??" unless defined($token_start);
         $token_end   = "??" unless defined($token_end);
      }
   } else { # normal case
      $orig_token_start = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$token_start};
      $orig_token_end   = $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$token_end};
   }
   if (defined($orig_token_start) && defined($orig_token_end)) {
      if ($verbose && $tokenization_log_verbose) {
       # print LOG "reg. markup: $token_type $text_id $token_id ($orig_token_start-$orig_token_end/$token_start-$token_end): $token_text (spc: $special_token_p) $markup_prov\n";
         $ht{MARKUP_ID_VERBOSE}->{$text_id}->{$token_id} = 1;
      }
      $ht{ID_START}->{$text_id}->{$token_id} = $orig_token_start;
      $ht{ID_END}->{$text_id}->{$token_id} = $orig_token_end;
      $ht{START_ID}->{$text_id}->{$orig_token_start}->{$token_id} = 1;
      $ht{START_ID_BY_TYPE}->{$text_id}->{$orig_token_start}->{$token_type}->{$token_id} = 1;
      $ht{END_ID}->{$text_id}->{$orig_token_end}->{$token_id} = 1;
      $ht{END_ID_BY_TYPE}->{$text_id}->{$orig_token_end}->{$token_type}->{$token_id} = 1;
      $ht{SPAN_ID}->{$text_id}->{$orig_token_start}->{$orig_token_end}->{$token_id} = 1;
      $ht{SPAN_ID_BY_TYPE}->{$text_id}->{$orig_token_start}->{$orig_token_end}->{$token_type}->{$token_id} = 1;
      $ht{TOKEN_TYPE}->{$text_id}->{$token_id} = $token_type;
      $ht{TOKEN_TEXT}->{$text_id}->{$token_id} = $token_text;
      $ht{TOKEN_PROV}->{$text_id}->{$token_id} = $markup_prov;
      # Note: $ht{TOKEN_ORIG_TEXT}->{$text_id}->{$token_id} is set individually for tags with values such as &eacute;
      $ht{TOKEN_ACTIVE_P}->{$text_id}->{$token_id} = 1;
      $ht{TOKEN_SCRIPT_DESCR}->{$text_id}->{$token_id} = $script_descr 
         if $tokenization_log_verbose
	 && ($script_descr = $this->script_char_type_description(*ht, $token_text));
      my $norm_string_lead_char_type = "";
      if ($token_type eq "NORM-STRING") {
         my $norm_string_lead_char = $token_text;
	 $norm_string_lead_char =~ s/^(.[\x80-\xBF]*)/$1/;
	 $norm_string_lead_char_type = $this->cached_character_type($norm_string_lead_char, *ht);
       # print LOG "Point F: $text_id ($token_start-$token_end/$orig_token_start-$orig_token_end) $token_type text:$token_text lead:$norm_string_lead_char type:$norm_string_lead_char_type\n";
      }

      my $orig_start = $ht{ORIG_START}->{$text_id} || 0;
      my @orig_chars = @{$ht{ORIG_CHARS}->{$text_id}};
      my $orig_token_text = "";
      foreach $i (($orig_token_start .. ($orig_token_end - 1))) {
         $ht{CHAR_IN_ID}->{$text_id}->{$i} = $token_id;
         $ht{CHAR_IN_ID_BY_TYPE}->{$text_id}->{$token_type}->{$i} = $token_id;
         $ht{SPECIAL_CHAR_IN_ID}->{$text_id}->{$i} = $token_id if $special_token_p;
	 $ht{ORIG_CHAR_TYPE}->{$text_id}->{$i} = $norm_string_lead_char_type if $norm_string_lead_char_type;
         my $orig_char = $orig_chars[$i-$orig_start];
       # print "Point YY i:$i orig_chars:@orig_chars orig_char:$orig_char\n";
         my $orig_char_type = $this->cached_character_type($orig_char, *ht);
	 $orig_token_text .= ($orig_char_type =~ /(?:control-character|invalid|combining-diacritic)/)
	                       ? ("<U+" . (uc $utf8->utf8_to_4hex_unicode($orig_char)) . ">")
			       : $orig_char;
      }
      $ht{ORIG_TOKEN_TEXT}->{$text_id}->{$token_id} = $orig_token_text;
   } else {
      my $adjusted_token_start = $token_start;
      my $adjusted_orig_token_start = $orig_token_start;
      my $norm_start = $ht{NORM_START}->{$text_id};
      while (($adjusted_token_start > $norm_start) && (! (defined($adjusted_orig_token_start)))) {
         $adjusted_token_start--;
         $adjusted_orig_token_start = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$adjusted_token_start};
      }
      if (defined($adjusted_orig_token_start)) {
         my @token_ids = keys %{$ht{START_ID}->{$text_id}->{$adjusted_orig_token_start}};
         foreach $token_id (@token_ids) {
	    next unless $ht{TOKEN_ACTIVE_P}->{$text_id}->{$token_id};
	    my $adjusted_orig_token_end = $ht{ID_END}->{$text_id}->{$token_id};
	    my $adjusted_norm_token_end = $ht{ORIG_TO_NORM_VERTEX_MAP_L}->{$text_id}->{$adjusted_orig_token_end};
	    if (defined($adjusted_norm_token_end) && ($adjusted_norm_token_end >= $token_end)) {
	       my $adjusted_token_text = $ht{TOKEN_TEXT}->{$text_id}->{$token_id};
	       print LOG "** Rejecting orphaned $text_id $token_text ($orig_token_start-$orig_token_end/$token_start-$token_end) based on larger $token_id $adjusted_token_text ($adjusted_orig_token_start-$adjusted_orig_token_end/$adjusted_token_start-$adjusted_norm_token_end) [1]\n" if $verbose;
	       return 1;
	    }
	 }
      }
      my $adjusted_token_end = $token_end;
      my $adjusted_orig_token_end = $orig_token_end;
      my $norm_end = $ht{NORM_END}->{$text_id};
      while (($adjusted_token_end < $norm_end) && (! (defined($adjusted_orig_token_end)))) {
         $adjusted_token_end++;
	 $adjusted_orig_token_end = $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$adjusted_token_end};
      }
      if (defined($adjusted_orig_token_end)) {
         my @token_ids = keys %{$ht{END_ID}->{$text_id}->{$adjusted_orig_token_end}};
	 foreach $token_id (@token_ids) {
	    next unless $ht{TOKEN_ACTIVE_P}->{$text_id}->{$token_id};
	    my $adjusted_orig_token_start = $ht{ID_START}->{$text_id}->{$token_id};
	    my $adjusted_norm_token_start = $ht{ORIG_TO_NORM_VERTEX_MAP_R}->{$text_id}->{$adjusted_orig_token_start};
	    if (defined($adjusted_norm_token_start) && ($adjusted_norm_token_start <= $token_start)) {
	       my $adjusted_token_text = $ht{TOKEN_TEXT}->{$text_id}->{$token_id};
	       print LOG "** Rejecting orphaned $text_id $token_text ($orig_token_start-$orig_token_end/$token_start-$token_end) based on larger $token_id $adjusted_token_text ($adjusted_orig_token_start-$adjusted_orig_token_end/$adjusted_token_start-$adjusted_norm_token_end) [2]\n" if $verbose;
	       return 1;
	    }
	 }
      }
      $orig_token_start = "??" unless defined($orig_token_start);
      $orig_token_end   = "??" unless defined($orig_token_end);
      print LOG "*** Can't register markup $token_type $text_id $token_id ($orig_token_start-$orig_token_end/$token_start-$token_end): $token_text\n" if $verbose;
   }
   if ($tokenization_log_verbose) {
      if ($token_text =~ /(http|www\.)/i) {
         my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};
         my $left_context = join("", @norm_chars[0 .. ($token_start-1)]);
         my $right_context = join("", @norm_chars[$token_end .. $#norm_chars]);
	 my $url_accept_p = 0;
	 my $url_suspicious_span_p = 0;
	 my $url_suspicious_type_p = 0;
	 if ($token_text =~ /(http|www)/i) {
            if ($token_type eq "URL") {
	       if ((($left_context =~ /"$/) && ($right_context =~ /^"/))
	        || ((($left_context =~ /^$/) || ($left_context =~ /[ >\(]$/))
	         && (($right_context =~ /^[.,]?$/) || ($right_context =~ /^[.,]?[ <\)]/)))) {
		 $url_accept_p = 1;
	       } else {
		  $url_suspicious_span_p = 1;
	       }
            } elsif (($token_type eq "XML-TAG") && ($token_text =~ /^<a href="https?:/i)) {
	       # normal
            } else {
	       $url_suspicious_type_p = 1;
	    }
	 }
         my $left2_context = $this->last_n_chars_of_string($left_context, 5);
         my $right2_context = $this->first_n_chars_of_string($right_context, (($url_suspicious_span_p || $url_suspicious_type_p) ? 15 : 5));
	 my $token_text_with_context = "$token_type $token_text ($left2_context :: $right2_context)";
       # print "Point G: $token_type :: $left_context :: $left2_context :: $token_text :: $right2_context :: $right_context ::\n";
	 if ($url_accept_p) {
            $ht{URL_ACCEPT_COUNT}->{$token_text_with_context} = ($ht{URL_ACCEPT_COUNT}->{$token_text_with_context} || 0) + 1;
            $ht{URL_ACCEPT_TEXT_ID}->{$token_text_with_context}->{$text_id} = 1;
	 } elsif ($url_suspicious_span_p) {
            $ht{URL_SUSP_SPAN_COUNT}->{$token_text_with_context} = ($ht{URL_SUSP_SPAN_COUNT}->{$token_text_with_context} || 0) + 1;
            $ht{URL_SUSP_SPAN_TEXT_ID}->{$token_text_with_context}->{$text_id} = 1;
	 } elsif ($url_suspicious_type_p) {
            $ht{URL_SUSP_TYPE_COUNT}->{$token_text_with_context} = ($ht{URL_SUSP_TYPE_COUNT}->{$token_text_with_context} || 0) + 1;
            $ht{URL_SUSP_TYPE_TEXT_ID}->{$token_text_with_context}->{$text_id} = 1;
	 }
      }
   }
   # locally set: TOKEN_SUB_TYPE, TOKEN_ORIG_TEXT, TOKEN_ETYM, TOKEN_NE_TYPE, TOKEN_ABBREV_EXPANSION, TOKEN_TAXON, TOKEN_GLOSS
   return 0;
}

sub special_char_in_id {
   local($this, *ht, $text_id, $norm_char_start, $norm_char_end) = @_;

   $norm_char_end = $norm_char_start+1 unless defined($norm_char_end);
   my $orig_char_start = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$norm_char_start};
   my $orig_char_end   = $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$norm_char_end};
   if (defined($orig_char_start)) {
      $orig_char_end = $orig_char_start+1 unless defined($orig_char_end);
      foreach $orig_char_offset (($orig_char_start .. ($orig_char_end-1))) {
          return 1 if $ht{SPECIAL_CHAR_IN_ID}->{$text_id}->{$orig_char_offset};
      }
   }
   return 0;
}

sub span_contains_token_of_type {
   local($this, *ht, $text_id, *LOG, $norm_char_start, $norm_char_end, @token_types) = @_;

   my $orig_char_start = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$norm_char_start};
   my $orig_char_end   = $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$norm_char_end};
   if (defined($orig_char_start)) {
      $orig_char_end = $orig_char_start+1 unless defined($orig_char_end);
      foreach $token_type (@token_types) {
         foreach $orig_char_offset (($orig_char_start .. ($orig_char_end-1))) {
	    return 1 if ($token_id = $ht{CHAR_IN_ID_BY_TYPE}->{$text_id}->{$token_type}->{$orig_char_offset})
	             && $ht{TOKEN_ACTIVE_P}->{$text_id}->{$token_id};
         }
      }
   }
   return 0;
}

sub split_into_utf8_characters {
   local($this, $text) = @_;
   # "return only chars; return trailing whitespaces"

   @characters = ();
   while (($char, $rest) = ($text =~ /^(.[\x80-\xBF]*)(.*)$/)) {
      push(@characters, $char);
      $text = $rest;
   }
   return @characters;
}

# our @ront_chars;
sub register_orig_norm_text {
   local($this, *ht, $text, $text_id, $offset, *LOG, $verbose) = @_;

   @ront_chars = $this->split_into_utf8_characters($text);
   my $n_chars = $#ront_chars + 1;
   my @typed_chars = $this->type_chars(*ht, "", *ront_chars);
 # print LOG "TYPE-CHARS: @ront_chars -> @typed_chars\n";
   my $typed_text = join("", @typed_chars);
   my $start_vertex = $offset;
   my $end_vertex = $offset + $n_chars;
   $ht{ORIG_START}->{$text_id} = $start_vertex;
   $ht{NORM_START}->{$text_id} = 0;
   $ht{ORIG_END}->{$text_id} = $end_vertex;
   $ht{NORM_END}->{$text_id} = $n_chars;
   $ht{ORIG_TEXT}->{$text_id} = $text;
   $ht{NORM_TEXT}->{$text_id} = $text;
   $ht{ORIG_TYPED_TEXT}->{$text_id} = $typed_text;
   $ht{NORM_TYPED_TEXT}->{$text_id} = $typed_text;
   @{$ht{ORIG_CHARS}->{$text_id}} = @ront_chars;
   @{$ht{NORM_CHARS}->{$text_id}} = @ront_chars;
   @{$ht{ORIG_TYPED_CHARS}->{$text_id}} = @typed_chars;
   @{$ht{NORM_TYPED_CHARS}->{$text_id}} = @typed_chars;
   $ht{ORIG_CHAR}->{$text_id}->{($offset-1)} = " ";
   $ht{ORIG_CHAR_TYPE}->{$text_id}->{($offset-1)} = "boundary";

   $ht{ORIG_TO_NORM_VERTEX_MAP_R}->{$text_id}->{$offset} = 0;
   $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{0} = $offset;
   $ht{ORIG_CHAR}->{$text_id}->{$offset} = $ront_chars[0];
   $ht{ORIG_CHAR_TYPE}->{$text_id}->{$offset} = $typed_chars[0];
   foreach $norm_index ((1 .. ($n_chars - 1))) {
      my $orig_index = $norm_index + $offset;
      $ht{ORIG_TO_NORM_VERTEX_MAP_L}->{$text_id}->{$orig_index} = $norm_index;
      $ht{ORIG_TO_NORM_VERTEX_MAP_R}->{$text_id}->{$orig_index} = $norm_index;
      $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$norm_index} = $orig_index;
      $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$norm_index} = $orig_index;
      $ht{ORIG_CHAR}->{$text_id}->{$orig_index} = $ront_chars[$norm_index];
      $ht{ORIG_CHAR_TYPE}->{$text_id}->{$orig_index} = $typed_chars[$norm_index];
   }
   $ht{ORIG_TO_NORM_VERTEX_MAP_L}->{$text_id}->{$end_vertex} = $n_chars;
   $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$n_chars} = $end_vertex;
   $ht{ORIG_CHAR}->{$text_id}->{$end_vertex} = " ";
   $ht{ORIG_CHAR_TYPE}->{$text_id}->{$end_vertex} = "boundary";
}

sub print_norm_text {
   local($this, *ht, $text_id, *LOG, $print_mappings_p, $message_id) = @_;
 
   $print_mappings_p = 1 unless defined($print_mappings_p);
   $message_id = "" unless defined($message_id);
   my $message_id_clause = ($message_id eq "") ? "" : " $message_id";
   my $start_vertex = $ht{NORM_START}->{$text_id};
   my $end_vertex = $ht{NORM_END}->{$text_id};
   my $span = "$start_vertex-$end_vertex";
   my $text = $ht{NORM_TEXT}->{$text_id};
   my $typed_text = $ht{NORM_TYPED_TEXT}->{$text_id};
   my @chars = @{$ht{NORM_CHARS}->{$text_id}};
   my @typed_chars = @{$ht{NORM_TYPED_CHARS}->{$text_id}};
   print LOG "print_norm_text $text_id$message_id_clause: $text ($span) $typed_text\n  chars: @chars\n  typed: @typed_chars\n";
   if ($print_mappings_p) {
      print LOG "  no-map:";
      foreach $norm_vertex (($start_vertex .. $end_vertex)) {
         $orig_vertex1 = $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$norm_vertex};
         $orig_vertex2 = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$norm_vertex};
         $orig_vertex1 = "*" unless defined($orig_vertex1);
         $orig_vertex2 = "*" unless defined($orig_vertex2);
         print LOG " $norm_vertex->$orig_vertex1";
         print LOG "/$orig_vertex2" if $orig_vertex1 ne $orig_vertex2;
      }
      print LOG "\n  on-map:";
      my $orig_start_vertex = $ht{ORIG_START}->{$text_id};
      my $orig_end_vertex = $ht{ORIG_END}->{$text_id};
      foreach $orig_vertex (($orig_start_vertex .. $orig_end_vertex)) {
         $norm_vertex1 = $ht{ORIG_TO_NORM_VERTEX_MAP_L}->{$text_id}->{$orig_vertex};
         $norm_vertex2 = $ht{ORIG_TO_NORM_VERTEX_MAP_R}->{$text_id}->{$orig_vertex};
         $norm_vertex1 = "*" unless defined($norm_vertex1);
         $norm_vertex2 = "*" unless defined($norm_vertex2);
         print LOG " $orig_vertex->$norm_vertex1";
         print LOG "/$norm_vertex2" if $norm_vertex1 ne $norm_vertex2;
      }
   }
   print LOG "\n";
}

sub realign_segment_for_update_norm_text {
   local($this, *ht, $text_id, $old_norm_sub_start, $old_norm_sub_end, *replaced_chars, $new_norm_sub_start, $new_norm_sub_end, *replacement_chars, *LOG, $verbose) = @_;

 # print LOG "realign_segment_for_update_norm_text $text_id old:$old_norm_sub_start-$old_norm_sub_end new:$new_norm_sub_start-$new_norm_sub_end\n" if $verbose;
   my $n_chars_in_old_segment = $old_norm_sub_end - $old_norm_sub_start;
   my $n_chars_in_new_segment = $new_norm_sub_end - $new_norm_sub_start;

   unless ($n_chars_in_new_segment == 0) {
      # segment start, outgoing
      $tmp_ht{NEW_TO_OLD_NORM_VERTEX_MAP_R}->{$text_id}->{$new_norm_sub_start} = $old_norm_sub_start;
      my $orig_index1 = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$old_norm_sub_start};
      $tmp_ht{NEW_NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$new_norm_sub_start} = $orig_index1 if defined($orig_index1);

      # segment end, incoming
      $tmp_ht{NEW_TO_OLD_NORM_VERTEX_MAP_L}->{$text_id}->{$new_norm_sub_end} = $old_norm_sub_end;
      my $orig_index2 = $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$old_norm_sub_end};
      $tmp_ht{NEW_NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$new_norm_sub_end} = $orig_index2 if defined($orig_index2);

      # realign segment chars from left
      my $left_alignment_border = $old_norm_sub_start;
      my $max_i = $this->min($#replaced_chars, $#replacement_chars);
      foreach $i ((0 .. $max_i)) {
         if ($replaced_chars[$i] eq $replacement_chars[$i]) {
	    my $old_norm_index1 = $old_norm_sub_start + $i;
	    my $old_norm_index2 = $old_norm_sub_start + $i + 1;
	    my $new_norm_index1 = $new_norm_sub_start + $i;
	    my $new_norm_index2 = $new_norm_sub_start + $i + 1;
	    $left_alignment_border = $old_norm_index2;
	    $tmp_ht{NEW_TO_OLD_NORM_VERTEX_MAP_R}->{$text_id}->{$new_norm_index1} = $old_norm_index1;
	    $tmp_ht{NEW_TO_OLD_NORM_VERTEX_MAP_L}->{$text_id}->{$new_norm_index2} = $old_norm_index2;
	    my $orig_index1 = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$old_norm_index1};
	    my $orig_index2 = $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$old_norm_index2};
	    $tmp_ht{NEW_NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$new_norm_index1} = $orig_index1 if defined($orig_index1);
	    $tmp_ht{NEW_NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$new_norm_index2} = $orig_index2 if defined($orig_index2);
         } else {
            last;
         }
      }
      # realign segment chars from right
      my $right_alignment_border = $old_norm_sub_end;
      foreach $i ((0 .. $max_i)) {
         if ($replaced_chars[($#replaced_chars-$i)] eq $replacement_chars[($#replacement_chars-$i)]) {
	    my $old_norm_index1 = $old_norm_sub_end - $i - 1;
	    my $old_norm_index2 = $old_norm_sub_end - $i;
	    my $new_norm_index1 = $new_norm_sub_end - $i - 1;
	    my $new_norm_index2 = $new_norm_sub_end - $i;
	    $right_alignment_border = $old_norm_index1;
	    last if $right_alignment_border < $left_alignment_border;
	    $tmp_ht{NEW_TO_OLD_NORM_VERTEX_MAP_R}->{$text_id}->{$new_norm_index1} = $old_norm_index1;
	    $tmp_ht{NEW_TO_OLD_NORM_VERTEX_MAP_L}->{$text_id}->{$new_norm_index2} = $old_norm_index2;
	    my $orig_index1 = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$old_norm_index1};
	    my $orig_index2 = $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$old_norm_index2};
	    $tmp_ht{NEW_NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$new_norm_index1} = $orig_index1 if defined($orig_index1);
	    $tmp_ht{NEW_NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$new_norm_index2} = $orig_index2 if defined($orig_index2);
         }
      }
   }
}

# our @replacement_chars;
# our @replaced_chars;
sub update_norm_text {
   local($this, *ht, $text_id, $old_norm_sub_start, $old_norm_sub_end, $replacement_text, $align_directive, *LOG, $verbose) = @_;
   # $old/new_norm_sub_start/end relative to current chars (without orig. offset)
   # align_directive: 0-3:0-2;4-7:2-5 (for example from new "can n't" to old "can't")

   my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};
   my $n_norm_chars = $#norm_chars + 1;
   my @norm_typed_chars = @{$ht{NORM_TYPED_CHARS}->{$text_id}};
   if ((0 <= $old_norm_sub_start)
    && ($old_norm_sub_start <= $old_norm_sub_end)
    && ($old_norm_sub_end <= $n_norm_chars)) {
      my $n_replaced_chars = $old_norm_sub_end - $old_norm_sub_start;
      @replacement_chars = $this->split_into_utf8_characters($replacement_text);
      my $n_replacement_chars = $#replacement_chars + 1;
      my @typed_replacement_chars = $this->type_chars(*ht, "", *replacement_chars);
      @replaced_chars = splice(@norm_chars, $old_norm_sub_start, $n_replaced_chars, @replacement_chars);
    # print LOG "Point A: @replaced_chars ($n_replaced_chars) @replacement_chars ($n_replacement_chars)\n" if $verbose;
    # print LOG "Point B: norm_chars: @norm_chars ::\n" if $verbose;
      splice(@norm_typed_chars, $old_norm_sub_start, $n_replaced_chars, @typed_replacement_chars);
    # print LOG "Point C: norm_typed_chars: @norm_typed_chars ::\n" if $verbose;
      my $new_norm_sub_start = $old_norm_sub_start;
      my $n_additional_chars = $n_replacement_chars - $n_replaced_chars; # could be negative
      my $new_norm_sub_end = $old_norm_sub_end + $n_additional_chars;
      my $old_norm_end = $ht{NORM_END}->{$text_id};
      my $new_norm_end = $old_norm_end + $n_additional_chars;
    # print LOG "Point D: old: $old_norm_sub_start-$old_norm_sub_end/$old_norm_end new: $new_norm_sub_start-$new_norm_sub_end/$new_norm_end\n" if $verbose;

      @{$ht{NORM_CHARS}->{$text_id}} = @norm_chars;
      @{$ht{NORM_TYPED_CHARS}->{$text_id}} = @norm_typed_chars;
      $ht{NORM_TEXT}->{$text_id} = join("", @norm_chars);
      $ht{NORM_TYPED_TEXT}->{$text_id} = join("", @norm_typed_chars);

      ## realignment
      %tmp_ht = ();
      if ($align_directive) {
         foreach $align_component (split(/;\s*/, $align_directive)) {
	    if (($new_relative_start, $new_relative_end, $old_relative_start, $old_relative_end)
	          = ($align_component =~ /^(\d+)-(\d+):(\d+)-(\d+)$/)) {
               $this->realign_segment_for_update_norm_text(*ht, $text_id,
	          ($old_norm_sub_start + $old_relative_start),
		  ($old_norm_sub_start + $old_relative_end),   *replaced_chars,
		  ($new_norm_sub_start + $new_relative_start),
		  ($new_norm_sub_start + $new_relative_end),   *replacement_chars, *LOG, $verbose);
	    } else {
	       print LOG "*** Error in align_directive component $align_component (in $align_component)\n" if $verbose;
	    }
	 }
      } else {
         $this->realign_segment_for_update_norm_text(*ht, $text_id, $old_norm_sub_start, $old_norm_sub_end, *replaced_chars, $new_norm_sub_start, $new_norm_sub_end, *replacement_chars, *LOG, $verbose);
      }

      # re-align post (if change in n_chars)
      unless ($n_additional_chars == 0) {
         foreach $new_norm_index (($new_norm_sub_end .. $new_norm_end)) {
	    my $old_norm_index = $new_norm_index - $n_additional_chars;
	    unless ($new_norm_index eq $new_norm_sub_end) {
               $tmp_ht{NEW_TO_OLD_NORM_VERTEX_MAP_L}->{$text_id}->{$new_norm_index} = $old_norm_index;
	       my $orig_index = $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$old_norm_index};
               $tmp_ht{NEW_NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$new_norm_index} = $orig_index if defined($orig_index);
	    }
	    unless ($new_norm_index eq $new_norm_end) {
               $tmp_ht{NEW_TO_OLD_NORM_VERTEX_MAP_R}->{$text_id}->{$new_norm_index} = $old_norm_index;
	       my $orig_index = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$old_norm_index};
               $tmp_ht{NEW_NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$new_norm_index} = $orig_index if defined($orig_index);
	    }
         }
      }
      # undefine old in old-segment; also post if change in n_chars
      my $undef_end = ($n_additional_chars == 0) ? $old_norm_sub_end : $old_norm_end;
      foreach $old_norm_index (($old_norm_sub_start .. $undef_end)) {
	 unless ($old_norm_index eq $old_norm_sub_start) {
            my $orig_index = $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$old_norm_index};
	    undef($ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$old_norm_index});
            undef($ht{ORIG_TO_NORM_VERTEX_MAP_L}->{$text_id}->{$orig_index}) if defined($orig_index);
	 }
	 unless ($old_norm_index eq $undef_end) {
            my $orig_index = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$old_norm_index};
	    undef($ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$old_norm_index});
            undef($ht{ORIG_TO_NORM_VERTEX_MAP_R}->{$text_id}->{$orig_index}) if defined($orig_index);
	 }
      }
      # copy from tmp_ht to ht
      foreach $new_norm_index (($new_norm_sub_start .. $new_norm_end)) {
	 my $orig_index1 = $tmp_ht{NEW_NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$new_norm_index};
	 if (defined($orig_index1)) {
	    $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$new_norm_index} = $orig_index1;
	    $ht{ORIG_TO_NORM_VERTEX_MAP_R}->{$text_id}->{$orig_index1} = $new_norm_index;
	 }
	 my $orig_index2 = $tmp_ht{NEW_NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$new_norm_index};
	 if (defined($orig_index2)) {
	    $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$new_norm_index} = $orig_index2;
	    $ht{ORIG_TO_NORM_VERTEX_MAP_L}->{$text_id}->{$orig_index2} = $new_norm_index;
	 }
      }
      $ht{NORM_END}->{$text_id} = $new_norm_end;
   }
   $this->print_norm_text(*ht, $text_id, *LOG) if 0 && $verbose;
}

$url_path = '(?:(?:\/(?:\.{1..3}|~?[a-z0-9%][-a-z0-9_%.,]*))*(?:\/[a-z0-9_%][-a-z0-9_%.,&]+\.(?:aspx?|bmp|cgi|docx?|gif|html?|jpeg|jpg|mp3|mp4|pdf|php|png|pptx?|stm|svg|txt|xml)\b)|(?:\/(?:\.{1..3}|~?[-a-z0-9_%.,]+))*\/?)';
$url_host = '(?:\:\d{2,5})?';
$url_query = '\?[a-z0-9_]*(?:=[-+a-z0-9_%\/.]*)?(?:(?:\&amp;|\&|;)[a-z][a-z0-9_]*(?:=[-a-z0-9_%\/.]*)?)*';
$url_fragment = '\#[a-z](?:[-a-z0-9_=.]*[a-z0-9])?';
$url_pattern1 = '(?:https?|ftp)://(?:[a-z][-_a-z0-9.#?&=\/]*\.\.(?:[-_a-z0-9.#?&=\/]*[a-z0-9\/])*|[a-z0-9][-a-z0-9_]*(?:\.[a-z0-9][-a-z0-9_]*)*\.[a-z]{2,})';
$url_pattern2 = '\bwww(?:\.[a-z0-9][-a-z0-9_]+)+\.(?:cat|com|edu|gov|info|int|mil|museum|net|org|[a-z]{2,2}\b)';
$url_pattern3 = '[a-z0-9][-a-z0-9_]+(?:\.[a-z][-a-z0-9_]+)*\.(?:cat|com|edu|gov|info|int|mil|museum|net|org|ar|at|au|be|bi|br|ca|ch|cn|co|cz|de|dk|dz|eg|er|es|et|eu|fi|fr|gr|hk|hu|id|ie|il|in|ir|is|it|jp|ke|kr|lb|lk|lu|lv|ly|ma|mg|mx|my|nl|no|nz|ph|pk|pl|ps|pt|ro|ru|rw|sa|se|sg|so|sy|tn|tr|tv|tw|tz|ug|uk|us|za)\b';
$url_pattern = "(?:$url_pattern1$url_host$url_path|$url_pattern2$url_host$url_path|$url_pattern3$url_host$url_path)(?:$url_query)?(?:$url_fragment)?";
$url_regex = qr/^(.*?)(?<![-_a-z0-9@])($url_pattern)(?![-_a-z0-9@])(.*)$/i;
sub markup_urls {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;

   my $position = 0;
   my $s = $ht{NORM_TEXT}->{$text_id};
   my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};

 # print LOG "url_pattern: $url_regex\n" if $verbose;
   while (($pre, $url, $post) = ($s =~ $url_regex)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $url_length = $this->length_in_utf8_chars($url);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $url_length;
      unless ($url =~ /\.\.$/) {
         my $n_non_url_chars_on_right = 0;
         my $offset;
         while ((($offset = $token_end - 1 - $n_non_url_chars_on_right) >= 0) && ($norm_chars[$offset] =~ /^[.,]$/)) {
	    $n_non_url_chars_on_right++;
         }
         if ($n_non_url_chars_on_right) {
	    my $orig_url = $url;
            ($pre, $url, $post, $token_start, $token_end) = $this->realign_pre_in_post($pre, $url, $post, $position, 0, -$n_non_url_chars_on_right, *ht, $text_id, *LOG, $verbose);
	  # print LOG "Adjusting URL from $orig_url to $url\n";
         }
      }
      unless ($this->span_contains_token_of_type(*ht, $text_id, *LOG, $token_start, $token_end, "XML-TAG")) {
         my $likely_validity = 0.5;
         $likely_validity += 0.2 if $url =~ /^(ftp|http|https|www):\/\//i;
         $likely_validity -= 0.2 if $url =~ /\.([A-Z][a-z]+)$/;
         $likely_validity -= 0.1 if $url =~ /\.\./;
         if ($likely_validity < 0.4) {
            if ($tokenization_log_verbose) {
               $ht{URL_REJECT_COUNT}->{$url} = ($ht{URL_REJECT_COUNT}->{$url} || 0) + 1;
               $ht{URL_REJECT_TEXT_ID}->{$url}->{$text_id} = 1;
	    }
         } else {
            my $url_id = $this->new_token_id(*ht, $text_id, "URL");
            $this->register_markup(*ht, $text_id, $url_id, "URL", $token_start, $token_end, $url, $verbose, 1, *LOG, "markup_urls", "norm");
            $ht{TOKEN_SUB_TYPE}->{$text_id}->{$url_id} = "truncated URL" if $url =~ /(?<![\/])\.\.(?![\/])/;
         }
      }
      $position = $token_end;
      $s = $post;
   }
}

$filename_pattern = '(?:[a-z0-9][-a-z0-9_.\/]+\.(?:aspx?|bmp|cgi|docx?|gif|html?|jpeg|jpg|mp3|mp4|pdf|php|png|pptx?|stm|svg|txt|xml)\b)';
$filename_regex = qr/^(.*?)(?<![-_a-z0-9@#])($filename_pattern)(?![-_a-z0-9@#])(.*)$/i;
sub markup_filenames {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;

   my $position = 0;
   my $s = $ht{NORM_TEXT}->{$text_id};

 # print LOG "filename: $filename_regex\n" if $verbose;
   while (($pre, $filename, $post) = ($s =~ $filename_regex)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $filename_length = $this->length_in_utf8_chars($filename);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $filename_length;
      unless ($this->special_char_in_id(*ht, $text_id, $token_start, $token_end)) {
         my $likely_validity = 0.5;
         $likely_validity -= 0.2 if $filename =~ /\.([A-Z][a-z]+)$/;
         $likely_validity -= 0.1 if $filename =~ /\.\./;
         if ($likely_validity < 0.4) {
	    if ($tokenization_log_verbose) {
               $ht{FILENAME_REJECT_COUNT}->{$filename} = ($ht{FILENAME_REJECT_COUNT}->{$filename} || 0) + 1;
               $ht{FILENAME_REJECT_TEXT_ID}->{$filename}->{$text_id} = 1;
	    }
         } else {
            my $filename_id = $this->new_token_id(*ht, $text_id, "FILENAME");
            $this->register_markup(*ht, $text_id, $filename_id, "FILENAME", $token_start, $token_end, $filename, $verbose, 1, *LOG, "markup_filenames", "norm");
         }
      }
      $position = $token_end;
      $s = $post;
   }
}

sub markup_s_words {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;
   # s-word: sanitized word (e.g. f***ing/f---ing/f@#$ing); stylized words (e.g. *great*, g*r*e*a*t)

   my $position = 0;
   my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};
   my @norm_typed_chars = @{$ht{NORM_TYPED_CHARS}->{$text_id}};
   my $s = $ht{NORM_TEXT}->{$text_id};
   my $n_norm_chars = $#norm_chars + 1;

   while (($pre, $s_word_anchor, $post) = ($s =~ /^(.*?)([-*\@\$\^#%&!]|\xC2\xA3|\xC2\xB6)(.*)$/)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + 1;
    # print LOG "Point A: $text_id $s_word_anchor ($token_start-$token_end)\n";
      while (($token_start >= 1)
          && (($norm_typed_chars[$token_start-1] =~ /^[AaBbEeGgYy]$/)
	   || ($norm_chars[$token_start-1] =~ /^(?:[-*\@\$\^#%&!]|\xC2\xA3|\xC2\xB6)$/))) {
         $token_start--;
      }
      while (($token_end <= $#norm_chars)
          && (($norm_typed_chars[$token_end] =~ /^[AaBbEeGgYy]$/)
	   || ($norm_chars[$token_end] =~ /^(?:[-*\@\$\^#%&!]|\xC2\xA3|\xC2\xB6)$/))) {
         $token_end++;
      }
      my $token_end_max = $token_end;
      while (($token_end > $token_start)
	  && ($norm_chars[$token_end-1] eq "!")) {
         $token_end--;
      }
      unless ($this->special_char_in_id(*ht, $text_id, $token_start, $token_end)) {
	 my $local_verbose = 0;
	 my $rejection_reason = "";
         my $token = join("", @norm_chars[$token_start .. ($token_end-1)]);
         my $typed_token = join("", @norm_typed_chars[$token_start .. ($token_end-1)]);
       # print LOG "Point B: $text_id $token :: $typed_token ($token_start-$token_end)\n";
	 if ($token_end - $token_start < 3) {
            $rejection_reason = "Point C1: too short";
	 } elsif ($token_end - $token_start > 13) {
            $rejection_reason = "Point C2: too long";
	 } elsif ($typed_token =~ /^(?:-|\^*)[AaBbEeGgYy]+(-[AaBbEeGgYy]+)*(?:-|!*|\^*)$/) { # anti-war
            $rejection_reason = "Point C3: a-a";
	 } elsif ($typed_token =~ /^\*+[AaBbEeGgYy]*\*+$/) {                  # *great* 
            $rejection_reason = "Point C4: *a*";
	 } elsif ($typed_token =~ /^[AaBbEeGgYy]+(?:!+-+|.[\x80-\xBF]*)$/) {  # Stop!
            $rejection_reason = "Point C5: Stop!";
	 } elsif ($typed_token =~ /^.[\x80-\xBF]*[AaBbEeGgYy]+$/) {           # #hashtag
            $rejection_reason = "Point C6: #hashtag";
         } elsif ($typed_token =~ /^[AaBbEeGgYy]*\@[AaBbEeGgYy]*$/) {         # e@mail
            $rejection_reason = "Point C7: e\@mail";
         } elsif ($token =~ /^(-+|\*+|\@+|\$+|#+|%+|\!+|\^+|(?:\xC2\xA3)+|(?:\xC2\xB6)+)$/) {
            $rejection_reason = "Point C8: !!!";
	 } elsif ($typed_token =~ /^\*[AaBbEeGgYy]+(-[AaBbEeGgYy]+)*\*$/) {   # *emphasis*
            $rejection_reason = "Point C9: *emphasis*";
	 } else {
            my $likely_validity = 0.5;
            $likely_validity -= 0.2 if $typed_token =~ /^[-AaBbEeGgYy]+$/;
            $likely_validity -= 0.2 if $typed_token =~ /^[%]-[AaBbEeGgYy]+$/;
	    # consider additional features such as vulgarity templates
            if ($likely_validity < 0.4) {
	       if ($tokenization_log_verbose) {
                  $ht{S_WORD_REJECT_COUNT}->{$token} = ($ht{S_WORD_REJECT_COUNT}->{$token} || 0) + 1;
                  $ht{S_WORD_REJECT_TEXT_ID}->{$token}->{$text_id} = 1;
	       }
            } else {
             # print LOG "S-WORD?: $text_id $token ($likely_validity)\n";
	       if ($tokenization_log_verbose) {
                  $ht{S_WORD_ACCEPT_COUNT}->{$token} = ($ht{S_WORD_ACCEPT_COUNT}->{$token} || 0) + 1;
                  $ht{S_WORD_ACCEPT_TEXT_ID}->{$token}->{$text_id} = 1;
	       }
               my $s_word_id = $this->new_token_id(*ht, $text_id, "S-WORD");
               $this->register_markup(*ht, $text_id, $s_word_id, "S-WORD", $token_start, $token_end, $token, $verbose, 1, *LOG, "markup_s_word", "norm");
            }
         }
         # print LOG "** $rejection_reason\n";
      }
      $position = $token_end_max;
      $s = join("", @norm_chars[$token_end_max .. $#norm_chars]);
   }
}

sub markup_xml_tags {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;

   my $s = $ht{NORM_TEXT}->{$text_id};
   my $position = 0;

   while (($pre, $tag, $post) = ($s =~ /^(.*?)(\@?<\/?(?:[a-z][-_:a-z0-9]*)(?:\s+[a-z][-_:a-z0-9]*=(?:"[^"]*"|'[^']*'))*\s*\/?>\@?|&(?:[a-z]{2,6}|#\d+|#x[0-9a-f]+);|\[\/?(?:img|indent|jpeg|jpg|mp3|mp4|quote|url)\]|\[quote=[a-z][-a-z0-9 ]*;\d+\])(.*)$/i)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $tag_length = $this->length_in_utf8_chars($tag);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $tag_length;
      $position = $token_end;
      $s = $post;
      if (($core_tag) = ($tag =~ /^&(.*);$/)) {
         my $cand = "";
         my $normalized_string = ""; # &#65; => A  &quot; => "
         my $tag_valid_p = 1;
         if (($decimal_tag) = ($core_tag =~ /^#(\d+)$/)) {
	    $cand = $utf8->unicode2string($decimal_tag);
         } elsif (($hexadecimal_tag) = ($core_tag =~ /^#[xX]([0-9A-Fa-f]+)$/)) {
	    $cand = $utf8->unicode_hex_string2string($hexadecimal_tag);
	 } elsif ($cand = $ht{HTML_ENTITY_NAME_TO_UTF8}->{$core_tag}) {
	 } else {
	    $tag_valid_p = 0;
	 }
         if ($tag_valid_p) {
	    $normalized_string = $cand if defined($cand) && ($cand ne "");
            my $norm_string_id = $this->new_token_id(*ht, $text_id, "NORM-STRING");
            $this->register_markup(*ht, $text_id, $norm_string_id, "NORM-STRING", $token_start, $token_end, $normalized_string, $verbose, 0, *LOG, "markup_norm_string", "norm");
            $ht{TOKEN_ORIG_TEXT}->{$text_id}->{$norm_string_id} = $tag;
            $this->update_norm_text(*ht, $text_id, $token_start, $token_end, $normalized_string, "", *LOG, $verbose);
          # $this->print_norm_text(*ht, $text_id, *LOG, 0, "post-markup_words($token_start-$token_end)");
	    $position = $token_start + $this->length_in_utf8_chars($normalized_string);
         } else {
            print LOG "markup_xml_tag: Rejecting norm-string $tag\n" if $tokenization_log_verbose;
	 }
      } else {
         my $tag_id = $this->new_token_id(*ht, $text_id, "XML-TAG");
         $this->register_markup(*ht, $text_id, $tag_id, "XML-TAG", $token_start, $token_end, $tag, $verbose, 1, *LOG, "markup_xml_tags", "norm");
      }
   }
}

$email_pattern = '(?:[a-z][-+a-z0-9_]*(?:\.[a-z][-+a-z0-9_]*)*\@[a-z][-a-z0-9_]+(?:\.[a-z][-a-z0-9_]+)*\.[a-z]{2,4})';
$email_regex = qr/^(.*?)(?<![-_a-z0-9@])($email_pattern)(?![-_a-z0-9@])(.*)$/i;
sub markup_emails {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;

   my $s = $ht{NORM_TEXT}->{$text_id};
   my $position = 0;

   while (($pre, $email, $post) = ($s =~ $email_regex)) {
      print LOG "*** markup_emails $pre :: $email :: $post\n" if $verbose && $tokenization_log_verbose;
      print LOG "*** email_pattern: $email_pattern\n" if $verbose && $tokenization_log_verbose;
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $email_length = $this->length_in_utf8_chars($email);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $email_length;
      my $email_id = $this->new_token_id(*ht, $text_id, "EMAIL");
      $this->register_markup(*ht, $text_id, $email_id, "EMAIL", $token_start, $token_end, $email, $verbose, 1, *LOG, "markup_emails", "norm");
      $position = $token_end;
      $s = $post;
   }
}

$handle_pattern = '(?:\@(?:[Aa1_]*[Aa1][Aa1_]*))'; # at least one letter or digit
$handle_regex = qr/^(.*?)(?<![_Aa1\@\#])($handle_pattern)(?![_Aa1\@\#])(.*)$/i;
sub markup_handles {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;

   my $text = $ht{NORM_TEXT}->{$text_id};
   my $typed_text = $ht{NORM_TYPED_TEXT}->{$text_id};
   my @s_chars = @{$ht{NORM_CHARS}->{$text_id}};
   my $typed_s = $typed_text;
   my $position = 0;
   print LOG "* markup_handles $text_id :: $text :: $typed_text ::\n" if $verbose && $tokenization_log_verbose;

   while (($pre, $typed_handle, $post) = ($typed_s =~ $handle_regex)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $handle_length = $this->length_in_utf8_chars($typed_handle);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $handle_length;
      my $handle = join("", @s_chars[$token_start .. ($token_end-1)]);
      my $handle_id = $this->new_token_id(*ht, $text_id, "HANDLE");
      $this->register_markup(*ht, $text_id, $handle_id, "HANDLE", $token_start, $token_end, $handle, $verbose, 1, *LOG, "markup_handles", "norm");
      $position = $token_end;
      $typed_s = $post;
   }
}

# Aa:Latin Bb:Cyrillic C:CJK c:(other)character Ee:Greek Jj:Jap.katakana/hiragana l:letter s:syllable
# Gg:Georgian Yy: Armenian R:Arabic H:Hebrew h:Ethiopic I:Indic
$hashtag_pattern = '(?:\#(?:[AaBbCcEeGgHhIJjlRsYy][_AaBbCcEeGgHhIJjlRsYy1]*[AaBbCcEeGgHhIJjlRsYy1]|[AaBbCcEeGgHhIJjlRsYy]))'; 
$hashtag_regex = qr/^(.*?)(?<![_AaBbCcEeGgHhIJjlRsYy1\@\#])($hashtag_pattern)(?![_AaBbCcEeGgHhIJjlRsYy1\@\#])(.*)$/i;
sub markup_hashtags {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;

   my $text = $ht{NORM_TEXT}->{$text_id};
   my $typed_text = $ht{NORM_TYPED_TEXT}->{$text_id};
   my @s_chars = @{$ht{NORM_CHARS}->{$text_id}};
   my $position = 0;
   my $typed_s = $typed_text;
   print LOG "* markup_hashtags $text_id :: $text :: $typed_text ::\n" if $verbose && $tokenization_log_verbose;

   while (($pre, $typed_hashtag, $post) = ($typed_s =~ $hashtag_regex)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $hashtag_length = $this->length_in_utf8_chars($typed_hashtag);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $hashtag_length;
      my $hashtag = join("", @s_chars[$token_start .. ($token_end-1)]);
      my $hashtag_id = $this->new_token_id(*ht, $text_id, "HASHTAG");
      $this->register_markup(*ht, $text_id, $hashtag_id, "HASHTAG", $token_start, $token_end, $hashtag, $verbose, 1, *LOG, "markup_hashtags", "norm");
      $position = $token_end;
      $typed_s = $post;
   }
}

sub markup_symbols {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;

   my $position;
   my $text = $ht{NORM_TEXT}->{$text_id};
   my $typed_text = $ht{NORM_TYPED_TEXT}->{$text_id};
   my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};
   print LOG "* markup_symbols $text_id :: $text :: $typed_text :: @norm_chars ::\n" if $verbose && $tokenization_log_verbose;

   $position = 0;
   my $typed_s = $typed_text;
   while (($pre, $typed_symbol, $post) = ($typed_s =~ /^(.*?)(S+(?:\xE2\x80\x8DS+)*)(.*)$/)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $symbol_length = $this->length_in_utf8_chars($typed_symbol);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $symbol_length;
      print LOG " * markup_symbols special_char_in_id $text_id, $token_start-$token_end\n" if $verbose && $tokenization_log_verbose;
      if ($this->special_char_in_id(*ht, $text_id, $token_start, $token_end)) {
         print LOG "  * markup_symbols special_char_in_id $text_id, $token_start-$token_end\n";
      }
      unless ($this->special_char_in_id(*ht, $text_id, $token_start, $token_end)) {
         my $symbol = join("", @norm_chars[$token_start .. ($token_end-1)]);
         my $symbol_id = $this->new_token_id(*ht, $text_id, "SYMBOL");
         $this->register_markup(*ht, $text_id, $symbol_id, "SYMBOL", $token_start, $token_end, $symbol, $verbose, 1, *LOG, "markup_symbols", "norm");
      }
      $position = $token_end;
      $typed_s = $post;
   }

   $position = 0;
   my $s = $text;
	 # ($token_text =~ /^(?:[-_*]|\xE2\x80[\x93\x94])+$/)
   while (($pre, $punct, $post) = ($s =~ /^(.*?)(\@(?:[:\/]|\xE2\x80[\x93\x94]|-+|_+|\*+)\@?|(?:[:\/]|\xE2\x80[\x93\x94]|-+|_+|\*+)\@|<?-+>?|<?=+>?|_{2,}|\*{2,}|\+{2,}|'{2,}|`{2,}|~{2,}|\.{2,}|\${2,}|\^{2,}|\/{2,})(.*)$/)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $punct_length = $this->length_in_utf8_chars($punct);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $punct_length;
    # print LOG "Point R1: $pre :: $punct  ($token_start-$token_end) :: $post\n";
      if ($this->span_contains_token_of_type(*ht, $text_id, *LOG, $token_start, ($token_start+1), "ABBREV", "WORD")) {
	 # chop off first character of punctuation
         $pre_length++;
	 $punct_length--;
	 $punct =~ s/^.[\x80-\xBF]*//;
	 $token_start++;
      }
    # print LOG "Point R2: $pre :: $punct  ($token_start-$token_end) :: $post\n";
      unless ($this->special_char_in_id(*ht, $text_id, $token_start, $token_end)
           || ($punct_length <= 1)) {
         my $punct_id = $this->new_token_id(*ht, $text_id, "PUNCT");
         $this->register_markup(*ht, $text_id, $punct_id, "PUNCT", $token_start, $token_end, $punct, $verbose, 1, *LOG, "markup_puncts", "norm");
      }
      $position = $token_end;
      $s = $post;
   }

   $position = 0;
   $s = $text;
   while (($pre, $punct, $post) = ($s =~ /^(.*?)((?:[-_\/\\:*=\@]|\xE2\x80[\x93\x94]){2,})(.*)$/)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $punct_length = $this->length_in_utf8_chars($punct);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $punct_length;
    # print LOG "Point R1: $pre :: $punct  ($token_start-$token_end) :: $post\n";
      unless (($pre =~ /\S$/)
           || ($post =~ /^\S/)
           || $this->special_char_in_id(*ht, $text_id, $token_start, $token_end)) {
         my $punct_id = $this->new_token_id(*ht, $text_id, "PUNCT");
         $this->register_markup(*ht, $text_id, $punct_id, "PUNCT", $token_start, $token_end, $punct, $verbose, 1, *LOG, "markup_punct_cluster", "norm");
	 $ht{PUNCT_CLUSTER_ACCEPT_COUNT}->{$punct} = ($ht{PUNCT_CLUSTER_ACCEPT_COUNT}->{$punct} || 0) + 1;
	 $ht{PUNCT_CLUSTER_ACCEPT_TEXT_ID}->{$punct}->{$text_id} = 1;
      }
      $position = $token_end;
      $s = $post;
   }
}

sub dominant_li_type {
   local($this, $text_id, $token_start, $token_end, *ht, *LOG) = @_;

   my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};
   my @norm_typed_chars = @{$ht{NORM_TYPED_CHARS}->{$text_id}};
   my $n_letters = 0;
   my $n_digits = 0;
   my $n_puncts = 0;
   my $n_others = 0;
   foreach $i (($token_start .. ($token_end-1))) {
      my $norm_typed_char = $norm_typed_chars[$i];
      if ($norm_typed_char =~ /^[AaBbCcEeGgHhIJjlRsYy]$/) {
         $n_letters++;
      } elsif ($norm_typed_char =~ /^[1]$/) {
         $n_digits++;
      } else {
         my $norm_char = $norm_chars[$i];
	 my $norm_char_type = $this->cached_character_type($norm_char, *ht);
	 if ($norm_char_type =~ /\bpunctuation$/) {
	    $n_puncts++;
	 } else {
	    $n_others++;
	 }
      }
   }
   return "WORD" if $n_letters;
   return "NUMBER" if $n_digits;
   return "PUNCT" if $n_punct;
   return "";
}

sub true_case_string_based_on_ref {
   local($this, $s, $ref, $text_id, *ht, *LOG, $verbose, *lang_codes) = @_;
   # s: come  ref: C'M (all caps)

   my $lang_code_s = join(" ", @lang_codes);
   return $result if defined($result = $ht{TRUE_CASE_STRING_BASED_ON_REF}->{$s}->{$ref}->{$lang_code_s}); # cached
   if ($s eq $ref) {
      $ht{TRUE_CASE_STRING_BASED_ON_REF}->{$s}->{$ref}->{$lang_code_s} = $s;
      return $s;
   }

   my @s_chars = $this->split_into_utf8_characters($s);
   my @ref_chars = $this->split_into_utf8_characters($ref);
   my @s_caseable_chars = ();
   my @ref_caseable_chars = ();
   my $first_lc_index = "";
   my $first_uc_index = "";
   my $n_lcs = 0;
   my $n_ucs = 0;
   my %alt_spelling_ht = ();
   foreach $i ((0 .. $#ref_chars)) {
      my $ref_char = $ref_chars[$i];
      if ($ht{LOWER_CASE_P}->{$ref_char}) {
	 $n_lcs++;
         $first_lc_index = $i if $first_lc_index eq "";
      }
      if ($ht{UPPER_CASE_P}->{$ref_char}) {
	 $n_ucs++;
         $first_uc_index = $i if $first_uc_index eq "";
      }
      foreach $lang_code (@lang_codes) {
	 $alt_spelling_ht{$norm_char} = $ref_char if $norm_char = $ht{LI_CHAR_NORM_SPELLING}->{$lang_code}->{$ref_char};
      }
      push(@ref_caseable_chars, $ref_char) if $ht{LOWER_CASE_P}->{$ref_char} || $ht{UPPER_CASE_P}->{$ref_char};
   }
   foreach $s_char (@s_chars) {
      push(@s_caseable_chars, $s_char) if $ht{LOWER_CASE_P}->{$s_char} || $ht{UPPER_CASE_P}->{$s_char};
   }
   my $same_caseable_chars_p = (join("", @ref_caseable_chars) eq join("", @s_caseable_chars));
   my $capitalization_style = "";
   if (($first_lc_index eq "") && ($first_uc_index ne "")) {
      $capitalization_style = "uc";
   } elsif (($first_lc_index ne "") && ($first_uc_index eq "")) {
      $capitalization_style = "lc";
   } elsif (($first_lc_index ne "") && ($first_uc_index ne "")) {
      if (($first_uc_index < $first_lc_index)) {
         $capitalization_style = "uc1";
      }
   }
   my $result = "";
   my $first_cased_letter_index = "";
   foreach $i ((0 .. $#s_chars)) {
      my $s_char = $s_chars[$i];
      if ($same_caseable_chars_p 
       && @s_caseable_chars
       && @ref_caseable_chars
       && ($s_char eq $s_caseable_chars[0])) {
         shift @s_caseable_chars;
	 my $ref_char = shift @ref_caseable_chars;
         $result .= $ref_char;
      } elsif ($ht{LOWER_CASE_P}->{$s_char}) {
         if (($capitalization_style eq "uc")
	  || (($capitalization_style eq "uc1") && ($first_cased_letter_index eq ""))) {
	    $result .= ((defined($uc_char = $ht{LOWER_TO_UPPER_CASE}->{$s_char})) ? $uc_char : $s_char);
	 } else {
	    $result .= $s_char;
	 }
	 $first_cased_letter_index = $i if $first_cased_letter_index eq "";
      } elsif ($ht{UPPER_CASE_P}->{$s_char}) {
         if (($capitalization_style eq "uc")
	  || (($capitalization_style eq "uc1") && ($first_cased_letter_index eq ""))) {
	    $result .= $s_char;
	 } else {
	    $result .= ((defined($lc_char = $ht{UPPER_TO_LOWER_CASE}->{$s_char})) ? $lc_char : $s_char);
	 }
	 $first_cased_letter_index = $i if $first_cased_letter_index eq "";
      } elsif (defined($alt_spelling = $alt_spelling_ht{$s_char})) {
         $result .= $alt_spelling;
      } else {
	 $result .= $s_char;
      }
   }
   $ht{TRUE_CASE_STRING_BASED_ON_REF}->{$s}->{$ref}->{$lang_code_s} = $result; # cache
 # print "** True case for $s => $result (ref: $ref lc: $lang_code_s) same_caseable_chars_p:$same_caseable_chars_p\n";
   return $result;
}

sub align_contraction {
   local($this, $li_token, $standard_contraction, $contr_norm, $alignment_s, $text_id, $token_start, $token_end, *ht, *contraction_align_ht, *LOG, $verbose, *lang_codes) = @_;

 # print LOG "  align_contraction $text_id ($token_start, $token_end) :: $li_token :: $standard_contraction :: $contr_norm :: $alignment_s\n" if $verbose && $tokenization_log_verbose;
   my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};
   my @norm_segments = split(/\s+/, $contr_norm);
   my $n_norm_segments = $#norm_segments + 1;
   my @alignment_segments;
   my @norm_segment_lengths = ();
   my $decomposable_p = 0;
   foreach $norm_segment (@norm_segments) {
      push(@norm_segment_lengths, $this->length_in_utf8_chars($norm_segment));
   }
   if ($alignment_s ne "") {
      @alignment_segments = split(/;\s*/, $alignment_s);
   } elsif (join("", @norm_segments) eq $standard_contraction) {
      $decomposable_p = 1;
      $contraction_align_ht{DECOMPOSABLE_P} = 1;
      my $position = 0;
      foreach $norm_segment_length (@norm_segment_lengths) {
	 my $segment_start = $position;
	 my $segment_end = $position+$norm_segment_length;
	 push(@alignment_segments, "$segment_start-$segment_end");
	 $position = $segment_end;
      }
      $alignment_s = join(";", @alignment_segments);
    # print LOG "m align_contraction $text_id ($token_start, $token_end) :: $li_token :: $standard_contraction :: $contr_norm :: $new_alignment_s\n" if $verbose && $tokenization_log_verbose;
   } elsif ($#norm_segments == 0) {
      my $standard_contraction_length = $this->length_in_utf8_chars($standard_contraction);
      @alignment_segments = ("0-$standard_contraction_length");
      $alignment_s = join(";", @alignment_segments);
   } else {
      print LOG "*** align-contraction problem: $standard_contraction/$contr_norm not linear. Provide alignment info.\n" if $tokenization_log_verbose;
      return "";
   }
   my $position = 0;
   my @align_directive_elements = ();
   my @li_token_chars = $this->split_into_utf8_characters($li_token);
   my @tc_norm_segments = ();
   foreach $i ((0 .. $#norm_segments)) {
      my $norm_segment = $norm_segments[$i];
      my $norm_segment_length = $norm_segment_lengths[$i];
      my $align_segment = $alignment_segments[$i];
      my $segment_start = $position;
      my $segment_end = $position+$norm_segment_length;
      my $norm_segment_span = "$segment_start-$segment_end";
      $position = $segment_end;
      my $align_directive_element = join(":", $norm_segment_span, $align_segment);
      push(@align_directive_elements, $align_directive_element);
      $contraction_align_ht{NORM_START}->{$i} = $segment_start;
      $contraction_align_ht{NORM_END}->{$i} = $segment_end;
      ($orig_start, $orig_end) = ($align_segment =~ /^(\d+)-(\d+)$/);
      $contraction_align_ht{ORIG_START}->{$i} = $orig_start;
      $contraction_align_ht{ORIG_END}->{$i} = $orig_end;
      my $li_sub_token  = join("", @li_token_chars[$orig_start .. ($orig_end-1)]);
      my $tc_norm_segment;
      if ($decomposable_p) {
	 $tc_norm_segment  = join("", @norm_chars[($token_start+$segment_start) .. ($token_start+$segment_end-1)]);
      } else {
	 $tc_norm_segment = $this->true_case_string_based_on_ref($norm_segment, $li_sub_token, $text_id, *ht, *LOG, $verbose, *lang_codes);
      }
      $contraction_align_ht{TRUE_CASE_NORM_SEGMENT_TEXT}->{$i} = $tc_norm_segment;
    # $contraction_align_ht{ALIGNMENT_DIRECTIVE_ELEMENT}->{$i} = $align_directive_element;
      push(@tc_norm_segments, $tc_norm_segment);
   }
   my $align_directive = join(";", @align_directive_elements);
   my $tc_norm_segment_s = join("", @tc_norm_segments);
   my $tc_norm_segment_s_w_spaces = join(" ", @tc_norm_segments);
   $contraction_align_ht{TRUE_CASE_NORM_TEXT} = $tc_norm_segment_s;
 # print LOG "    Aligned contraction $text_id ($token_start-$token_end): $li_token => $tc_norm_segment_s_w_spaces\n" if $verbose && $tokenization_log_verbose;
 # print LOG "    align_directive: $align_directive\n" if $tokenization_log_verbose;

   $contraction_align_ht{N} = $#norm_segments + 1;
   $contraction_align_ht{DIRECTIVE} = $align_directive;
   # align_directive: 0-3:0-2;4-7:2-5 (for example from new "can n't" to old "can't")

   return $align_directive;
}

sub markup_li_tokens {
   local($this, *ht, $text_id, *LOG, $verbose, *lang_codes) = @_;

   my $text = $ht{NORM_TEXT}->{$text_id};
   my $typed_text = $ht{NORM_TYPED_TEXT}->{$text_id};
   my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};
   my @norm_typed_chars = @{$ht{NORM_TYPED_CHARS}->{$text_id}};
   my @lc_norm_chars = ();
   my @reverse_lang_codes = reverse @lang_codes;
   foreach $char (@norm_chars) {
      $lc_char = $this->lower_case_char($char, *ht, $char);
      foreach $lang_code (@lang_codes)  {
         if ($norm_spelling_char = $ht{LI_CHAR_NORM_SPELLING}->{$lang_code}->{$lc_char}) {
	    $lc_char = $norm_spelling_char;
	    last;
	 }
      }
      push(@lc_norm_chars, $lc_char);
   }
   my $end_position = $#lc_norm_chars;
   print LOG "* markup_li_tokens $text_id :: $text :: $typed_text :: for " . ($matching_lang_code || "all languages") .  "\n" if $verbose && $tokenization_log_verbose;

   while ($end_position >= 0) {
      my $start_position = $end_position + 1;
      my $lc_tok_suffix = "";
      my $tc_tok_suffix = "";
      my $lc_tok_suffix_wo_period = "";
      my $tc_tok_suffix_wo_period = "";
      my $ends_in_period_p = ($norm_chars[$end_position] =~ /^(\.)$/);
      my @matching_lc_suffixes = ();
      my @matching_tc_suffixes = ();
      my @matching_start_positions = ();
      my @matching_end_positions = ();
      my @matching_lang_codes = ();

      # find max-length suffix
      while ($start_position >= 1) {
         $start_position--;
	 $lc_tok_suffix = $lc_norm_chars[$start_position] . $lc_tok_suffix;
	 $tc_tok_suffix = $norm_chars[$start_position] . $tc_tok_suffix;
	 if ($ends_in_period_p && ($start_position != $end_position)) {
	    $lc_tok_suffix_wo_period = $lc_norm_chars[$start_position] . $lc_tok_suffix_wo_period;
	    $tc_tok_suffix_wo_period = $norm_chars[$start_position] . $tc_tok_suffix_wo_period;
	 }
	 my $new_match = 0;
       # print LOG "    $start_position-$end_position: $lc_tok_suffix (@lang_codes)\n" if $text_id =~ /2/;
         foreach $lang_code (@reverse_lang_codes) {
            if ($ends_in_period_p && $ht{LI_TOKEN_SUFFIX_P}->{$lang_code}->{$lc_tok_suffix_wo_period}) {
	       $new_match = 1;
	       push(@matching_lc_suffixes, $lc_tok_suffix_wo_period);
	       push(@matching_tc_suffixes, $tc_tok_suffix_wo_period);
	       push(@matching_start_positions, $start_position);
	       push(@matching_end_positions, $end_position-1);
	       push(@matching_lang_codes, $lang_code);
	    }
	 }
         foreach $lang_code (@reverse_lang_codes) {
            if ($ht{LI_TOKEN_SUFFIX_P}->{$lang_code}->{$lc_tok_suffix}) {
	       $new_match = 1;
	       push(@matching_lc_suffixes, $lc_tok_suffix);
	       push(@matching_tc_suffixes, $tc_tok_suffix);
	       push(@matching_start_positions, $start_position);
	       push(@matching_end_positions, $end_position);
	       push(@matching_lang_codes, $lang_code);
	    }
         }
	 last unless $new_match;
      }
      # reduce to ensure full match
      my $matching_lc_suffix = "";
      my $matching_tc_suffix = "";
      my $matching_start_position = "";
      my $matching_end_position = "";
      my $matching_lang_code = "";
      my $spelling_correction = "";
      while (@matching_lc_suffixes) {
         $matching_lc_suffix = pop @matching_lc_suffixes;
         $matching_tc_suffix = pop @matching_tc_suffixes;
         $matching_start_position = pop @matching_start_positions;
         $matching_end_position = pop @matching_end_positions;
         $matching_lang_code = pop @matching_lang_codes;
	 $match_type = "";
       # print LOG "Point B: $text_id/$matching_start_position/$matching_lang_code/$matching_lc_suffix\n";
         if ((defined($ht{LI_TOKEN_ENTRY_P}->{$matching_lang_code}->{$matching_lc_suffix})
	         && ($match_type = "LI_TOKEN_ENTRY_P"))
	  || (defined($ht{NORM_ELEM_ENTRY_P}->{$matching_lang_code}->{$matching_lc_suffix}) 
	         && ($match_type = "NORM_ELEM_ENTRY_P"))
	  || (defined($ht{SPELLING_CORRECTION}->{$matching_lang_code}->{$matching_lc_suffix}) 
	         && ($match_type = "SPELLING_CORRECTION"))
	  || (defined($ht{SPELLING_NORMALIZATION}->{$matching_lang_code}->{$matching_lc_suffix}) 
	         && ($match_type = "SPELLING_NORMALIZATION"))) {
          # print LOG "Point C: $text_id/$matching_start_position/$matching_lang_code/$matching_lc_suffix $match_type\n";
            my $token_start = $matching_start_position;
            my $token_end = $matching_end_position + 1;
            my $li_token = join("", @norm_chars[$token_start .. ($token_end-1)]);
	    my $left_context_test_p = 0;
	    my $right_context_test_p = 0;
	    my $context;
	    my $context_regex;
	    my $impermissible_token_p = 0;
	    my $impermissible_left_context_p = 0;
	    my $impermissible_right_context_p = 0;
	    my $impermissibility_message = "";
	    my $start_char_type = $norm_typed_chars[$token_start];
            my $end_char_type = $norm_typed_chars[$token_end-1];
            my $prev_char_type = ($token_start > 0) ? $norm_typed_chars[$token_start-1] : " ";
	    my $next_char_type = ($token_end <= $#norm_chars) ? $norm_typed_chars[$token_end] : " ";
	    if ($context_regex = $ht{LI_TOKEN_LEFT_CONTEXT}->{$matching_lang_code}->{$matching_lc_suffix}) {
	       $left_context_test_p = 1;
	       $context = join("", @norm_chars[0 .. ($token_start-1)]);
	       unless ($context =~ /$context_regex/) {
	          $impermissible_left_context_p = 1;
	          $impermissibility_message = "left context ($context) does not match \/$context_regex\/";
	       }
	    }
	    if ($context_regex = $ht{LI_TOKEN_LEFT_TYPED_CONTEXT}->{$matching_lang_code}->{$matching_lc_suffix}) {
	       $left_context_test_p = 1;
	       $context = join("", @norm_typed_chars[0 .. ($token_start-1)]);
	       unless ($context =~ /$context_regex/) {
	          $impermissible_left_context_p = 1;
	          $impermissibility_message = "left typed context ($context) does not match \/$context_regex\/";
	       }
	    }
	    if ($context_regex = $ht{LI_TOKEN_RIGHT_CONTEXT}->{$matching_lang_code}->{$matching_lc_suffix}) {
	       $right_context_test_p = 1;
	       $context = join("", @norm_chars[$token_end .. $#norm_chars]);
	       unless ($context =~ /$context_regex/) {
	          $impermissible_right_context_p = 1;
	          $impermissibility_message = "right context ($context) does not match \/$context_regex\/";
	       }
	     # print "Point RE LI_TOKEN_RIGHT_CONTEXT $matching_lang_code $matching_lc_suffix :: $context :: $context_regex :: $impermissible_right_context_p\n";
	    }
	    if ($context_regex = $ht{LI_TOKEN_RIGHT_TYPED_CONTEXT}->{$matching_lang_code}->{$matching_lc_suffix}) {
	       $right_context_test_p = 1;
	       $context = join("", @norm_typed_chars[$token_end .. $#norm_typed_chars]);
	       unless ($context =~ /$context_regex/) {
	          $impermissible_right_context_p = 1;
	          $impermissibility_message = "right typed context ($context) does not match \/$context_regex\/";
	       }
	    }
	    unless ($left_context_test_p) {
	       if (($start_char_type =~ /^[AaBbcEeGgHhIJjlRsYy1]$/)
	        && ((lc $prev_char_type) eq (lc $start_char_type))) {
	          $impermissible_left_context_p = 1;
	          $impermissibility_message = "prev_char_type ($prev_char_type) clashes with start_char_type ($start_char_type)";
	       } elsif (($match_type eq "NORM_ELEM_ENTRY_P")
		     && ($start_char_type =~ /^[AaBbcdEeGgHhIJjlRsYy123']$/)
		     && ($prev_char_type  =~ /^[AaBbcdEeGgHhIJjlRsYy123']$/)) {
	          $impermissible_left_context_p = 1;
	          $impermissibility_message = "NORM_ELEM_ENTRY_P: prev_char_type ($prev_char_type) clashes with start_char_type ($start_char_type)";
	       } elsif (($ht{LI_R_CONTRACTION_NORM}->{$matching_lang_code}->{$matching_lc_suffix}
	              || $ht{LI_M_CONTRACTION_NORM}->{$matching_lang_code}->{$matching_lc_suffix})
	             && ($start_char_type eq "'")
	             && (! ($prev_char_type  =~ /^[AaBbcdEeGgHhIJjlRsYy123'.]$/))) {
	          $impermissible_left_context_p = 1;
	          $impermissibility_message = "LI_R_CONTRACTION_NORM: prev_char_type ($prev_char_type) clashes with start_char_type ($start_char_type)";
	       }
	    }
	    unless ($right_context_test_p) {
	       if (($end_char_type =~ /^[AaBbcEeGgHhIJjlRsYy1]$/)
	        && ((lc $next_char_type) eq (lc $end_char_type))) {
	          $impermissible_right_context_p = 1;
	          $impermissibility_message = "end_char_type ($end_char_type) clashes with next_char_type ($next_char_type)";
	       } elsif (($match_type eq "NORM_ELEM_ENTRY_P")
		     && ($end_char_type =~ /^[AaBbcdEeGgHhIJjlRsYy123']$/)
		     && ($next_char_type  =~ /^[AaBbcdEeGgHhIJjlRsYy123']$/)) {
	          $impermissible_right_context_p = 1;
	          $impermissibility_message = "NORM_ELEM_ENTRY_P: end_char_type ($end_char_type) clashes with next_char_type ($next_char_type)";
	       } elsif (($ht{LI_L_CONTRACTION_NORM}->{$matching_lang_code}->{$matching_lc_suffix}
	              || $ht{LI_M_CONTRACTION_NORM}->{$matching_lang_code}->{$matching_lc_suffix})
	             && ($end_char_type eq "'")
	             && (! ($next_char_type  =~ /^[AaBbcdEeGgHhIJjlRsYy123']$/))) {
	          $impermissible_right_context_p = 1;
	          $impermissibility_message = "LI_L_CONTRACTION_NORM: end_char_type ($end_char_type) clashes with next_char_type ($next_char_type)";
	       }
	    }
	    my @case_invariants = keys %{$ht{CASE_INVARIANT}->{$matching_lang_code}->{$matching_lc_suffix}};
	    if (@case_invariants && (! $ht{CASE_INVARIANT}->{$matching_lang_code}->{$matching_lc_suffix}->{$matching_tc_suffix})) {
	     # print LOG "*** case_invariant conflict $matching_lang_code $matching_lc_suffix $matching_tc_suffix\n";
	       $impermissible_token_p = 1;
	       $impermissibility_message = "Match requires proper case ($matching_tc_suffix)";
	    }
	    # Except, preserve contraction norm elems (if they are already a token)
	    if (($impermissible_left_context_p || $impermissible_right_context_p)
	     && ($ht{LI_L_CONTRACTION_NORM}->{$matching_lang_code}->{$matching_lc_suffix}
	      || $ht{LI_M_CONTRACTION_NORM}->{$matching_lang_code}->{$matching_lc_suffix}
	      || $ht{LI_R_CONTRACTION_NORM}->{$matching_lang_code}->{$matching_lc_suffix}
	      || $ht{NORM_ELEM_ENTRY_P}->{$matching_lang_code}->{$matching_lc_suffix})
	     && (! ($prev_char_type =~ /^[AaBbcdEeGgHhIJjlRsYy123']$/))
	     && (! ($next_char_type =~ /^[AaBbcdEeGgHhIJjlRsYy123']$/))) {
	       $impermissible_left_context_p = 0;
	       $impermissible_right_context_p = 0;
	       $impermissibility_message = "standalone NORM_ELEM_ENTRY_P token $li_token between prev_char_type ($prev_char_type) and next_char_type ($next_char_type)";
	    }
	  # print LOG "Point D: $text_id/$matching_start_position/$matching_lang_code/$matching_lc_suffix IL:$impermissible_left_context_p IR:$impermissible_right_context_p\n";
	    if ($impermissible_left_context_p || $impermissible_right_context_p || $impermissible_token_p) {
	       if ($verbose && $tokenization_log_verbose) {
	          print LOG "- Reject $matching_lang_code li-token $text_id: $li_token ($token_start-$token_end) -- $impermissibility_message --";
                  print LOG " with impermissible left context ($impermissible_left_context)" if $impermissible_left_context;
                  print LOG " with impermissible right context ($impermissible_right_context)" if $impermissible_right_context;
                  print LOG " with impermissible case ($matching_tc_suffix)" if $impermissible_token_p;
	          print LOG "\n";
	       }
	    } else {
	       # found valid li-token
	       print LOG "+ Accept li-token $text_id: $li_token ($token_start-$token_end) $impermissibility_message\n"
	          if $verbose && $tokenization_log_verbose && $impermissibility_message;
	     # print LOG "Found valid li-token $matching_lc_suffix $matching_start_position $matching_lang_code\n";
	       last;
	    }
	 }
         $matching_lc_suffix = "";
         $matching_start_position = "";
         $matching_lang_code = "";
      }
    # print LOG "  Point E $text_id $matching_lc_suffix ($matching_start_position/$matching_end_position) $matching_lang_code\n" if $matching_lc_suffix;
      if ($matching_start_position ne "") {
         my $token_start = $matching_start_position;
         my $token_end = $matching_end_position + 1;
         my $li_token = join("", @norm_chars[$token_start .. ($token_end-1)]);
	 my $change_in_length_p = 0;
	 my $corrected_spelling;
	 my $tc_corrected_spelling;
	 if ($match_type eq "SPELLING_CORRECTION") {
	    $corrected_spelling = $ht{TOKEN_CORRECTED_SPELLING}->{$matching_lang_code}->{$matching_lc_suffix};
	    $tc_corrected_spelling = $this->true_case_string_based_on_ref($corrected_spelling, $li_token, $text_id, *ht, *LOG, $verbose, *lang_codes);
	  # print "TC: $corrected_spelling (ref: $li_token) -> $tc_corrected_spelling\n";
	    $li_token_length = $token_end - $token_start;
	    $tc_corrected_spelling_length = $this->length_in_utf8_chars($tc_corrected_spelling);
	    $change_in_length_p = 1 unless $li_token_length == $tc_corrected_spelling_length;
	 }
	 if ($ht{LI_TOKEN_ADD_ABBREV_PERIOD_IF_MISSING_P}->{$matching_lang_code}->{$matching_lc_suffix}) {
	    $li_token .= ".";
	    $change_in_length_p = 1;
	 }
	 my $dominant_type = $this->dominant_li_type($text_id, $token_start, $token_end, *ht, *LOG) || "LI-TOKEN";
       # print LOG "  Matched $text_id $matching_lc_suffix ($token_start-$token_end)\n";
	 # check for token
	 my $prov;
         if (($ht{LI_TOKEN_P}->{$matching_lang_code}->{$matching_lc_suffix} && ($prov = "markup_li_tokens"))
	  || ($ht{NORM_ELEM_ENTRY_P}->{$matching_lang_code}->{$matching_lc_suffix} && ($prov = "markup norm-elem"))
	  || ($ht{SPELLING_CORRECTION}->{$matching_lang_code}->{$matching_lc_suffix} && ($prov = "spelling-correction"))
	  || ($ht{SPELLING_NORMALIZATION}->{$matching_lang_code}->{$matching_lc_suffix} && ($prov = "spelling-normalization"))) {
	    my $type = $ht{LI_TOKEN_TYPE}->{$matching_lang_code}->{$matching_lc_suffix} || "";
            unless ($this->span_contains_token_of_type(*ht, $text_id, *LOG, $token_start, $token_end, "URL", "XML-TAG")) {
             # print LOG "+ li-token $text_id $li_token ($token_start-$token_end) TOKEN-P\n";
               my $li_token_id = $this->new_token_id(*ht, $text_id, $dominant_type);
	       my $corrected_li_token = $tc_corrected_spelling || $li_token;
               $this->register_markup(*ht, $text_id, $li_token_id, $dominant_type, $token_start, $token_end, $corrected_li_token, $verbose, 1, *LOG, $prov, "norm");
               $this->update_norm_text(*ht, $text_id, $token_start, $token_end, $corrected_li_token, "", *LOG, $verbose) if $change_in_length_p;
	       $ht{TOKEN_ETYM}->{$text_id}->{$li_token_id} = $etym_lang_code if $etym_lang_code = $ht{LI_TOKEN_ETYM}->{$matching_lang_code}->{$matching_lc_suffix};
	       $ht{TOKEN_NE_TYPE}->{$text_id}->{$li_token_id} = $ne_type if $ne_type = $ht{LI_TOKEN_NE_TYPE}->{$matching_lang_code}->{$matching_lc_suffix};
	       my $abbrev_expansion = $ht{LI_TOKEN_ABBREV_EXPANSION}->{$matching_lang_code}->{$matching_lc_suffix};
	       if ($abbrev_expansion) {
	          $ht{TOKEN_ABBREV_EXPANSION}->{$text_id}->{$li_token_id} = $abbrev_expansion;
                  my $orig_token_start = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$token_start};
                  my $orig_token_end   = $ht{NORM_TO_ORIG_VERTEX_MAP_L}->{$text_id}->{$token_end};
		  if (defined($orig_token_start) && defined($orig_token_end)) {
		     my @registered_span_token_ids = keys %{$ht{SPAN_ID}->{$text_id}->{$orig_token_start}->{$orig_token_end}};
		     foreach $registered_span_token_id (@registered_span_token_ids) {
		        next if $registered_span_token_id eq $li_token_id;
                        my $registered_span_token_type = $ht{TOKEN_TYPE}->{$text_id}->{$registered_span_token_id};
		        if ($this->member($registered_span_token_type, "ABBREV")
			 && $ht{TOKEN_ACTIVE_P}->{$text_id}->{$registered_span_token_id}) {
                           $ht{TOKEN_ACTIVE_P}->{$text_id}->{$registered_span_token_id} = 0;
			   print LOG "Deactiv. markup $registered_span_token_type $text_id $registered_span_token_id ($orig_token_start-$orig_token_end/$token_start-$token_end) $corrected_li_token\n" 
			      if ($verbose && $tokenization_log_verbose)
			      || $ht{MARKUP_ID_VERBOSE}->{$text_id}->{$registered_span_token_id};
			}
		     }
		  }
	       }
	       $ht{TOKEN_TAXON}->{$text_id}->{$li_token_id} = $taxon if $taxon = $ht{LI_TOKEN_TAXON}->{$matching_lang_code}->{$matching_lc_suffix};
	       $ht{TOKEN_GLOSS}->{$text_id}->{$li_token_id}->{"eng"} = $eng_gloss if $eng_gloss = $ht{LI_TOKEN_GLOSS}->{$matching_lang_code}->{"eng"}->{$matching_lc_suffix};
	       $ht{TOKEN_ORIGINAL_MISSPELLING}->{$text_id}->{$li_token_id} = $li_token if $prov eq "spelling-correction";
	       my $abbrev_expansion2 = $ht{TOKEN_ABBREV_EXPANSION}->{$text_id}->{$li_token_id} || "";
	       if ($type =~ /^(symbol)$/i) {
	          $ht{TOKEN_TYPE}->{$text_id}->{$li_token_id} = uc $type;
	       } else {
	          $ht{TOKEN_SUB_TYPE}->{$text_id}->{$li_token_id} = $type;
	       }
	       foreach $normalized_spelling (keys %{$ht{TOKEN_NORMALIZED_SPELLING}->{$matching_lang_code}->{$matching_lc_suffix}}) {
	          my $tc_normalized_spelling = $this->true_case_string_based_on_ref($normalized_spelling, $li_token, $text_id, *ht, *LOG, $verbose, *lang_codes);
                  my $alt_token_id = $this->new_token_id(*ht, $text_id, $dominant_type);
                  $this->register_markup(*ht, $text_id, $alt_token_id, $dominant_type, $token_start, $token_end, $tc_normalized_spelling, $verbose, 1, *LOG, $prov, "norm");
	          $ht{TOKEN_ETYM}->{$text_id}->{$alt_token_id} = $etym_lang_code if $etym_lang_code = $ht{LI_TOKEN_ETYM}->{$matching_lang_code}->{$matching_lc_suffix};
	          $ht{TOKEN_NE_TYPE}->{$text_id}->{$alt_token_id} = $ne_type if $ne_type = $ht{LI_TOKEN_NE_TYPE}->{$matching_lang_code}->{$matching_lc_suffix};
	          $ht{TOKEN_ABBREV_EXPANSION}->{$text_id}->{$alt_token_id} = $abbrev_expansion if $abbrev_expansion = $ht{LI_TOKEN_ABBREV_EXPANSION}->{$matching_lang_code}->{$matching_lc_suffix};
	          $ht{TOKEN_TAXON}->{$text_id}->{$alt_token_id} = $taxon if $taxon = $ht{LI_TOKEN_TAXON}->{$matching_lang_code}->{$matching_lc_suffix};
	          $ht{TOKEN_GLOSS}->{$text_id}->{$alt_token_id}->{"eng"} = $eng_gloss if $eng_gloss = $ht{LI_TOKEN_GLOSS}->{$matching_lang_code}->{"eng"}->{$matching_lc_suffix};
	          $ht{TOKEN_ORIGINAL_SPELLING}->{$text_id}->{$alt_token_id} = $li_token;
                  $ht{ALT_TOKEN_P}->{$text_id}->{$alt_token_id} = 1;
		  $ht{ALT_TOKENS}->{$text_id}->{$li_token_id}->{$alt_token_id} = 1;
	       }
	    }
	 # check for contraction
         } elsif ($contr_norm = $ht{LI_CONTRACTION_NORM}->{$matching_lang_code}->{$matching_lc_suffix}) {
	    my $contr_norm2 = $ht{LI_CONTRACTION_NORM2}->{$matching_lang_code}->{$matching_lc_suffix};
	    my $standard_contraction = $ht{LI_CONTRACTION_CONTRACTION}->{$matching_lang_code}->{$matching_lc_suffix};
	    # $contr_norm e.g. come on
	    my $alignment_s = $ht{LI_CONTRACTION_ALIGNMENT_S}->{$matching_lang_code}->{$matching_lc_suffix} || "";
	    %contraction_align_ht = ();
	    my $align_directive = $this->align_contraction($li_token, $standard_contraction, $contr_norm, $alignment_s, $text_id, $token_start, $token_end, *ht, *contraction_align_ht, *LOG, $verbose, *lang_codes);
	    my $decomposable_p = $contraction_align_ht{DECOMPOSABLE_P};
            my $n_norm_segments = $contraction_align_ht{N};
            my $tc_norm_segment_s = $contraction_align_ht{TRUE_CASE_NORM_TEXT};
	    foreach $i ((0 .. ($n_norm_segments-1))) {
               my $orig_segment_start = $contraction_align_ht{ORIG_START}->{$i};
               my $orig_segment_end   = $contraction_align_ht{ORIG_END}->{$i};
               my $norm_segment_start = $contraction_align_ht{NORM_START}->{$i};
               my $norm_segment_end   = $contraction_align_ht{NORM_END}->{$i};
	     # print LOG "      o:$orig_segment_start-$orig_segment_end n:$norm_segment_start-$norm_segment_end\n";
	       if (defined($orig_segment_start) && defined($orig_segment_end)
                && defined($norm_segment_start) && defined($norm_segment_end)) {
                  my $orig_sub_token_start = $token_start + $orig_segment_start;
                  my $orig_sub_token_end   = $token_start + $orig_segment_end;
                  my $norm_sub_token_start = $token_start + $norm_segment_start;
                  my $norm_sub_token_end   = $token_start + $norm_segment_end;
		  my $sub_token_text = ($decomposable_p)
 		                       ? join("", @norm_chars[$norm_sub_token_start .. ($norm_sub_token_end-1)])
                                       : $contraction_align_ht{TRUE_CASE_NORM_SEGMENT_TEXT}->{$i};
                  my $contraction_id = $this->new_token_id(*ht, $text_id, $dominant_type);
		# print LOG "++REG.M. $text_id $sub_token_text ($orig_sub_token_start-$orig_sub_token_end) $contraction_id $dominant_type\n";
                  $this->register_markup(*ht, $text_id, $contraction_id, $dominant_type, $orig_sub_token_start, $orig_sub_token_end, $sub_token_text, $verbose, 1, *LOG, "markup_li_contr", "norm");
                  $ht{TOKEN_SUB_TYPE}->{$text_id}->{$contraction_id} = "$dominant_type (part of contraction)"
		     if $n_norm_segments >= 2;
	       }
	    }
	  # print LOG "++UPDATE $text_id $tc_norm_segment_s ($token_start-$token_end) $align_directive\n";
            $this->update_norm_text(*ht, $text_id, $token_start, $token_end, $tc_norm_segment_s, $align_directive, *LOG, $verbose) unless $decomposable_p;
          # print LOG "+ li-token $text_id $li_token ($token_start-$token_end) CONTRACTION $contr_norm :: $alignment_s\n";
         } elsif ($l_contr_norm = $ht{LI_L_CONTRACTION_NORM}->{$matching_lang_code}->{$matching_lc_suffix}) {
          # print LOG "+ li-token $text_id $li_token ($token_start-$token_end) L-CONTRACTION $l_contr_norm\n";
            my $li_token_id = $this->new_token_id(*ht, $text_id, $dominant_type);
            $this->register_markup(*ht, $text_id, $li_token_id, $dominant_type, $token_start, $token_end, $li_token, $verbose, 1, *LOG, "markup_li_l_contr", "norm");
         } elsif ($m_contr_norm = $ht{LI_M_CONTRACTION_NORM}->{$matching_lang_code}->{$matching_lc_suffix}) {
          # print LOG "+ li-token $text_id $li_token ($token_start-$token_end) M-CONTRACTION $m_contr_norm\n";
            my $li_token_id = $this->new_token_id(*ht, $text_id, $dominant_type);
            $this->register_markup(*ht, $text_id, $li_token_id, $dominant_type, $token_start, $token_end, $li_token, $verbose, 1, *LOG, "markup_li_m_contr", "norm");
         } elsif ($r_contr_norm = $ht{LI_R_CONTRACTION_NORM}->{$matching_lang_code}->{$matching_lc_suffix}) {
          # print LOG "+ li-token $text_id $li_token ($token_start-$token_end) R-CONTRACTION $r_contr_norm\n";
            my $li_token_id = $this->new_token_id(*ht, $text_id, $dominant_type);
            $this->register_markup(*ht, $text_id, $li_token_id, $dominant_type, $token_start, $token_end, $li_token, $verbose, 1, *LOG, "markup_li_r_contr", "norm");
         }
         $end_position = $token_start - 1;
      } else {
         $end_position--;
      }
   }
}

sub markup_encoding_errors {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;

   my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};

   my $end_position = $#norm_chars;
   print LOG "* markup_encoding_errors $text_id :: @norm_chars\n" if $verbose && $tokenization_log_verbose;

   while ($end_position >= 0) {
      my $start_position = $end_position + 1;
      my $incorrect_suffix = "";
      my @matching_suffixes = ();
      my @matching_start_positions = ();

      # find max-length suffix
      while ($start_position >= 1) {
         $start_position--;
	 $incorrect_suffix = $norm_chars[$start_position] . $incorrect_suffix;
         if ($ht{ENCODING_CORRECTION_SUFFIX_P}->{$incorrect_suffix}) {
	    push(@matching_suffixes, $incorrect_suffix);
	    push(@matching_start_positions, $start_position);
	 } else {
	    last;
	 }
      }
      my $matching_suffix = "";
      my $matching_start_position = "";
      my $correct = "";
      my $new_end_position = "";
      while (@matching_suffixes) {
         $matching_suffix = pop @matching_suffixes;
         $matching_start_position = pop @matching_start_positions;
         if (defined($correct = $ht{ENCODING_CORRECTION}->{$matching_suffix})) {
            my $token_start = $matching_start_position;
            my $token_end = $end_position + 1;
            my $incorrect = join("", @norm_chars[$token_start .. ($token_end-1)]);
            my $encoding_correction_id = $this->new_token_id(*ht, $text_id, "ENCODING-CORRECTION");
            $this->register_markup(*ht, $text_id, $encoding_correction_id, "ENCODING-CORRECTION", $token_start, $token_end, $correct, $verbose, 0, *LOG, "markup_encoding_error", "norm");
            $ht{TOKEN_ORIG_TEXT}->{$text_id}->{$encoding_correction_id} = $incorrect;
            $this->update_norm_text(*ht, $text_id, $token_start, $token_end, $correct, "", *LOG, $verbose);
            $new_end_position = $matching_start_position - 1;
	    last;
	 }
      }
      if ($new_end_position =~ /^\d+$/) {
         $end_position = $new_end_position;
      } elsif (defined($char = $norm_chars[$end_position])
	    && (! $utf8->valid_utf8_string_incl_ascii_control_p($char))) {
         my $token_start = $end_position;
         my $token_end = $end_position + 1;
         my $encoding_correction_id = $this->new_token_id(*ht, $text_id, "ENCODING-CORRECTION");
	 my $utf8_replacement_char = "\xEF\xBF\xBD";
         $this->register_markup(*ht, $text_id, $encoding_correction_id, "ENCODING-CORRECTION", $token_start, $token_end, $utf8_replacement_char, $verbose, 0, *LOG, "invalid UTF8 char", "norm");
         $ht{TOKEN_ORIG_TEXT}->{$text_id}->{$encoding_correction_id} = $char;
         $this->update_norm_text(*ht, $text_id, $token_start, $token_end, $utf8_replacement_char, "", *LOG, $verbose);
         $end_position--;
      } else {
         $end_position--;
      }
   }
}

sub realign_pre_in_post {
   local($this, $pre, $in, $post, $position, $n_left_realign, $n_right_realign, *ht, $text_id, *LOG, $verbose) = @_;

   if ($n_left_realign > 0) {
      foreach $i ((1 .. $n_left_realign)) {
         if (($c, $rest) = ($in =~ /^(.[\x80-\xBF]*)(.*)$/)) {
	    $pre .= $c;
	    $in = $rest;
	 } else {
	    print LOG "*** realign_pre_in_post error $text_id :: $pre :: $in :: $post :: L:$i/$n_left_realign\n" if $tokenization_log_verbose;
	    last;
	 }
      }
   } elsif ($n_left_realign < 0) {
      foreach $i ((1 .. (abs $n_left_realign))) {
         if (($rest, $c) = ($pre =~ /^(.*)(.[\x80-\xBF]*)$/)) {
	    $pre = $rest;
	    $in = "$c$in";
	 } else {
	    print LOG "*** realign_pre_in_post error $text_id :: $pre :: $in :: $post :: L:$i/$n_left_realign\n" if $tokenization_log_verbose;
	    last;
	 }
      }
   }
   if ($n_right_realign > 0) {
      foreach $i ((1 .. $n_right_realign)) {
         if (($c, $rest) = ($post =~ /^(.[\x80-\xBF]*)(.*)$/)) {
	    $in .= $c;
	    $post = $rest;
         } else {
	    print LOG "*** realign_pre_in_post error $text_id :: $pre :: $in :: $post :: r:$i/$n_right_realign\n" if $tokenization_log_verbose;
	    last;
	 }
      }
   } elsif ($n_right_realign < 0) {
      foreach $i ((1 .. (abs $n_right_realign))) {
         if (($rest, $c) = ($in =~ /^(.*)(.[\x80-\xBF]*)$/)) {
	    $in = $rest;
	    $post = "$c$post";
	 } else {
	    print LOG "*** realign_pre_in_post error $text_id :: $pre :: $in :: $post :: r:$i/$n_right_realign\n" if $tokenization_log_verbose;
	    last;
	 }
      }
   }
   my $pre_length = $this->length_in_utf8_chars($pre);
   my $in_length = $this->length_in_utf8_chars($in);
   my $token_start = $position + $pre_length;
   my $token_end = $token_start + $in_length;
   return ($pre, $in, $post, $token_start, $token_end);
}

sub trim_or_ditch_mname {
   local($this, $text_id, $token_start, $token_end, *ht, $text_id, *LOG, $verbose) = @_;
   # trim mname to make it para-balanced, dropping matching paired outer paras, non-matching single paras (incl. at end)

   my @typed_chars = @{$ht{NORM_TYPED_CHARS}->{$text_id}};
   my $typed_mname = join("", @typed_chars[$token_start .. ($token_end-1)]);
   my $orig_typed_mname = $typed_mname;
   my $n_dropped_left_chars = 0;
   my $n_dropped_right_chars = 0;
   my $error = "";

   # drop paired paras at ends of $typed_mname (e.g. "(X11)")
   my $pre;
   my $core;
   my $post;
   while ((($left_para, $core, $right_para) = ($typed_mname =~ /^([\(\[\{])(.*)([\}\]\)])$/))
       && ((($left_para eq "(") && $right_para eq ")")
        || (($left_para eq "[") && $right_para eq "]")
        || (($left_para eq "{") && $right_para eq "}"))) {
      $typed_mname = $core;
      $n_dropped_left_chars++;
      $n_dropped_right_chars++;
   }
   while (($core) = ($typed_mname =~ /^_(.*)$/)) {
      $typed_mname = $core;
      $n_dropped_left_chars++;
   }
   while (($core) = ($typed_mname =~ /^(.*)_$/)) {
      $typed_mname = $core;
      $n_dropped_right_chars++;
   }

   if (($pre, $left_para, $post) = ($typed_mname =~ /^([^\(\)\[\]\{\}]*)([\(\[\{])([^\(\)\[\]\{\}]*)$/)) {
      $typed_mname = $post;
      $n_dropped_left_chars += $this->length_in_utf8_chars($pre) + 1;
   }
   if (($pre, $right_para, $post) = ($typed_mname =~ /^([^\(\)\[\]\{\}]*)([\}\]\)])([^\(\)\[\]\{\}]*)$/)) {
      $typed_mname = $pre;
      $n_dropped_right_chars += $this->length_in_utf8_chars($post) + 1;
   }

   my $para_s = $typed_mname;
   $para_s =~ s/[^\(\)\[\]\{\}]//g;
   while (($pre, $post) = ($para_s =~ /^(.*)(?:\(\)|\[\]|\{\})(.*)$/)) {
      $para_s = "$pre$post";
   }
   unless ($para_s eq "") {
      $error = "unbalanced para";
   }

   return ($error, $n_dropped_left_chars, $n_dropped_right_chars, $orig_typed_mname, $typed_mname);
}

sub markup_words {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;

   my $position = 0;
   my $typed_s = $ht{NORM_TYPED_TEXT}->{$text_id};
   my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};
   print LOG "* markup_words $text_id :: $typed_s :: @norm_chars ::\n" if $verbose && $tokenization_log_verbose;

   while (($pre, $typed_word, $post) = ($typed_s =~ /^(.*?)([Aa]+(?:'[Aa]+)+|[Aa]+|[Bb]+|C+|[Ee]+|[Gg]+|H+|h+|I+|J+|j+|l+|R+|s+|[Yy]+|c+)(.*)$/)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $word_length = $this->length_in_utf8_chars($typed_word);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $word_length;
      my $n_left_special_chars = 0;
      my $n_reg_chars = 0;
      foreach $i (($token_start .. ($token_end-1))) {
         if ($this->special_char_in_id(*ht, $text_id, $i)) {
	    $n_left_special_chars++;
	 } else {
	    last;
	 }
      }
      foreach $i ((($token_start+$n_left_special_chars) .. ($token_end-1))) {
         if ($this->special_char_in_id(*ht, $text_id, $i)) {
	    last;
	 } else {
	    $n_reg_chars++;
	 }
      }
      my $word = join("", @norm_chars[$token_start .. ($token_end-1)]);
      if ($n_reg_chars) {
         my $n_right_special_chars = $word_length - $n_left_special_chars - $n_reg_chars;
	 my $orig_token_start = $token_start;
	 my $orig_token_end = $token_end;
	 my $orig_word = $word;
         ($pre, $in, $post, $token_start, $token_end) = $this->realign_pre_in_post($pre, $typed_word, $post, $position, $n_left_special_chars, -$n_right_special_chars, *ht, $text_id, *LOG, $verbose);
	 unless ($this->span_contains_token_of_type(*ht, $text_id, *LOG, $token_start, $token_end, "URL", "XML-TAG")) {
            $word = join("", @norm_chars[$token_start .. ($token_end-1)]);
	    if ($verbose && $tokenization_log_verbose && ! (($token_start == $orig_token_start) && ($token_end == $orig_token_end))) {
	       print LOG "* markup_words adjust: $text_id $orig_word ($orig_token_start-$orig_token_end) to $word ($token_start-$token_end)\n";
	    }
            my $word_id = $this->new_token_id(*ht, $text_id, "WORD");
            $this->register_markup(*ht, $text_id, $word_id, "WORD", $token_start, $token_end, $word, $verbose, 1, *LOG, "markup_words", "norm");
	 }
      } elsif ($verbose && $tokenization_log_verbose) {
         print LOG "* markup_words reject: $text_id $word ($token_start-$token_end) due to specials inside.\n";
      }
      $position = $token_end;
      $typed_s = $post;
   }
}

sub hash_table_lookup_with_lang_codes {
   local($this, *ht, *lang_codes, $control, @x_args) = @_;

   my $result;
   my $lang_code;
   if ($control eq "X-LC-X") {
      foreach $lang_code (@lang_codes) {
         return $result if $result = $ht{$x_args[0]}->{$lang_code}->{$x_args[1]};
      }
   }
   return "";
}

$roman_numeral_pattern = "(?:M|MM)?(?:C|CC|CCC|CD|D|DC|DCC|DCCC|CM)?(?:X|XX|XXX|XL|L|LX|LXX|LXXX|XC)?(?:I|II|III|IV|V|VI|VII|VIII|IX)?";
sub markup_mnames {
   local($this, *ht, $text_id, *LOG, $verbose, *lang_codes) = @_;
   # AB&C, AK-47, TFG-beta2

   my $position;
   my $text = $ht{NORM_TEXT}->{$text_id};
   my @norm_typed_chars;

   # AB&C
   if ($text =~ /[A-Z]&[A-Z]/) {
      $position = 0;
      $text = $ht{NORM_TEXT}->{$text_id};
      @norm_typed_chars = @{$ht{NORM_TYPED_CHARS}->{$text_id}};
      while (($pre, $mname, $post) = ($text =~ /^(.*?)([A-Z]{1,2}&[A-Z]{1,2}(?:s)?)(.*)$/)) {
         my $pre_length = $this->length_in_utf8_chars($pre);
         my $mname_length = $this->length_in_utf8_chars($mname);
         my $token_start = $position + $pre_length;
         my $token_end = $token_start + $mname_length;
         unless ($this->special_char_in_id(*ht, $text_id, $token_start, $token_end)
              || ($mname_length <= 1)
              || (($token_start > 0) && ($norm_typed_chars[$token_start-1] =~ /[Aa]$/))
              || (($token_end < $ht{NORM_END}->{$text_id}) && ($norm_typed_chars[$token_end] =~ /^[Aa]/))) {
            my $mname_id = $this->new_token_id(*ht, $text_id, "M-NAME");
            $this->register_markup(*ht, $text_id, $mname_id, "M-NAME", $token_start, $token_end, $mname, $verbose, 1, *LOG, "markup_mname_ampersand", "norm");
         }
         $position = $token_end;
         $text = $post;
      }
      $text = $ht{NORM_TEXT}->{$text_id};
   }

   # DNA-sequence 5'-CAGCTGGCCAGGCTCTCGGT-3'
   if ($text =~ /[ACGT]{6,}/) {
      $position = 0;
      @norm_typed_chars = @{$ht{NORM_TYPED_CHARS}->{$text_id}};
      while (($pre, $mname, $post) = ($text =~ /^(.*?)((?:[35](?:'|\xE2\x80[\xB2\x99])?-?)?[ACGT]{6,}(?:-?[35](?:'|\xE2\x80[\xB2\x99])?)?)(.*)$/)) {
         my $pre_length = $this->length_in_utf8_chars($pre);
         my $mname_length = $this->length_in_utf8_chars($mname);
         my $token_start = $position + $pre_length;
         my $token_end = $token_start + $mname_length;
         unless ((($token_start > 0) && ($norm_typed_chars[$token_start-1] =~ /[Aa1]$/))
              || (($token_end < $ht{NORM_END}->{$text_id}) && ($norm_typed_chars[$token_end] =~ /^[Aa1]/))) {
            my $mname_id = $this->new_token_id(*ht, $text_id, "M-NAME");
            $this->register_markup(*ht, $text_id, $mname_id, "M-NAME", $token_start, $token_end, $mname, $verbose, 1, *LOG, "markup_mname_ampersand", "norm");
            $ht{TOKEN_SUB_TYPE}->{$text_id}->{$mname_id} = "DNA sequence";
         }
         $position = $token_end;
         $text = $post;
      }
      $text = $ht{NORM_TEXT}->{$text_id};
   }

   $position = 0;
   $text = $ht{NORM_TEXT}->{$text_id};
   my $typed_text = $ht{NORM_TYPED_TEXT}->{$text_id};
   my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};
   print LOG "* markup_mnames $text_id :: $text :: $typed_text ::\n" if $verbose && $tokenization_log_verbose;

   my $pre;
   my $typed_mname; 
   my $post;
   while (($pre, $typed_mname, $post) = ($typed_text =~ /^(.*?)([\[\(]*[AaBbEeGgYy1](?:1,1|[-+_'AaBbEeGgYy1\(\)\[\]])*[-+_AaBbEeGgYy1][\)\]]*[-+]*)(.*)$/)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $mname_length = $this->length_in_utf8_chars($typed_mname);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $mname_length;
      unless ($typed_mname =~ /^([Aa]+|[Bb]+|[Ee]+|[GgYy]+|[1+])$/) { # not an mname, just a plain word
         my $mname = join("", @norm_chars[$token_start .. ($token_end-1)]);
         my $n_left_special_chars = 0;
         my $n_reg_chars = 0;
         foreach $i (($token_start .. ($token_end-1))) {
            if ($this->special_char_in_id(*ht, $text_id, $i)) {
	       $n_left_special_chars++;
	    } else {
	       last;
	    }
         }
         foreach $i ((($token_start+$n_left_special_chars) .. ($token_end-1))) {
            if ($this->special_char_in_id(*ht, $text_id, $i)) {
	       last;
	    } else {
	       $n_reg_chars++;
	    }
         }
	 my $token_start2 = $token_start+$n_left_special_chars;
	 my $token_end2 = $token_start2 + $n_reg_chars;
	 my $error = "";
	 my $typed_mname2;
         ($error, $n_dropped_left_chars, $n_dropped_right_chars, $typed_mname1, $typed_mname2)
	    = $this->trim_or_ditch_mname($text_id, $token_start2, $token_end2, *ht, $text_id, *LOG, $verbose);
	 unless ($error) {
            $error = "plain core" if $typed_mname2 =~ /^([Aa]+|[Ee]+|[1+])$/;
	 }
	 $n_left_special_chars += $n_dropped_left_chars;
	 $n_reg_chars -= ($n_dropped_left_chars + $n_dropped_right_chars);
	 if ($error) {
            print LOG "* markup_mname reject: $text_id $mname ($token_start-$token_end) due to $error.\n" if $verbose && $tokenization_log_verbose;
         } elsif ($n_reg_chars) {
            my $n_right_special_chars = $mname_length - $n_left_special_chars - $n_reg_chars;
	    my $orig_token_start = $token_start;
	    my $orig_token_end = $token_end;
	    my $orig_mname = $mname;
            ($pre, $in, $post, $token_start, $token_end) = $this->realign_pre_in_post($pre, $typed_mname, $post, $position, $n_left_special_chars, -$n_right_special_chars, *ht, $text_id, *LOG, $verbose);
	    if (! (($token_start == $orig_token_start) && ($token_end == $orig_token_end))) {
	       $mname = join("", @norm_chars[$token_start .. ($token_end-1)]);
	       print LOG "* markup_mname adjust: $text_id $orig_mname ($orig_token_start-$orig_token_end) to $mname ($token_start-$token_end)\n" if $verbose && $tokenization_log_verbose;
	    }
	    $typed_mname = $typed_mname2 if $typed_mname;
          # print LOG "      mname: $mname typed_mname: $typed_mname\n" if $verbose && $tokenization_log_verbose;
            my $mname_sub_type = "";
	    my $mname_rejection_reason = "";
            if ((($word1) = ($mname =~ /^([a-z]+)-\d/i))
             && ($word1 =~ /^(mid|post|pre|sub)$/i)) {
	       $mname_rejection_reason = "separable prefix";
               # allow SPLIT
	    } elsif ((($alpha_elem, $sep, $number_elem, $rest) = ($typed_mname =~ /^([AaBbEeGgYy]+)([-]|)(1+)(.*)$/))
	          && ($alpha_length = length($alpha_elem))
		  && ($alpha_text = join("", @norm_chars[$token_start .. ($token_start+$alpha_length-1)]))
		# && $this->print_stderr("    alpha_text:$alpha_text sep:$sep number_elem:$number_elem rc:$rest$post lang_codes:@lang_codes\n")
                  && ($this->hash_table_lookup_with_lang_codes(*ht, *lang_codes, "X-LC-X", "CURRENCY_PREFIX", $alpha_text)
		   || (($right_context = "$rest$post")
		    && ($right_context =~ /^\.1/)))) {
	       # allow SPLIT for RMB200 and M6.1
	       $mname_rejection_reason = "separable alpha prefix $alpha_text before number";
	    } elsif (($pre =~ /[123][.,]?$/) && ($typed_mname =~ /^[123]/)) {
	       $mname_rejection_reason = "decimal number across left boundary";
	    } elsif (($typed_mname =~ /[123]$/) && ($post =~ /^[.,]?[123]/)) {
	       $mname_rejection_reason = "decimal number across right boundary";
	    } elsif (($typed_mname =~ /1$/) && ($post =~ /^:1/)) {
	       $mname_rejection_reason = "number with colon across right boundary";
	    } elsif ($mname =~ /^\d+(am|noon|pm|m|km)-\d+(am|noon|pm|m|km)$/i) {
	       $mname_rejection_reason = "time/quant-interval";
	    } elsif (($mname =~ /^[IVXLCDM]+(-|\xE2\x80[\x92-\x95])[IVXLCDM]+$/)
		  && ($mname =~ /^M*(C{0,4}|CD|DC{0,4}|CM)(X{0,4}|XL|LX{0,4}|XC)(I{0,4}|IV|VI{0,4}|IX)(-|\xE2\x80[\x92-\x95])M*(C{0,4}|CD|DC{0,4}|CM)(X{0,4}|XL|LX{0,4}|XC)(I{0,4}|IV|VI{0,4}|IX)$/)) {
	       $mname_rejection_reason = "roman-numeral-span";
            } elsif ($typed_mname =~ /[AaBbEeGgYy].*-[AaBbEeGgYy]*1/) {
               $mname_sub_type = "alpha-dash-numeric";
            } elsif ($typed_mname =~ /[AaBbEeGgYy]1/) {
               $mname_sub_type = "alpha-numeric";
            } elsif (($mname =~ /-$roman_numeral_pattern$/)
	          && ($typed_mname =~ /[A]-A+$/)) {
               $mname_sub_type = "caps-alpha-roman-numeral";
            } elsif ($typed_mname =~ /[A][aA]*-[A]$/) {
               $mname_sub_type = "caps-alpha-1cap";
            } elsif ($typed_mname =~ /^[Aa]-[Aa]+$/) {
	       if (($post =~ /^[.]/)
                && ($this->span_contains_token_of_type(*ht, $text_id, *LOG, $token_start+2, $token_end, "ABBREV", "WORD"))) {
	          $mname_rejection_reason = "give precedence to post-dash abbreviation (e.g. D-Ariz.)";
	       } else {
                  $mname_sub_type = "1alpha-dash-alpha";
	       }
            } elsif ($typed_mname =~ /^[A][Aa]*\++1*$/) {
               $mname_sub_type = "cap-alpha-plus";
            } elsif ($mname =~ /^(?:[ae]l-|ad-d|adh-dh|as-s|ash-sh|ar-r|at-t|ath-th|az-z)[a-z']+$/i) {
               $mname_sub_type = "al-Arabic-Name";
            } elsif ($mname =~ /^[A-Z][a-z]+-(de|e|i|sur|upon)-[A-Z][a-z]+$/i) {
               $mname_sub_type = "uc-name-infix-uc-name";
            } elsif (($mname =~ /[0-9],[0-9]-?[a-z]/i) && ($mname_length >= 12)) {
               $mname_sub_type = "c-name";
            } elsif (($typed_mname =~ /[Aa]/)
                  && ($typed_mname =~ /^[Aa1]*(_[Aa1]+)+$/)) {
               $mname_sub_type = "alhpa_underscrore_alpha";
            }
            if ($mname_sub_type) {
               my $mname_id = $this->new_token_id(*ht, $text_id, "M-NAME");
	       if ($verbose && $tokenization_log_verbose) {
	          print LOG "* markup_mname accept: $text_id $mname ($orig_token_start-$orig_token_end) $mname_sub_type\n";
	       }
	       if ($tokenization_log_verbose) {
	          $ht{MNAME_ACCEPT_COUNT}->{$mname} = ($ht{MNAME_ACCEPT_COUNT}->{$mname} || 0) + 1;
	          $ht{MNAME_ACCEPT_TEXT_ID}->{$mname}->{$text_id} = 1;
	       }
               $this->register_markup(*ht, $text_id, $mname_id, "M-NAME", $token_start, $token_end, $mname, $verbose, 1, *LOG, "markup_mname", "norm");
            } else {
	       if ($verbose && $tokenization_log_verbose) {
                  print LOG "* markup_mname reject: $text_id $mname :: $typed_mname ($token_start-$token_end) due to $mname_rejection_reason\n";
	       }
	       if ($tokenization_log_verbose) {
	          unless ($typed_mname2 =~ /^(1+|[Aa][Aa']*a)$/) {
	             $ht{MNAME_REJECT_COUNT}->{$mname} = ($ht{MNAME_REJECT_COUNT}->{$mname} || 0) + 1;
	             $ht{MNAME_REJECT_TEXT_ID}->{$mname}->{$text_id} = 1;
	          }
	       }
            }
         } else {
            print LOG "* markup_mname reject: $text_id $mname ($token_start-$token_end) due to specials inside.\n" if $verbose && $tokenization_log_verbose;
         }
      }
      $position = $token_end;
      $typed_text = $post;
   }
}

sub string_ipa_score {
   local($this, $ipa_cand, $left_context, $right_context, *ht, $text_id, *LOG, $token_start, $token_end) = @_;

   my $ipa_core = $ipa_cand;
   $ipa_core =~ s/^[\/\[\(]//;
   $ipa_core =~ s/[\/\]\)]$//;
   my $external_ipa_marker_score = 0;
   if ($left_context =~ /\bIPA\b(?:\s|&#160;|[:|])*$/) {
      $external_ipa_marker_score = 10;
   } elsif ($left_context =~ /\(IPA\)(?:\s|&#160;|[:|])*$/) {
      $external_ipa_marker_score = 9;
   } elsif ($right_context =~ /^(?:\s|&#160;)*\(IPA\)/) {
      $external_ipa_marker_score = 9;
   } elsif (($new_ipa_core) = ($ipa_core =~ /^IPA(?:\s+|:\s*)(.*)$/)) {
      $ipa_core = $new_ipa_core;
      $external_ipa_marker_score = 8;
   }

   print LOG "IPA ipa_cand: $ipa_cand ipa_core:$ipa_core ::\n" if $verbose && $tokenization_log_verbose;
   if (($ipa_cand =~ /^\[[a-z](?: [a-z])+\]$/)
    || ($ipa_cand =~ /^\/.*\/.*\/$/) # inside /
    || ($ipa_cand =~ /^\/\@/)
    || ($ipa_cand =~ /\@\/$/)
    || (($ipa_cand =~ /^\[.*[\[\]].*\]$/) && ! ($ipa_cand =~ /^\[[^\[\]]*(\]\s*\[[^\[\]]*)*\]$/))
    || ($ipa_core =~ /^\d+$/)
    || ($ipa_core =~ /\d\d/)
    || ($ipa_core =~ /^\d+-\d+$/)
    || ($ipa_core =~ /^ ?(\*|\d+) ?$/)
    || ($ipa_core =~ /^\s*$/)
    || ($ipa_core =~ /http/i)
    || ($ipa_core =~ /^[a-z]$/)
    || ($ipa_core =~ /mailto:/i)
    || $this->token_is_url_p($ipa_core)) {
      return ($external_ipa_marker_score) ? 3 : 0;
   }

   if (($ipa_core =~ /\.$/)
    || ($ipa_core =~ /^[-_ a-z?!,;="0-9]{7,}$/)
    || ($ipa_core =~ /^ ?(and|apple|at|brief|com|dot|int|sic|snip) ?$/)
    || ($ipa_core =~ /[~'?]$/)
    || ($ipa_core =~ /(\. )/)
    || $this->span_contains_token_of_type(*ht, $text_id, *LOG, $token_start, $token_end, "EMAIL", "URL")) {
      return ($external_ipa_marker_score) ? 7 : 4;
   }

   $n_lc_ascii_latin = 0;
   $n_non_ascii_latin_letter = 0;
   $n_other_legit_letter = 0;
   $n_ipa_char = 0;
   $n_whitespace = 0;
   $n_other_legit_char = 0;
   $n_suspicious_char = 0;
   $n_total_chars = 0;
   my @chars = $this->split_into_utf8_characters($ipa_core);
   foreach $char (@chars) {
      $n_total_chars++;
      $char_type = $this->cached_character_type($char, *ht);
      if ($char =~ /[a-z]/) {
         $n_lc_ascii_latin++;
      } elsif ($char =~ /[\@\\]/) {
         $n_suspicious_char++;
      } elsif ($char_type eq "IPA") {
         $n_ipa_char++;
      } elsif ($char_type eq "non-ASCII Latin letter") {
         $n_non_ascii_latin_letter++;
      } elsif ($char_type =~ /(Greek letter|Latin ligature letter)/) {
         $n_other_legit_letter++;
      } elsif ($char_type =~ /(combining-diacritic|punctuation|modifier tone)/) {
         $n_other_legit_char++;
      } elsif ($char_type =~ /\bwhitespace\b/) {
         $n_whitespace++;
      } else {
         return ($external_ipa_marker_score) ? 3 : 0;
      }
      $ht{IPA_CHAR_COUNT}->{$char_type}->{$char} = ($ht{IPA_CHAR_COUNT}->{$char_type}->{$char} || 0) + 1;
      $ht{IPA_TYPE_COUNT}->{$char_type}          = ($ht{IPA_TYPE_COUNT}->{$char_type} || 0) + 1;
   }

   my $left_context1 = $left_context;
   $left_context1 =~ s/^.*([\x00-\x7F\xC0-\xFF][\x80-\xBF]*)$/$1/;
   my $left_context1_char_type = ($left_context1 eq "") ? "" : $this->cached_character_type($left_context1, *ht);

   my $right_context1 = $right_context;
   $right_context1 =~ s/^([\x00-\x7F\xC0-\xFF][\x80-\xBF]*).*$/$1/;
   my $right_context1_char_type = ($right_context1 eq "") ? "" : $this->cached_character_type($right_context1, *ht);

   if (($ipa_cand =~ /\]$/) && ($right_context =~ /^\]/)) {
      return ($external_ipa_marker_score) ? 3 : 0;
   }
   if ($n_ipa_char == 0) {
      if (($ipa_core =~ /[A-Z]/)
       || (($left_context1_char_type =~ /letter/i) || ($right_context1_char_type =~ /letter/i))
       || ($ipa_core =~ /(, )/)) {
         return ($external_ipa_marker_score) ? 3 : 0;
      } elsif (($ipa_cand =~ /^\/.*\/$/)
            && (($left_context1 eq "\@") || ($right_context1 eq "\@"))) {
         return ($external_ipa_marker_score) ? 3 : 0;
      } elsif ($n_suspicious_char) {
         return ($external_ipa_marker_score) ? 7 : 4;
      }
   }
   if ($ipa_core =~ /[A-Z]/) {
      return ($external_ipa_marker_score) ? 7 : 4;
   }

   return 10 if $n_ipa_char && $n_lc_ascii_latin;
   return 9 if $external_ipa_marker_score;
   return 8;
}

sub markup_ipas {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;

   my $text = $ht{NORM_TEXT}->{$text_id};
   my $position = 0;
   my $s = $text;

   my $pre;
   my $ipa;
   my $post;
   while (($pre, $ipa, $post) = ($s =~ /^(.*?)(\/[^\/\[\]]{1,30}\/|\[[^\/\[\]]{1,30}\]|\(IPA\b[^()]{1,30}?\)|\bIPA\b[^()]{1,30}[\]\)]|\bIPA\b[^\/\[\]\(\)]{0,3}?\/[^\/\[\]\(\)]{1,30}?\/)(.*)$/)) {
    # print LOG "*** Point A: $pre :: $ipa :: $post ::\n";
      if (($external_marker, $core_ipa, $post2) = ($ipa =~ /^(\(?\bIPA(?:\s|&#160;|[:|])*)(\/.*?\/|\[.*?\])(.*\))$/)) {
         $ipa = $core_ipa;
         $pre .= $external_marker;
         $post = "$post2$post";
      } elsif (($external_marker, $core_ipa) = ($ipa =~ /^(IPA(?:\s|&#160;|[:|])*)(\/.*\/|\[.*\])$/)) {
         $ipa = $core_ipa;
         $pre .= $external_marker;
      } elsif (($core_ipa, $punct) = ($ipa =~ /^(IPA.*)([\/\] \)])$/)) {
         $ipa = $core_ipa;
         $post = "$punct$post";
      } else {
      }
    # print LOG "*** Point B: $pre :: $ipa :: $post\n";
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $ipa_length = $this->length_in_utf8_chars($ipa);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $ipa_length;
      $position = $token_end;
      $s = $post;
      next if $this->span_contains_token_of_type(*ht, $text_id, *LOG, $token_start, $token_end, "URL", "XML-TAG");
      my $string_ipa_score = $this->string_ipa_score($ipa, $pre, $post, *ht, $text_id, *LOG, $token_start, $token_end);
      if ($string_ipa_score >= 3) {
         my $left_context10 = $pre;
         $left_context10 =~ s/^.*((?:[\x00-\x7F\xC0-\xFF][\x80-\xBF]*){10})$/$1/;
         my $right_context10 = $post;
         $right_context10 =~ s/^((?:[\x00-\x7F\xC0-\xFF][\x80-\xBF]*){10}).*$/$1/;
         if ($string_ipa_score >= 7) {
            if ($string_ipa_score >= 9) {
	       if ($verbose && $tokenization_log_verbose) {
                  print LOG "+++ Reliable IPA $ipa   ($text_id $token_start-$token_end)\n";
                  $ht{IPA_SUSPICIOUS_COUNT}->{$ipa} = ($ht{IPA_SUSPICIOUS_COUNT}->{$ipa} || 0) + 1;
                  $ht{IPA_SUSPICIOUS_TEXT_ID}->{$ipa}->{$text_id} = 1;
	       }
            } else {
	       if ($verbose && $tokenization_log_verbose) {
                  print LOG "++  Accepted IPA $ipa   ($text_id $token_start-$token_end)          $left_context10" . "***" . "$right_context10 score:$string_ipa_score\n";
                  $ht{IPA_ACCEPT_COUNT}->{$ipa} = ($ht{IPA_ACCEPT_COUNT}->{$ipa} || 0) + 1;
                  $ht{IPA_ACCEPT_TEXT_ID}->{$ipa}->{$text_id} = 1;
	       }
            }
            my $ipa_id = $this->new_token_id(*ht, $text_id, "IPA");
            $this->register_markup(*ht, $text_id, $ipa_id, "IPA", $token_start, $token_end, $ipa, $verbose, 1, *LOG, "markup_ipas", "norm");
         } else {
	    if ($verbose && $tokenization_log_verbose) {
               print LOG "--- Rejected IPA $ipa   ($text_id $token_start-$token_end)          $left_context10" . "***" . "$right_context10\n";
               $ht{IPA_REJECT_COUNT}->{$ipa} = ($ht{IPA_REJECT_COUNT}->{$ipa} || 0) + 1;
               $ht{IPA_REJECT_TEXT_ID}->{$ipa}->{$text_id} = 1;
	    }
         }
      }
   }
}

sub markup_abbreviations {
   local($this, *ht, $text_id, *LOG, $verbose, *lang_codes) = @_;

   my $text = $ht{NORM_TEXT}->{$text_id};
   my $typed_text = $ht{NORM_TYPED_TEXT}->{$text_id};
   my @s_chars = @{$ht{NORM_CHARS}->{$text_id}};
   my $position = 0;
   my $typed_s = $typed_text;

   print LOG "markup_abbreviations: $text :: $typed_text\n" if $verbose && $tokenization_log_verbose;
   my $typed_pre;
   my $typed_abbrev;
   my $typed_post;
   my $abbrev;
   my @alt_token_starts = ();
   my @alt_token_ends = ();
   my @alt_token_texts = ();
   my @alt_token_types = ();
   # Aa:Latin Bb:Cyrillic C:CJK c:(other)character Ee:Greek Jj:Jap.katakana/hiragana l:letter s:syllable
   # Gg:Georgian Yy: Armenian R:Arabic H:Hebrew h:Ethiopic I:Indic
   while (($typed_pre, $typed_abbrev, $typed_post) = ($typed_s =~ /^(.*?)((?:(?:[ABEG][abeg]{0,2}|[abeg]{1,2})\.){2,}|\b[ABEG][abeg]*\.|\b[abeg]+\.)(.*)$/)) {
      my $pre_length = $this->length_in_utf8_chars($typed_pre);
      my $abbrev_length = $this->length_in_utf8_chars($typed_abbrev);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $abbrev_length;
      my $abbrev_p = 0;
      if ($typed_abbrev =~ /\..*\./) {
         $abbrev_p = 1;
	 $abbrev = join("", @s_chars[$token_start .. ($token_end-1)]);
      # A. Merkel
      } elsif (($typed_abbrev =~ /^[ABEG]\.$/) && ($typed_post =~ /^\s*[ABEG]/)) {
         $abbrev_p = 1;
	 $abbrev = join("", @s_chars[$token_start .. ($token_end-1)]);
	 push(@alt_token_starts, $token_start, ($token_end-1));
	 push(@alt_token_ends, ($token_end-1), $token_end);
	 push(@alt_token_texts, join("", @s_chars[$token_start .. ($token_end-2)]), $s_chars[($token_end-1)]);
	 push(@alt_token_types, "WORD", "PUNCT");
      # Angela M.
      } elsif (($typed_abbrev =~ /^[ABEG]\.$/) && ($typed_pre =~ /\b[ABEG][abeg]+\s+$/)) {
         $abbrev_p = 1;
	 $abbrev = join("", @s_chars[$token_start .. ($token_end-1)]);
	 push(@alt_token_starts, $token_start, ($token_end-1));
	 push(@alt_token_ends, ($token_end-1), $token_end);
	 push(@alt_token_texts, join("", @s_chars[$token_start .. ($token_end-2)]), $s_chars[($token_end-1)]);
	 push(@alt_token_types, "WORD", "PUNCT");
      } 
      $position = $token_end;
      $typed_s = $typed_post;
      if ($abbrev_p) {
         my $abbrev_id = $this->new_token_id(*ht, $text_id, "ABBREV");
         $this->register_markup(*ht, $text_id, $abbrev_id, "ABBREV", $token_start, $token_end, $abbrev, $verbose, 0, *LOG, "markup_abbreviations", "norm");
	 my $abbrev_expansion = "";
	 my $eng_gloss = "";
         my $lc_abbrev = $this->lower_case_string($abbrev, *ht, "norm-punct");
	 foreach $lang_code (@lang_codes) {
	    my $abbrev_cand = $ht{LI_TOKEN_ABBREV_EXPANSION}->{$lang_code}->{$lc_abbrev};
	    my $eng_gloss_cand = $ht{LI_TOKEN_GLOSS}->{$lang_code}->{"eng"}->{$lc_abbrev};
	    if (defined($abbrev_cand)) {
	       $eng_gloss = $eng_gloss_cand if defined($eng_gloss_cand);
	       $abbrev_expansion = $abbrev_cand;
	       last;
	    }
	 }
	 $ht{TOKEN_ABBREV_EXPANSION}->{$text_id}->{$abbrev_id} = $abbrev_expansion if $abbrev_expansion;
	 $ht{TOKEN_GLOSS}->{$text_id}->{$abbrev_id}->{"eng"} = $eng_gloss if $eng_gloss;
	 # HHHHERE
         foreach $i ((0 .. $#alt_token_texts)) {
	    my $token_start = pop @alt_token_starts;
	    my $token_end = pop @alt_token_ends;
	    my $token_text = pop @alt_token_texts;
	    my $token_type = pop @alt_token_types;
            my $alt_token_id = $this->new_token_id(*ht, $text_id, $token_type);
            $this->register_markup(*ht, $text_id, $alt_token_id, $token_type, $token_start, $token_end, $token_text, $verbose, 0, *LOG, "markup_abbreviations_alt", "norm");
            $ht{ALT_TOKEN_P}->{$text_id}->{$alt_token_id} = 1;
	    $ht{ALT_TOKENS}->{$text_id}->{$abbrev_id}->{$alt_token_id} = 1;
         }
      }
   }

   # Indic languages
   $position = 0;
   $typed_s = $typed_text;
   if ($typed_s =~ /I/) {
      while (($typed_pre, $typed_abbrev, $typed_post) = ($typed_s =~ /^(.*?)(?<![I])((?:I{1,3}\.){2,})(.*)$/)) {
         my $pre_length = $this->length_in_utf8_chars($typed_pre);
         my $abbrev_length = $this->length_in_utf8_chars($typed_abbrev);
         my $token_start = $position + $pre_length;
         my $token_end = $token_start + $abbrev_length;
         my $abbrev = join("", @s_chars[$token_start .. ($token_end-1)]);
         my $abbrev_id = $this->new_token_id(*ht, $text_id, "ABBREV");
	 my $abbrev_p = 0;
         if ($typed_abbrev =~ /\..*\./) {
            $abbrev_p = 1;
	 } else {
	    foreach $lang_code ((@lang_codes, "eng", "")) {
	       if ($ht{IS_ABBREVIATION_LANG}->{$lang_code}->{$abbrev}) {
	          $abbrev_p = 1;
	          last;
	       }
	    }
	 }
	 if ($abbrev_p) {
	    $abbrev = join("", @s_chars[$token_start .. ($token_end-1)]);
            $this->register_markup(*ht, $text_id, $abbrev_id, "ABBREV", $token_start, $token_end, $abbrev, $verbose, 0, *LOG, "markup_abbreviations_I", "norm");
	 }
         $position = $token_end;
         $typed_s = $typed_post;
      }
   }

   # Hebrew (abbreviation indicated by Gershayim/quotation mark before last root letter)
   $position = 0;
   $typed_s = $typed_text;
   if ($typed_s =~ /H/) {
      while (($typed_pre, $typed_abbrev, $typed_post) = ($typed_s =~ /^(.*?)(H+(?:"|\xD7\xB4)H+)(.*)$/)) {
         my $pre_length = $this->length_in_utf8_chars($typed_pre);
         my $abbrev_length = $this->length_in_utf8_chars($typed_abbrev);
         my $token_start = $position + $pre_length;
         my $token_end = $token_start + $abbrev_length;
         my $abbrev = join("", @s_chars[$token_start .. ($token_end-1)]);
	 my $abbrev_p = 1;
	 $abbrev_p = 0 if $abbrev =~ /^\xD7\x9B(?:"|\xD7\xB4)/;   # standard quotation prefix
	 if ($abbrev_p) {
            my $abbrev_id = $this->new_token_id(*ht, $text_id, "ABBREV");
            $this->register_markup(*ht, $text_id, $abbrev_id, "ABBREV", $token_start, $token_end, $abbrev, $verbose, 0, *LOG, "markup_abbreviations_H", "norm");
	 } else {
             $ht{ABBREV_REJECT_COUNT}->{$abbrev} = ($ht{ABBREV_REJECT_COUNT}->{$abbrev} || 0) + 1;
             $ht{ABBREV_REJECT_TEXT_ID}->{$abbrev}->{$text_id} = 1;
	 }
         $position = $token_end;
         $typed_s = $typed_post;
      }
   }

   # Armenian (abbreviation indicated by ASCII period; sentence end indicated by special Armenian punctuation)
   $position = 0;
   $typed_s = $typed_text;
   if ($typed_s =~ /[Yy]/) {
      my @s_typed_chars = @{$ht{NORM_TYPED_CHARS}->{$text_id}};
      my $revised_typed_s = "";
      foreach $i ((0 .. $#s_typed_chars)) {
	 if ($s_chars[$i] eq "\xD6\x89") { # Note: \xE2\x80\xA4 is UTF8 one dot leader
	    $revised_typed_s .= $s_chars[$i];
	 } else {
	    $revised_typed_s .= $s_typed_chars[$i];
	 }
      }
      unless ($revised_typed_s eq $typed_s) {
       # print LOG "markup Armenian abbreviations revise $typed_s -> $revised_typed_s\n";
	 $typed_s = $revised_typed_s;
      }
      while (($typed_pre, $typed_abbrev, $typed_post) = ($typed_s =~ /^(.*?)((?:[Yy]{1,5}(?:\.|\xE2\x80\xA4))(?:\s*[Yy]{1,5}(?:\.|\xE2\x80\xA4))*)(.*)$/)) {
	 # Note: \xE2\x80\xA4 is UTF8 one dot leader
         my $pre_length = $this->length_in_utf8_chars($typed_pre);
         my $abbrev_length = $this->length_in_utf8_chars($typed_abbrev);
         my $token_start = $position + $pre_length;
         my $token_end = $token_start + $abbrev_length;
         my $abbrev = join("", @s_chars[$token_start .. ($token_end-1)]);
	 my $abbrev_p = 1;
       # $abbrev_p = 0 if $abbrev =~ /\xD6\x89/; # Armenian Full Stop (to mark end of sentence as opposed to abbreviation)
	 if ($abbrev_p) {
            my $abbrev_id = $this->new_token_id(*ht, $text_id, "ABBREV");
            $this->register_markup(*ht, $text_id, $abbrev_id, "ABBREV", $token_start, $token_end, $abbrev, $verbose, 0, *LOG, "markup_abbreviations_Y", "norm");
	    if ($abbrev =~ /(\xE2\x80\xA4)/) {
               $ht{ABBREV_ACCEPT_COUNT}->{$abbrev} = ($ht{ABBREV_ACCEPT_COUNT}->{$abbrev} || 0) + 1;
               $ht{ABBREV_ACCEPT_TEXT_ID}->{$abbrev}->{$text_id} = 1;
	    }
	 } elsif (($typed_abbrev =~ /^[Yy]{5,}\.$/) && ($abbrev =~ /\xD6\x89$/)) {
	    # regular word plus Armenian Full Stop 	
	 } else {
            $ht{ABBREV_REJECT_COUNT}->{$abbrev} = ($ht{ABBREV_REJECT_COUNT}->{$abbrev} || 0) + 1;
            $ht{ABBREV_REJECT_TEXT_ID}->{$abbrev}->{$text_id} = 1;
	 }
         $position = $token_end;
         $typed_s = $typed_post;
      }
   }

   # Ethiopic (Ge'ez)
   $position = 0;
   $typed_s = $typed_text;
   if ($typed_s =~ /h/) {
      while (($typed_pre, $typed_abbrev, $typed_post) = ($typed_s =~ /^(.*?)(?<![h])((?:h){1,2}\.(?:\s?(?:h){1,2}\.){1,})(.*)$/)) {
         my $pre_length = $this->length_in_utf8_chars($typed_pre);
         my $abbrev_length = $this->length_in_utf8_chars($typed_abbrev);
         my $token_start = $position + $pre_length;
         my $token_end = $token_start + $abbrev_length;
         my $orig_abbrev = join("", @s_chars[$token_start .. ($token_end-1)]);
         my $abbrev = $orig_abbrev;
	 $abbrev =~ s/\s+//g;
	 my $n_chars_removed = ($orig_abbrev eq $abbrev) ? 0 : ($this->length_in_utf8_chars($orig_abbrev) - $this->length_in_utf8_chars($abbrev));
	 my $abbrev_p = 0;
         if ($typed_abbrev =~ /\..*\./) {
            $abbrev_p = 1;
	 } else {
	    foreach $lang_code ((@lang_codes, "eng", "")) {
	       if ($ht{IS_ABBREVIATION_LANG}->{$lang_code}->{$abbrev}) {
	          $abbrev_p = 1;
	          last;
	       }
	    }
	 }
	 if ($abbrev_p) {
            my $abbrev_id = $this->new_token_id(*ht, $text_id, "ABBREV");
            $this->register_markup(*ht, $text_id, $abbrev_id, "ABBREV", $token_start, $token_end, $abbrev, $verbose, 0, *LOG, "markup_abbreviations_Eth", "norm");
            $this->update_norm_text(*ht, $text_id, $token_start, $token_end, $abbrev, "", *LOG, $verbose) if $n_chars_removed;
            @s_chars = @{$ht{NORM_CHARS}->{$text_id}};
            $position = $token_end - $n_chars_removed;
	 } else {
            $position = $token_end;
	 }
         $typed_s = $typed_post;
      }
   }
}

sub markup_numbers {
   local($this, *ht, $text_id, *LOG, $verbose, *lang_codes) = @_;

   my $text = $ht{NORM_TEXT}->{$text_id};
   my $typed_text = $ht{NORM_TYPED_TEXT}->{$text_id};
   my @s_chars = @{$ht{NORM_CHARS}->{$text_id}};
   my @s_typed_chars = @{$ht{NORM_TYPED_CHARS}->{$text_id}};

   print LOG "* markup_numbers $text_id :: $text :: $typed_text ::\n" if $verbose && $tokenization_log_verbose;

   # scientific notation 1.2345e-03 123E+06
   my $s = $text;
   my $position = 0;
   my $pre;
   my $number;
   my $post;
   if ($s =~ /[eE][-+]\d/) {
      while (($pre, $number, $post) = ($s =~ /^(.*?)([-+]?\d{1,3}(?:\.\d+)?[eE][-+]\d{1,3})(.*)$/)) {
         my $pre_length = $this->length_in_utf8_chars($pre);
         my $number_length = $this->length_in_utf8_chars($number);
         my $token_start = $position + $pre_length;
         my $token_end = $token_start + $number_length;
         my $left_typed_context = ($token_start > 0) ? $s_typed_chars[$token_start-1] : "";
         $position = $token_end;
         $s = $post;
         if (($number =~ /^[-+]/) && ($left_typed_context =~ /[AaBbcEeGgHhIlRsYy1]$/)) { # exclude +- for cases such as 2+3e-01
            $token_start++;
	    ($pre_plus, $core_number) = ($number =~ /^(.[\x80-\xBF]*)(.*)$/);
	    $number = $core_number;
	 }
         unless ($this->special_char_in_id(*ht, $text_id, $token_start)) {
            my $number_id = $this->new_token_id(*ht, $text_id, "NUMBER");
            $this->register_markup(*ht, $text_id, $number_id, "NUMBER", $token_start, $token_end, $number, $verbose, 0, *LOG, "markup_numbers_e", "norm");
         }
      }
   }

   # decimal without digit before decimal point: .303 $.14 .2%
   my $typed_s = $typed_text;
   $position = 0;
   my $typed_pre;
   my $typed_number;
   my $typed_post;
   while (($typed_pre, $typed_number, $typed_post) = ($typed_s =~ /^(.*?)([-+]?\.1+)(.*)$/)) {
      my $pre_length = $this->length_in_utf8_chars($typed_pre);
      my $number_length = $this->length_in_utf8_chars($typed_number);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $number_length;
      $position = $token_end;
      $typed_s = $typed_post;
      if ($this->special_char_in_id(*ht, $text_id, $token_start)
       || (defined($orig_token_start = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$token_start})
        && $ht{CHAR_IN_ID_BY_TYPE}->{$text_id}->{NUMBER}->{$orig_token_start})) {
	 # part of previous special
      } elsif (($typed_number =~ /^[-+]?\.1+$/)
            && (($typed_pre eq "") || ! ($typed_pre =~ /[-_AaBbCcEeGgHhIJjlRsYy123]$/))
            && (($typed_post eq "") || ! ($typed_post =~ /^[-_AaBbCcEeGgHhIJjlRsYy123]/))) {
	 $number = join("", @s_chars[$token_start .. ($token_end-1)]);
         my $number_id = $this->new_token_id(*ht, $text_id, "NUMBER");
         $this->register_markup(*ht, $text_id, $number_id, "NUMBER", $token_start, $token_end, $number, $verbose, 0, *LOG, "markup point+decimals", "norm");
      }
   }

   $typed_s = $typed_text;
   $position = 0;
   my $typed_left_context = "";
   # 1=digit (e.g. 5) 2=fraction (e.g. 1/2) 3=number (e.g. 10)
   # for now, not considering simple fractions (e.g. 1/2) because they could be dates (e.g. on 9/11)
   while (($typed_pre, $typed_number, $typed_post) = ($typed_s =~ /^(.*?)((?:13+)+1?|(?:3+1)+3*|1+ ?2|2|3+|[-+]?1+(?:[.,]1+)*)(.*)$/)) {
      my $pre_length = $this->length_in_utf8_chars($typed_pre);
      my $number_length = $this->length_in_utf8_chars($typed_number);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $number_length;
      $typed_left_context .= $typed_pre;
      my $number_p = 0;
    # print LOG "Point A $text_id: $typed_number ($token_start-$token_end)\n";
      if (($typed_number =~ /^[-+]?1+(?:\.1+)?$/)                      # +12.34
       || ($typed_number =~ /^[-+]?1{1,4}(?:,1{2,4})*(?:\.1+)?$/)      # -12,345,678.90
       || ($typed_number =~ /^[-+]?1{1,4}(?:\.1{2,4})*(?:,1+)?$/)) {   # 12.345.678,90
         $number_p = 1;
         $token_start++ if ($typed_number =~ /^[-+]/) # exclude +- for cases such as 2+3; 7'-8'
	                && ($typed_left_context =~ /[AaBbcEeGgHhIlRsYy1%]'?$/);
       # print LOG "Point B $text_id: $typed_number ($token_start-$token_end) @s_chars\n";
      } elsif ($typed_number =~ /^((?:13+)+1?|(?:3+1)+3*|3+)$/) {
	 # incl. Ethiopic, Egyptian hieroglyph number
         $number_p = 1;
      } elsif ($typed_number =~ /^(?:1+ ?2|2)$/) {
         $number_p = 1;
      }
      $position = $token_end;
      $typed_s = $typed_post;
      if ($this->special_char_in_id(*ht, $text_id, $token_start)
       || (defined($orig_token_start = $ht{NORM_TO_ORIG_VERTEX_MAP_R}->{$text_id}->{$token_start})
        && $ht{CHAR_IN_ID_BY_TYPE}->{$text_id}->{NUMBER}->{$orig_token_start})) {
	 # part of previous special
      } elsif ($number_p) {
	 $number = join("", @s_chars[$token_start .. ($token_end-1)]);
         my $number_id = $this->new_token_id(*ht, $text_id, "NUMBER");
         $this->register_markup(*ht, $text_id, $number_id, "NUMBER", $token_start, $token_end, $number, $verbose, 0, *LOG, "markup_numbers", "norm");
      } else {
	 $number = join("", @s_chars[$token_start .. ($token_end-1)]);
	 print LOG "*** Rejecting number based on structure: $text_id ($token_start-$token_end): $number\n" if $verbose && $tokenization_log_verbose;
      }
      $typed_left_context .= $typed_number;
   }
}

$phone_number_pattern1 = "(_PHONE_NUMBER_)";
$ip_address_pattern = "(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?:\\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}";
sub load_phone_number_formats {
   local($this, *ht, $filename, *LOG, $verbose) = @_;
   # e.g. /nfs/isd/ulf/arabic/data/phone-number-formats.txt

   my $min_n_digits = 9999;
   my $max_n_non_digits = 0;
   if (open(IN, $filename)) {
      my $line_number = 0;
      my @patterns = ();
      while (<IN>) {
	 s/^\xEF\xBB\xBF//;
         $line_number++;
	 my $line = $_;
	 next if $line =~ /^#/;
	 $line =~ s/\+s#.*$//;
	 next unless $line =~ /\S/;
	 $line =~ s/\s*$//;
	 last if $line =~ /^exit\s+-?\d+\s*;/;
	 $unreliable = $this->slot_value_in_double_colon_del_list($line, "unreliable");
	 $line =~ s/\s*::.*$//;
	 my $pattern = $line;
	 if ($ht{RAW_PHONE_NUMBER_FORMAT}->{$pattern}) {
	    print LOG "*** Warning: duplicate phone-number format $pattern in line $line_number\n";
	 } else {
            my $pattern2 = $pattern;
	    my $pattern3 = "";
	    while (($pre, $x, $n, $post) = ($pattern2 =~ /^(.*?)([ABX0-9])\{(\d+),?\d*\}(.*)$/)) {
	       $pattern3 .= $pre;
	       foreach $i ((1 .. $n)) {
	          $pattern3 .= $x;
	       }
	       $pattern2 = $post;
	    }
	    $pattern3 .= $pattern2;
	    $pattern3 =~ s/.[\x80-\xBF]*\?//g;
	    $pattern3 =~ s/^[^ABX0-9]*//;
	    $pattern3 =~ s/[^ABX0-9]*$//;
	    $core_pattern = $pattern3;
	    my $len_core_pattern = length($core_pattern);
	    $pattern3 =~ s/[^ABX0-9]//g;
	    my $n_digits = length($pattern3);
	    my $n_core_non_digits = $len_core_pattern - $n_digits;
	    $min_n_digits = $n_digits if $n_digits < $min_n_digits;
	    $max_n_non_digits = $n_core_non_digits if $n_core_non_digits > $max_n_non_digits;

	    $ht{RAW_PHONE_NUMBER_FORMAT}->{$pattern} = 1;
	    $pattern =~ s/A/\[1-9\]/g;
	    $pattern =~ s/B/\[2-9\]/g;
	    $pattern =~ s/X/\\d/g;
	    $pattern =~ s/([.\(\)\/])/\\$1/g;
	    $pattern =~ s/^\+/(?:00|\\\+\\\+?\\s\?)/;
	    $ht{UNRELIABLE_PHONE_NUMBER_FORMAT}->{$pattern} = $unreliable if $unreliable;
	    push(@patterns, $pattern);
	 }
      }
      close(IN);
      $ht{MIN_N_PHONE_DIGITS} = $min_n_digits;
      $ht{MAX_N_PHONE_NON_DIGITS} = $max_n_non_digits;
      $phone_number_pattern1 = join("|", @patterns, $ip_address_pattern);
    # print LOG "phone_number_pattern: $phone_number_pattern1\n";
      $phone_number_regex1 = qr/^(.*?)($phone_number_pattern1)(.*)$/i;
    # print LOG "phone_number_regex1: $phone_number_regex1\n";
      my $n_patterns = $#patterns + 1;
      print LOG "Loaded $n_patterns phone number patterns (window: $min_n_digits/$max_n_non_digits).\n" if $verbose;
   } else {
      print LOG "*** Error: Could not open $filename\n";
   }
}

sub load_abbreviations {
   local($this, $filename, $lang_code, *ht, *LOG, $verbose) = @_;
   # e.g. /nfs/nlg/users/textmap/brahms-ml/arabic/data/abbreviations-deu.txt

   my $n = 0;
   if (open(IN, $filename)) {
      while (<IN>) {
	 s/^\xEF\xBB\xBF//;
         next if /^\#/;
         s/\s*$//;
	 next unless /\S/;
         my @expansions;
         if (@expansions = split(/\s*::\s*/, $_)) {
            my $abbrev = shift @expansions;
            my $lc_abbrev = $this->lower_case_string($abbrev, *ht, "norm-punct");
	    unless ($ht{LI_TOKEN_ABBREV_EXPANSION}->{$lang_code}->{$lc_abbrev}) {
               $ht{IS_ABBREVIATION_LANG}->{$lang_code}->{$abbrev} = 1;
               $ht{IS_LC_ABBREVIATION_LANG}->{$lang_code}->{$lc_abbrev} = 1;
               foreach $expansion (@expansions) {
	          my $core_expansion = $expansion;
	          $core_expansion =~ s/\s*\(.*\)//g;
                  $ht{ABBREV_EXPANSION_LANG}->{$lang_code}->{$abbrev}->{$expansion} = 1;
                  $ht{ABBREV_EXPANSION_LANG_OF}->{$lang_code}->{$core_expansion}->{$abbrev} = 1;
               }
               $n++;
	    }
         }
      }
      close(IN);
      print LOG "Loaded $n entries from $filename\n" if $verbose;
   } else {
      print LOG "Can't open $filename\n" if $verbose;
   }
}

sub markup_phone_numbers { # including IPv4 addresses; timestamps; s-numbers (e.g. 1.2.3; 123-45-6789)
   local($this, *ht, $text_id, *LOG, $verbose, *lang_codes) = @_;

   my $text = $ht{NORM_TEXT}->{$text_id};
   my @typed_chars = @{$ht{NORM_TYPED_CHARS}->{$text_id}};
   my $min_n_digits = $ht{MIN_N_PHONE_DIGITS};
   my $max_n_non_digits = $ht{MAX_N_PHONE_NON_DIGITS};
   my $window_size = $min_n_digits + $max_n_non_digits;
   my $n_digits_in_window = 0;
   my $text_might_contain_phone_number_p = 0;
   foreach $i ((0 .. $#typed_chars)) {
      $n_digits_in_window++ if $typed_chars[$i] eq "1";
      $n_digits_in_window-- if ($i >= $window_size) && ($typed_chars[$i-$window_size] eq "1");
      if ($n_digits_in_window >= $min_n_digits) {
	 $text_might_contain_phone_number_p = 1;
         last;
      }
   }
   my $text_might_contain_ip_address_p = ($text =~ /\d\.\d{1,3}.\d{1,3}\.\d/);
   my $text_might_contain_timestamp = ($text =~ /[12]\d\d\d-[0-1]\d-[0-3]\d/);
   my $text_might_contain_s_number_p = ($text =~ /(\d+-\d+-\d+|\d+\.\d+\.\d+)/);
   unless ($text_might_contain_phone_number_p || $text_might_contain_ip_address_p || $text_might_contain_timestamp || $text_might_contain_s_number_p) {
      print LOG "Insufficient digit cluster for phone-number/IP-address in $text_id\n" if $verbose && $tokenization_log_verbose;
      return;
   }

   my $typed_text = $ht{NORM_TYPED_TEXT}->{$text_id};
   my $s = $text;
   my $position = 0;
   my $pre;
   my $pre_length;
   my $phone_number;
   my $phone_number_length;
   my $phone_number_p;
   my $post;
   my $left_context = "";
   my $typed_s = $typed_text;
   my $typed_pre;
   my $typed_pre_length;
   my $typed_phone_number;
   my $typed_phone_number_p;
   my $typed_post;
   my $typed_left_context = "";
   my $token_start;
   my $token_end;

   while (($pre, $timestamp, $post) = ($s =~ /^(.*?)([12]\d\d\d-(?:0\d|1[0-2])-(?:[0-2]\d|3[01])(?:[T ](?:[01]\d|2[0-4]):(?:[0-5]\d)(?::[0-5]\d)?(?:Z|[-+](?:0\d|1[0-2])(?::00|:15|:30|:45)?)?)?)(.*)$/)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $timestamp_length = $this->length_in_utf8_chars($timestamp);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $timestamp_length;
      unless ($this->special_char_in_id(*ht, $text_id, $token_start, $token_end)) {
         my $timestamp_id = $this->new_token_id(*ht, $text_id, "TIMESTAMP");
         $this->register_markup(*ht, $text_id, $timestamp_id, "TIMESTAMP", $token_start, $token_end, $timestamp, $verbose, 1, *LOG, "markup_timestamps", "norm");
      }
      $position = $token_end;
      $s = $post;
   }

   # S-NUMBER 1.2.3 (e.g. subsection numbers)
   $position = 0;
   $s = $text;
   while (($pre, $s_number, $post) = ($s =~ /^(.*?)([12]?\d(?:\.[12]?\d){2,})(.*?)$/)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $s_number_length = $this->length_in_utf8_chars($s_number);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $s_number_length;
      my $primary_token_id = "";
      unless ($s_number =~ /^\d{2,}(\.\d{2,})+$/) {
         my $s_number_id = $this->new_token_id(*ht, $text_id, "S-NUMBER");
         $this->register_markup(*ht, $text_id, $s_number_id, "S-NUMBER", $token_start, $token_end, $s_number, $verbose, 1, *LOG, "markup_s_numbers-1", "norm");
	 $primary_token_id = $s_number_id;
      }
      if ($s_number =~ /^$ip_address_pattern$/) {
         my $ip_address_id = $this->new_token_id(*ht, $text_id, "IP-ADDRESS");
         $this->register_markup(*ht, $text_id, $ip_address_id, "IP-ADDRESS", $token_start, $token_end, $s_number, $verbose, 1, *LOG, "markup_ip_addresses-1", "norm");
	 if ($primary_token_id) {
            $ht{ALT_TOKEN_P}->{$text_id}->{$ip_address_id} = 1;
	    $ht{ALT_TOKENS}->{$text_id}->{$primary_token_id}->{$ip_address_id} = 1;
	 } else {
	    $primary_token_id = $ip_address_id;
         }
      }
      my $phone_number_p = (($pre2, $phone_number2, $post2) = ($s_number =~ $phone_number_regex1));
      if ($s_number =~ /^\d{2,}(\.\d{2,}){2,}$/) {
         my $phone_number_id = $this->new_token_id(*ht, $text_id, "PHONE-NUMBER");
         $this->register_markup(*ht, $text_id, $phone_number_id, "PHONE-NUMBER", $token_start, $token_end, $s_number, $verbose, 1, *LOG, "markup_phone_numbers-1", "norm");
	 if ($primary_token_id) {
            $ht{ALT_TOKEN_P}->{$text_id}->{$phone_number_id} = 1;
	    $ht{ALT_TOKENS}->{$text_id}->{$primary_token_id}->{$phone_number_id} = 1;
	 } else {
	    $primary_token_id = $phone_number_id;
         }
      }
      $position = $token_end;
      $s = $post;
   }

   # S-NUMBER 123-45-6789 (e.g. social security numbers, ISBN numbers)
   $position = 0;
   $s = $text;
   while (($pre, $s_number, $post) = ($s =~ /^(.*?)(\d+(?:-\d+){2,})(.*?)$/)) {
      my $pre_length = $this->length_in_utf8_chars($pre);
      my $s_number_length = $this->length_in_utf8_chars($s_number);
      my $token_start = $position + $pre_length;
      my $token_end = $token_start + $s_number_length;
      my $valid_li_token_p = 0;
      my $primary_token_id = "";
      foreach $lang_code (@lang_codes) {
	 if ($ht{LI_TOKEN_P}->{$lang_code}->{$s_number}) {
	    $valid_li_token_p = 1;
	    last;
	 }
      }
      $phone_number_p = (($pre2, $phone_number2, $post2) = ($s_number =~ $phone_number_regex1));
      if ($phone_number_p && ($pre2 eq "") && ($post2 eq "")) {
         my $phone_number_id = $this->new_token_id(*ht, $text_id, "PHONE-NUMBER");
         $this->register_markup(*ht, $text_id, $phone_number_id, "PHONE-NUMBER", $token_start, $token_end, $s_number, $verbose, 1, *LOG, "markup_phone_numbers-2", "norm");
	 $primary_token_id = $phone_number_id;
      }
      unless ($valid_li_token_p) {
         my $s_number_id = $this->new_token_id(*ht, $text_id, "S-NUMBER");
         $this->register_markup(*ht, $text_id, $s_number_id, "S-NUMBER", $token_start, $token_end, $s_number, $verbose, 1, *LOG, "markup_s_numbers-1", "norm");
	 if ($primary_token_id) {
            $ht{ALT_TOKEN_P}->{$text_id}->{$s_number_id} = 1;
	    $ht{ALT_TOKENS}->{$text_id}->{$primary_token_id}->{$s_number_id} = 1;
	 } else {
	    $primary_token_id = $s_number_id;
         }
      }
      $position = $token_end;
      $s = $post;
   }

   $position = 0;
   $s = $text;
   my $n_iterations = 0;
   while (1) {
      $n_iterations++;
      if ($n_iterations > 10000) {
	 print LOG "*** Emergency brake after $n_iterations $n_iterations iterations in markup_phone_numbers\n";
	 last;
      }
    # print LOG "Point A1: $s\n";
    # print LOG "Point A2: $typed_s\n";
      $phone_number_p = (($pre, $phone_number, $post) = ($s =~ $phone_number_regex1));
      $typed_phone_number_p = (($typed_pre, $typed_phone_number, $typed_post) = ($typed_s =~ /^(.*?)(\+1{10,12})(.*)$/));

      if ($phone_number_p && $typed_phone_number_p) {
         $pre_length = $this->length_in_utf8_chars($pre);
         $typed_pre_length = $this->length_in_utf8_chars($typed_pre);
	 if ($pre_length <= $typed_pre_length) {
	    $typed_phone_number_p = 0;
	 } else {
	    $phone_number_p = 0;
	 }
      } elsif ($phone_number_p) {
	 $pre_length = $this->length_in_utf8_chars($pre); 
      } elsif ($typed_phone_number_p) {
	 $typed_pre_length = $this->length_in_utf8_chars($typed_pre);
      } else {
	 last;
      }
      if ($phone_number_p) {
         $phone_number_length = $this->length_in_utf8_chars($phone_number);
         $token_start = $position + $pre_length;
         $token_end = $token_start + $phone_number_length;
       # print LOG "Point B1: $phone_number ($token_start-$token_end)\n";
       # print LOG "Point B2: $pre :: $phone_number :: $post\n";
	 ($typed_pre, $typed_phone_number, $typed_post) = ($typed_s =~ /^((?:.[\x80-\xBF]*){$pre_length})((?:.[\x80-\xBF]*){$phone_number_length})(.*)$/);
       # print LOG "Point B3: $typed_pre :: $typed_phone_number :: $typed_post\n";
      } else {
         $phone_number_length = $this->length_in_utf8_chars($typed_phone_number);
         $token_start = $position + $typed_pre_length;
         $token_end = $token_start + $phone_number_length;
       # print LOG "Point C1: $typed_phone_number ($token_start-$token_end)\n";
	 ($pre, $phone_number, $post) = ($s =~ /^((?:.[\x80-\xBF]*){$typed_pre_length})((?:.[\x80-\xBF]*){$phone_number_length})(.*)$/);
      }
      $left_context .= $pre;
      $typed_left_context .= $typed_pre;
      $s = $post;
      $typed_s = $typed_post;
      unless ($this->special_char_in_id(*ht, $text_id, $token_start)) {
	 if (($typed_left_context =~ /1\s*$/)
	  || ($typed_left_context =~ /[-+]$/)
	  || ($typed_post =~ /^\s*1/)
	  || ($typed_post =~ /^[-+]/)) {
	    print LOG "*** Rejecting phone-number ip-address based on context: $text_id ($token_start-$token_end): $phone_number\n" if $verbose && $tokenization_log_verbose;
	 } else {
            # consider left context: call|calling|contact|phone|fax|at|Tel.|cell:
            # consider right context: call|calls|for|night|\$|$
            # consider sufficient length
	    my @unreliabity_messages = ();
	    my $unreliable_message_could_be_a_span = 0;
	    my $phone_number_id = "";
	    my $ip_address_id = "";
	    foreach $unreliable_pattern (keys %{$ht{UNRELIABLE_PHONE_NUMBER_FORMAT}}) {
	       $unreliabity_message = $ht{UNRELIABLE_PHONE_NUMBER_FORMAT}->{$unreliable_pattern};
	       if ($phone_number =~ /^$unreliable_pattern$/) {
	          print LOG "*** Unreliable phone number in $text_id ($token_start-$token_end): $phone_number   # $unreliabity_message\n" if $verbose;
	          push(@unreliabity_messages, $unreliabity_message);
		  $unreliable_message_could_be_a_span = 1
		     if $unreliabity_message =~ /^Could be a span/;
	       }
	    }
	    my $special_token_p = ($#unreliabity_messages < 0) ? 1 : 0;
	    if ($phone_number =~ /^$ip_address_pattern$/) {
	       my $ip_address = $phone_number;
               $ip_address_id = $this->new_token_id(*ht, $text_id, "IP-ADDRESS");
               $this->register_markup(*ht, $text_id, $ip_address_id, "IP-ADDRESS", $token_start, $token_end, $ip_address, $verbose, $special_token_p, *LOG, "markup_ip_addresses-2", "norm");
	       if ($phone_number =~ /^\d\d\.\d\d\.\d\d\.\d\d$/) {
                  $phone_number_id = $this->new_token_id(*ht, $text_id, "PHONE-NUMBER");
                  $this->register_markup(*ht, $text_id, $phone_number_id, "PHONE-NUMBER", $token_start, $token_end, $phone_number, $verbose, $special_token_p, *LOG, "markup_phone_numbers-3", "norm");
	       }
	    } else {
               $phone_number_id = $this->new_token_id(*ht, $text_id, "PHONE-NUMBER");
               $this->register_markup(*ht, $text_id, $phone_number_id, "PHONE-NUMBER", $token_start, $token_end, $phone_number, $verbose, $special_token_p, *LOG, "markup_phone_numbers-4", "norm");
	    }
	    if ($phone_number_id && $unreliable_message_could_be_a_span && ($phone_number =~ /^\d+(-|\xE2\x80[\x92-\x95])\d+$/)) {
	       ($number1, $punct, $number2) = ($phone_number =~ /^(\d+)(-|\xE2\x80[\x92-\x95])(\d+)$/);
	       my $length1 = length($number1);
	       my $length2 = length($number2);
	       my $point1 = $token_start+$length1;
	       my $point2 = $token_end-$length2;
	       my $number1_id = $this->new_token_id(*ht, $text_id, "NUMBER");
               $this->register_markup(*ht, $text_id, $number1_id, "NUMBER", $token_start, $point1, $number1, $verbose, $special_token_p, *LOG, "markup_numbers-p1", "norm");
	       my $punct_id = $this->new_token_id(*ht, $text_id, "PUNCT");
               $this->register_markup(*ht, $text_id, $punct_id, "PUNCT", $point1, $point2, $punct, $verbose, $special_token_p, *LOG, "markup_numbers-p2", "norm");
	       my $number2_id = $this->new_token_id(*ht, $text_id, "NUMBER");
               $this->register_markup(*ht, $text_id, $number2_id, "NUMBER", $point2, $token_end, $number2, $verbose, $special_token_p, *LOG, "markup_numbers-p3", "norm");
               $ht{ALT_TOKEN_P}->{$text_id}->{$number1_id} = 1;
               $ht{ALT_TOKEN_P}->{$text_id}->{$number2_id} = 1;
               $ht{ALT_TOKEN_P}->{$text_id}->{$punct_id}   = 1;
	       $ht{ALT_TOKENS}->{$text_id}->{$phone_number_id}->{$number1_id} = 1;
	       $ht{ALT_TOKENS}->{$text_id}->{$phone_number_id}->{$number2_id} = 1;
	       $ht{ALT_TOKENS}->{$text_id}->{$phone_number_id}->{$punct_id}   = 1;
	    }
	 }
      }
      $left_context .= $phone_number;
      $typed_left_context .= $typed_phone_number;
      if ($token_end == $position) {
	 print LOG "*** Error: empty phone_number in $text_id position $position [breaking loop]\n";
	 last;
      }
      $position = $token_end;
   }
}

$ignorable_pattern = "(?:[\x00-\x08\x0B-\x1F\x7F]|\xC2[\x80-\x9F]|\xD9\x80|\xE2\x80[\x8B-\x8F]|\xEF\xB8[\x80-\x8F]|\xEF\xBB\xBF|\xF3\xA0[\x84-\x87][\x80-\xBF])";
$ignorable_regex = qr/^(.*?)($ignorable_pattern)(.*)$/i;

sub delete_ignorable_characters {
   local($this, $s) = @_;

   $s =~ s/$ignorable_pattern//g;
   return $s;
}

sub markup_ignorable_characters {
   local($this, *ht, $text_id, *LOG, $verbose) = @_;

   # markup for deletion control chacters (except tab and linefeed), zero-width characters,
   # byte order mark, directional marks, join marks, variation selectors, Arabic tatweel

   my @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};
   my $end_vertex = $ht{NORM_END}->{$text_id};
   my $text = $ht{NORM_TEXT}->{$text_id};
   my $s = $text;
   my $position = 0;
   my $pre;
   my $ignorable_char;
   my $post;
   while (($pre, $ignorable_char, $post) = ($s =~ $ignorable_regex)) {
      $pre_length = $this->length_in_utf8_chars($pre);
      $ignorable_length = $this->length_in_utf8_chars($ignorable_char);
      $token_start = $position + $pre_length;
      $token_end = $token_start + $ignorable_length;
    # print LOG "Ignorable char cand $ignorable_char $token_start-$token_end\n";
      # keep certain zero width joiner characters
      if (($ignorable_char =~ /^\xE2\x80\x8C$/) # zero width non-joiner (U+200C)
       && ($token_start > 0)
       && ($left_context = $norm_chars[$token_start-1])
       && ($this->cached_character_type($left_context, *ht) =~ /(Arabic|Devanagari|Bengali|Gujarati|Gurmukhi|Hebrew|Kannada|Malayalam|Oriya|Sinhala|Tamil|Telegu) (letter|accent|point)/i)) {
         $ht{IGNORE_REJECT_COUNT}->{$ignorable_char} = ($ht{IGNORE_REJECT_COUNT}->{$ignorable_char} || 0) + 1;
         $ht{IGNORE_REJECT_TEXT_ID}->{$ignorable_char}->{$text_id} = 1;
       # print LOG "** Reject ignoring (= keep) ZWNJ $token_start-$token_end\n";
         $position = $token_end;
      } elsif (($ignorable_char =~ /^\xE2\x80\x8D$/) # zero width joiner (U+200D)
       # zero width joiner between pictographs
       && ((($token_start > 0)
         && ($left_context = $norm_chars[$token_start-1])
         && ($token_end < $end_vertex)
         && ($this->cached_character_type($left_context, *ht) =~ /pictograph/)
         && ($right_context = $norm_chars[$token_end])
         && ($this->cached_character_type($right_context, *ht) =~ /pictograph/))
        || (($token_start > 0)
         && ($left_context = $norm_chars[$token_start-1])
	 && ($this->cached_character_type($left_context, *ht) =~ /(Devanagari|Bengali|Gujarati|Gurmukhi|Kannada|Malayalam|Oriya|Sinhala|Tamil|Telegu) letter/i))
        || (($token_end < $end_vertex)
         && ($right_context = $norm_chars[$token_end])
	 && ($this->cached_character_type($right_context, *ht) =~ /(Devanagari|Bengali|Gujarati|Gurmukhi|Kannada|Malayalam|Oriya|Sinhala|Tamil|Telegu) letter/i)))) {
            $ht{IGNORE_REJECT_COUNT}->{$ignorable_char} = ($ht{IGNORE_REJECT_COUNT}->{$ignorable_char} || 0) + 1;
            $ht{IGNORE_REJECT_TEXT_ID}->{$ignorable_char}->{$text_id} = 1;
          # print LOG "** Reject ignoring (= keep) $ignorable_char $token_start-$token_end\n";
            $position = $token_end;
      } else {
         my $ignorable_id = $this->new_token_id(*ht, $text_id, "IGNORABLE");
       # print LOG "** Ignore $ignorable_char $token_start-$token_end\n";
         $this->register_markup(*ht, $text_id, $ignorable_id, "IGNORABLE", $token_start, $token_end, $ignorable_char, $verbose, 0, *LOG, "markup_ignorable_characters", "norm");
         $this->update_norm_text(*ht, $text_id, $token_start, $token_end, "", "", *LOG, $verbose);
	 @norm_chars = @{$ht{NORM_CHARS}->{$text_id}};
	 $end_vertex = $ht{NORM_END}->{$text_id};
         $position = $token_start; # Note that IGNORABLE_ORIG_CHARs have been removed.
      }
      $s = $post;
   }
}

sub cached_character_type {
   local($this, $char, *ht) = @_;

   my $char_type = $ht{CHARACTER_TYPE}->{$char};
   unless (defined($cached_char_type)) {
      $char_type = $utf8->character_type($char);
      if (defined($char_type)) {
         $ht{CHARACTER_TYPE}->{$char} = $char_type;
      } else {
         $char_type = "other character";
      }
   }
   return $char_type;
}

sub type_chars {
   local($this, *ht, $control, *s_chars) = @_;

   @typed_chars = ();
   my $i = 0;
   my $prev_typed_char = "";
   foreach $char (@s_chars) {
      $i++;
      my $typed_char = $ht{TYPE_CHAR}->{$char};
      unless (defined($typed_char)) {
         my $char_type = $this->cached_character_type($char, *ht);
         my $lc_char = $ht{UPPER_TO_LOWER_CASE}->{$char};
         my $de_accent_char = $ht{DE_ACCENT1}->{$char};
         my $norm_punct = $ht{NORM_PUNCT}->{$char};
         $de_accent_char = $char unless defined($de_accent_char);
         if ($de_accent_char =~ /^[A-Z]$/) {
	    $typed_char = "A";
         } elsif ($de_accent_char =~ /^[a-z]$/) {
	    $typed_char = "a";
	 } elsif ($char_type =~ /Latin letter/) {
	    if ($lc_char) {
	       $typed_char = "A";
	    } else {
	       $typed_char = "a";
	    }
         } elsif ($char_type =~ /\bdigit\b/) {
	    $typed_char = "1";
         } elsif ($char_type =~ /\bfraction\b/) {
	    $typed_char = "2";
         } elsif ($char_type =~ /\bnumber\b/) {
	    $typed_char = "3";
         } elsif ($char_type =~ /\bwhitespace/) {
	    $typed_char = " ";
         } elsif ($char_type =~ /Cyrillic letter/) {
	    if ($lc_char) {
	       $typed_char = "B";
	    } else {
	       $typed_char = "b";
	    }
         } elsif ($char_type =~ /Greek letter/) {
	    if ($lc_char) {
	       $typed_char = "E";
	    } else {
	       $typed_char = "e";
	    }
         } elsif ($char_type =~ /Armenian letter/i) {
	    if ($lc_char) {
	       $typed_char = "Y";
	    } else {
	       $typed_char = "y";
	    }
         } elsif ($char_type =~ /(Georgian|Coptic) letter/i) {
	    if ($lc_char) {
	       $typed_char = "G";
	    } else {
	       $typed_char = "g";
	    }
         } elsif ($char_type =~ /(Devanagari|Bengali|Gujarati|Gurmukhi|Kannada|Malayalam|Oriya|Sinhala|Tamil|Telegu) letter/i) {
	    $typed_char = "I";
         } elsif ($char_type =~ /(Balinese|Javanese|Khmer|Lao|Myanmar|Sundanese|Thai) (character|letter)/i) {
	    $typed_char = "I";
         } elsif ($char_type =~ /(Hebrew)\b.*\b(letter|accent|point)/i) {
	    $typed_char = "H";
         } elsif ($char_type =~ /(Arabic) letter/i) {
	    $typed_char = "R";
         } elsif ($char_type =~ /(Ethiopic) syllable/i) {
	    $typed_char = "h";
         } elsif ($char_type =~ /CJK character/) {
	    $typed_char = "C";
         } elsif ($char_type =~ /Japanese hiragana character/) {
	    $typed_char = "j";
         } elsif ($char_type =~ /Japanese katagana character/) {
	    $typed_char = "J";
	 # combining accute accent as stress marker for Cyrillic (esp. Russian)
	 } elsif (($char =~ /^\xCC\x81$/) && ($prev_typed_char =~ /^[Bb]$/)) {
	    $typed_char = $prev_typed_char;
         } elsif ($char_type =~ /\b(accent|diacritic|modifier tone|point)\b/) {
	    $typed_char = "d";
         } elsif ($char_type =~ /replacement character/) {
	    $typed_char = "x";
         } elsif ($char_type =~ /\bcharacter\b/) {
	    $typed_char = "c";
         } elsif ($char_type =~ /\bletter\b/) {
	    $typed_char = "l";
         } elsif ($char_type =~ /\bsyllable\b/) {
	    $typed_char = "s";
         } elsif ($char_type =~ /\b(symbol|mathematical operator|box drawing|geometric shape|pictograph)\b/) {
	    $typed_char = "S";
         } elsif ($char_type =~ /\bIPA\b/) {
	    $typed_char = "i";
         } elsif ($char_type =~ /\bcurrency\b/) {
	    $typed_char = "k";
         } elsif ($char_type =~ /\bcontrol-character\b/) {
	    $typed_char = "K";
         } elsif ($char_type =~ /\(invalid\)/) {
	    $typed_char = "X";
         } elsif ($norm_punct) {
	    $typed_char = $norm_punct;
	 # zero width non-joiner for Arabic, Hebrew, Indic, Latin scripts
	 } elsif (($char =~ /^\xE2\x80\x8C$/) && ($prev_typed_char =~ /^[RHIAa]$/)) {
	    $typed_char = $prev_typed_char;
	 # zero width joiner in Indic scripts
	 } elsif (($char =~ /^\xE2\x80\x8D$/) && ($prev_typed_char =~ /^[I]$/)) {
	    $typed_char = $prev_typed_char;
         } else {
	    $typed_char = $char;
         }
         $ht{TYPE_CHAR}->{$char} = $typed_char unless $char =~ /^\xE2\x80[\x8C\x8D]$/;
      }
      push(@typed_chars, $typed_char);
      $prev_typed_char = $typed_char;
   }
   return @typed_chars;
}

my @token_type_preference_order = ("URL", "FILENAME", "TIMESTAMP", "EMAIL", "XML-TAG", "LI-TOKEN", "HANDLE", "HASHTAG", "IPA", "M-NAME", "S-WORD", "ABBREV", "IP-ADDRESS", "PHONE-NUMBER", "S-NUMBER", "NUMBER", "SYMBOL", "PUNCT", "WORD", "CHAR", "NORM-STRING", "ENCODING-CORRECTION", "IGNORABLE", "");
sub find_best_token_path {
   local($this, $text_id, *ht, *LOG, $verbose) = @_;

   $this->stopwatch("start", "find_best_token_path", *ht, *LOG);
   my $start_vertex = $ht{ORIG_START}->{$text_id};
   my $end_vertex = $ht{ORIG_END}->{$text_id};
   my $current_vertex = $start_vertex;
   @best_token_id_list = ();
   while ($current_vertex < $end_vertex) {
      my @token_ids = keys %{$ht{START_ID}->{$text_id}->{$current_vertex}};
      my $best_token_id = "";
      my $best_token_type = "";
      my $best_token_type_priority = 9999;
      my $best_token_end = $current_vertex;
      foreach $token_id (@token_ids) {
	 next unless $ht{TOKEN_ACTIVE_P}->{$text_id}->{$token_id};
	 next if $ht{ALT_TOKEN_P}->{$text_id}->{$token_id};
	 my $token_type = $ht{TOKEN_TYPE}->{$text_id}->{$token_id} || "";
         my $token_end = $ht{ID_END}->{$text_id}->{$token_id};
	 if ($token_end > $best_token_end) {
	    $best_token_id = $token_id;
	    $best_token_end = $token_end;
	    $best_token_type = $token_type;
	    $best_token_type_priority = $this->position($best_token_type, @token_type_preference_order);
	 } elsif ($token_end == $best_token_end) {
	    my $token_type = $ht{TOKEN_TYPE}->{$text_id}->{$token_id} || "";
	    my $token_type_priority = $this->position($token_type, @token_type_preference_order);
	    if ($token_type_priority < $best_token_type_priority) {
	       $best_token_id = $token_id;
	       $best_token_end = $token_end;
	       $best_token_type = $token_type;
	       $best_token_type_priority = $token_type_priority;
	    }
	 }
      }
      if ($best_token_id) {
	 push(@best_token_id_list, $best_token_id) unless $best_token_type eq "IGNORABLE";
         $current_vertex = $best_token_end;
      } else {
         my $char = $ht{ORIG_CHAR}->{$text_id}->{$current_vertex};
	 my $char_type = $this->cached_character_type($char, *ht);
	 if ($char_type =~ /whitespace$/) {
            $current_vertex++;
	 } else {
	    my $token_end = $current_vertex+1;
	    my $char_type = $this->cached_character_type($char, *ht);
	    my $token_type = ($char_type =~ /\bpunctuation$/i) ? "PUNCT" : "CHAR";
            my $token_id = $this->new_token_id(*ht, $text_id, $token_type);
            $this->register_markup(*ht, $text_id, $token_id, $token_type, $current_vertex, $token_end, $char, $verbose, 0, *LOG, "single char default", "orig");
	    push(@best_token_id_list, $token_id);
            $current_vertex = $token_end;
	 }
      }
   }
   @{$ht{BEST_TOKEN_ID_LIST}->{$text_id}} = @best_token_id_list;
   my $n_tokens = @best_token_id_list;
   $ht{N_TOKENS}->{$text_id} = $n_tokens;

   if ($verbose) {
      my $n_orig_chars = $ht{ORIG_END}->{$text_id} - $ht{ORIG_START}->{$text_id};
      my $n_norm_chars = $ht{NORM_END}->{$text_id} - $ht{NORM_START}->{$text_id};
      print LOG "$text_id has $n_tokens tokens with $n_orig_chars/$n_norm_chars characters: $text\n";
      $this->log_best_token_path($text_id, *ht, *LOG);
   }
   $this->stopwatch("end", "find_best_token_path", *ht, *LOG);
}

sub find_alt_tokens {
   local($this, $text_id, *ht, *LOG, $verbose) = @_;

   $this->stopwatch("start", "find_alt_tokens", *ht, *LOG);
   my $start_vertex = $ht{ORIG_START}->{$text_id};
   my $end_vertex = $ht{ORIG_END}->{$text_id};
   my $current_vertex = $start_vertex;
   @alt_token_id_list = ();
   while ($current_vertex < $end_vertex) {
      my @token_ids = keys %{$ht{START_ID}->{$text_id}->{$current_vertex}};
      foreach $token_id (@token_ids) {
	 next unless $ht{TOKEN_ACTIVE_P}->{$text_id}->{$token_id};
	 next unless $ht{ALT_TOKEN_P}->{$text_id}->{$token_id};
	 push(@alt_token_id_list, $token_id);
      }
      $current_vertex++;
   }
   @{$ht{ALT_TOKEN_ID_LIST}->{$text_id}} = @alt_token_id_list;
   my $n_alt_tokens = @alt_token_id_list;
   $ht{N_ALT_TOKENS}->{$text_id} = $n_alt_tokens;

   $this->log_alt_tokens($text_id, *ht, *LOG) if $verbose;
   $this->stopwatch("end", "find_alt_tokens", *ht, *LOG);
}

sub log_best_token_path {
   local($this, $text_id, *ht, *LOG) = @_;

   my @best_token_id_list = @{$ht{BEST_TOKEN_ID_LIST}->{$text_id}};
   print LOG "Best token path for $text_id:";
   foreach $token_id (@best_token_id_list) {
      my $token_start = $ht{ID_START}->{$text_id}->{$token_id};
      my $token_end = $ht{ID_END}->{$text_id}->{$token_id};
      my $token_span = "$token_start-$token_end";
      my $token_type = $ht{TOKEN_TYPE}->{$text_id}->{$token_id};
      my $token_text = $ht{TOKEN_TEXT}->{$text_id}->{$token_id};
      print LOG " $token_text ($token_span, $token_type)";
   }
   print LOG "\n";
}

sub log_alt_tokens {
   local($this, $text_id, *ht, *LOG) = @_;

   my @alt_token_id_list = @{$ht{ALT_TOKEN_ID_LIST}->{$text_id}};
   if (@alt_token_id_list) {
      print LOG "Alt tokens for $text_id:";
      foreach $token_id (@alt_token_id_list) {
         my $token_start = $ht{ID_START}->{$text_id}->{$token_id};
         my $token_end = $ht{ID_END}->{$text_id}->{$token_id};
         my $token_span = "$token_start-$token_end";
         my $token_type = $ht{TOKEN_TYPE}->{$text_id}->{$token_id};
         my $token_text = $ht{TOKEN_TEXT}->{$text_id}->{$token_id};
         print LOG " $token_text ($token_span, $token_type)";
      }
      print LOG "\n";
   }
}

sub write_json_token_lattice_line {
   local($this, $text_id, *ht, *OUT) = @_;

   my $sg_text_id = $this->string_guard($text_id);
   $sg_text_id = "" unless defined($sg_text_id);
   my $orig_text = $ht{ORIG_TEXT}->{$text_id};
   $orig_text = "" unless defined($orig_text);
   my $sg_orig_text = $this->string_guard($orig_text);
   my @best_token_id_list = @{$ht{BEST_TOKEN_ID_LIST}->{$text_id}};
   my @alt_token_id_list = @{$ht{ALT_TOKEN_ID_LIST}->{$text_id}};
   my $comma1 = (@best_token_id_list || @alt_token_id_list || ($orig_text =~ /\S/)) ? "," : "";
   my $comma2 = (@best_token_id_list || @alt_token_id_list) ? "," : "";
   my $comma3 = (@alt_token_id_list) ? "," : "";
   print OUT " {\n";
   print OUT "  \"text-id\": \"$sg_text_id\"$comma1\n" if $sg_text_id =~ /\S/;
   print OUT "  \"text\": \"$sg_orig_text\"$comma2\n" if $orig_text =~ /\S/;
   if (@best_token_id_list) {
      print OUT "  \"primary-tokens\": [\n";
      foreach $i ((0 .. $#best_token_id_list)) {
	 my $token_id = $best_token_id_list[$i];
         $this->write_json_token_lattice_token($text_id, $token_id, *ht, *OUT);
	 print ",\n" unless $i == $#best_token_id_list;
      }
      print OUT "]$comma3\n";
   }
   if (@alt_token_id_list) {
      print OUT "  \"secondary-tokens\": [\n";
      foreach $i ((0 .. $#alt_token_id_list)) {
         my $token_id = $alt_token_id_list[$i];
         $this->write_json_token_lattice_token($text_id, $token_id, *ht, *OUT);
	 print ",\n" unless $i == $#alt_token_id_list;
      }
      print OUT "]\n";
   }
   print OUT " }\n";
}

sub write_json_token_lattice_token {
   local($this, $text_id, $token_id, *ht, *OUT) = @_;

   my $token_text = $ht{TOKEN_TEXT}->{$text_id}->{$token_id};
   my $token_type = $ht{TOKEN_TYPE}->{$text_id}->{$token_id};
   my $token_start = $ht{ID_START}->{$text_id}->{$token_id};
   my $token_end = $ht{ID_END}->{$text_id}->{$token_id};
   my $token_span = "$token_start-$token_end";
   my $token_sub_type = $ht{TOKEN_SUB_TYPE}->{$text_id}->{$token_id} || "";
   my $orig_token_text = $ht{ORIG_TOKEN_TEXT}->{$text_id}->{$token_id};
   $orig_token_text = "" unless defined($orig_token_text);
   my $token_ne_type = $ht{TOKEN_NE_TYPE}->{$text_id}->{$token_id} || "";
   my $token_etym_lang_code = $ht{TOKEN_ETYM}->{$text_id}->{$token_id} || "";
   my $token_abbrev_expansion = $ht{TOKEN_ABBREV_EXPANSION}->{$text_id}->{$token_id} || "";
   my $token_taxon = $ht{TOKEN_TAXON}->{$text_id}->{$token_id} || "";
   my $token_eng_gloss = $ht{TOKEN_GLOSS}->{$text_id}->{$token_id}->{"eng"} || "";
   my $token_original_misspelling = $ht{TOKEN_ORIGINAL_MISSPELLING}->{$text_id}->{$token_id};
   $token_original_misspelling = "" unless defined($token_original_misspelling);
   my $sg_token_text = $this->string_guard($token_text);
   my $sg_token_type = $this->string_guard($token_type);
   my $sg_token_sub_type = $this->string_guard($token_sub_type);
   my $sg_orig_token_text = $this->string_guard($orig_token_text);
   my $sg_token_ne_type = $this->string_guard($token_ne_type);
   my $sg_token_etym_lang_code = $this->string_guard($token_etym_lang_code);
   my $sg_token_abbrev_expansion = $this->string_guard($token_abbrev_expansion);
   my $sg_token_taxon = $this->string_guard($token_taxon);
   my $sg_token_eng_gloss = $this->string_guard($token_eng_gloss);
   my $sg_token_original_misspelling = $this->string_guard($token_original_misspelling);

   print OUT "    { \"token\": \"$sg_token_text\"";
   print OUT ", \"type\": \"$sg_token_type\"";
   print OUT ", \"span\": \"$token_span\"";
   print OUT ", \"sub-type\": \"$sg_token_sub_type\"" if $token_sub_type;
   print OUT ", \"orig-text\": \"$sg_orig_token_text\"" if ($orig_token_text ne $token_text) && ($orig_token_text =~ /\S/);
   print OUT ", \"NE-type\": \"$sg_token_ne_type\"" if $token_ne_type;
   print OUT ", \"etym\": \"$sg_token_etym_lang_code\"" if $token_etym_lang_code;
   print OUT ", \"abbrev-expansion\": \"$sg_token_abbrev_expansion\"" if $token_abbrev_expansion;
   print OUT ", \"taxon\": \"$sg_token_taxon\"" if $token_taxon;
   print OUT ", \"gloss\": \"$sg_token_eng_gloss\"" if $token_eng_gloss;
   print OUT ", \"orig-misspelling\": \"$sg_token_original_misspelling\"" if $token_original_misspelling;
   print OUT " }";
}

sub first_char_of_string {
   local($this, $s) = @_;

   $s =~ s/^(.[\x80-\xBF]*).*$/$1/;
   return $s;
}

sub last_char_of_string {
   local($this, $s) = @_;

   $s =~ s/^.*([^\x80-\xBF][\x80-\xBF]*)$/$1/;
   return $s;
}

sub first_n_chars_of_string {
   local($this, $s, $n) = @_;

   $s =~ s/^((?:.[\x80-\xBF]*){$n,$n}).*$/$1/;
   return $s;
}

sub last_n_chars_of_string {
   local($this, $s, $n) = @_;

   $s =~ s/^.*((?:[^\x80-\xBF][\x80-\xBF]*){$n,$n})$/$1/;
   return $s;
}

sub identify_short_token_clusters_in_best_token_path {
   local($this, $text_id, *ht, *LOG, $verbose, *lang_codes) = @_;

   my $snt_start = $ht{NORM_START}->{$text_id};
   my $snt_end = $ht{NORM_END}->{$text_id};
   my @best_token_id_list = @{$ht{BEST_TOKEN_ID_LIST}->{$text_id}};
   my @adj_token_text_lengths = ();
   my @token_texts = ();
   my @adj_ngram_lengths  = (0, 0, 0, 0, 0, 0); # 0-gram to 5-gram
   my @adj_ngram_max_sums = (0, 1.5, 2, 2.5, 3, 3.5);
   foreach $i ((0 .. $#best_token_id_list)) {
      my $token_id = $best_token_id_list[$i];
      my $token_text = $ht{TOKEN_TEXT}->{$text_id}->{$token_id};
      my $token_start = $ht{ID_START}->{$text_id}->{$token_id};
      my $token_end = $ht{ID_END}->{$text_id}->{$token_id};
      my $last_token_id = ($i >= 1) ? $best_token_id_list[$i-1] : "";
      my $last_token_end = ($last_token_id) ? $ht{ID_END}->{$text_id}->{$last_token_id} : $snt_start;
      my $next_token_id = ($i < $#best_token_id_list) ? $best_token_id_list[$i+1] : "";
      my $next_token_start = ($next_token_id) ? $ht{ID_START}->{$text_id}->{$next_token_id} : $snt_end;
      my $token_text_length = $utf8->length_in_utf8_chars($token_text);
      my $adj_token_text_length = $token_text_length;
      my $split_on_left_p = ($last_token_end == $token_start) && ($token_start > $snt_start);
      my $split_on_right_p = ($token_end == $next_token_start) && ($token_end < $snt_end);
      $adj_token_text_length -= 0.5 if $split_on_left_p;
      $adj_token_text_length -= 0.5 if $split_on_right_p;
      push(@adj_token_text_lengths, $adj_token_text_length);
      push(@token_texts, $token_text);
      foreach $j ((1 .. 5)) { # size of ngram (e.g. 3-gram)
         $adj_ngram_lengths[$j] += $adj_token_text_length;
         $adj_ngram_lengths[$j] -= $adj_token_text_lengths[$i-$j] if $i-$j >= 0;
	 my $start_i = $i-$j+1;
	 next unless $start_i >= 0;
	 my $token_cluster_text = join(" ", @token_texts[$start_i .. $i]);
	 my $valid_cluster_p = 0;
	 my $invalid_cluster_p = 0;
	 $valid_cluster_p = 1 if ($token_cluster_text =~ /^\d+ : \d+$/) # 18 : 30
	                      || ($token_cluster_text =~ /^[12]\d\d\d - (?:0[1-9]|1[0-2]) - (?:0[1-9]|[12]\d|3[01])$/)
	                      || ($token_cluster_text =~ /^\( \d+ \)$/)
	                      || ($token_cluster_text =~ /^\[ \d+ \]$/)
			      || (($token_cluster_text =~ /^.[\x80-\xBF]*$/) # single letter/number between orig. spaces
			       && (! ($split_on_left_p || $split_on_right_p))
			       && ($type_char = $ht{TYPE_CHAR}->{$token_cluster_text})
			       && ($type_char =~ /^[AaBbcEeGgHhIJjlRsYy123]$/));
	 foreach $lang_code (@lang_codes) {
	    last if $valid_cluster_p;
	    $valid_cluster_p = 1 if $ht{VALID_CLUSTER}->{$lang_code}->{$token_cluster_text};
	 }
	 foreach $lang_code (@lang_codes) {
	    last if $invalid_cluster_p;
	    $invalid_cluster_p = 1 if $ht{INVALID_CLUSTER}->{$lang_code}->{$token_cluster_text};
	 }
	 # VALID-CLUSTER
	 if ($valid_cluster_p) {
	    foreach $k (($start_i .. $i)) {
	       my $k_token_id = $best_token_id_list[$k];
	       $ht{TOKEN_IN_VALID_TOKEN_CLUSTER_P}->{$text_id}->{$k_token_id} = 1 if $j >= 2;
	    }
	 } else {
	    my $adj_ngram_length  = $adj_ngram_lengths[$j];
	    my $adj_ngram_max_sum = $adj_ngram_max_sums[$j];
	    if ($invalid_cluster_p || ($adj_ngram_length <= $adj_ngram_max_sum)) {
	       foreach $k (($start_i .. $i)) {
	          my $k_token_id = $best_token_id_list[$k];
	          $ht{TOKEN_IN_SHORT_TOKEN_CLUSTER_P}->{$text_id}->{$k_token_id} = 1;
	        # print LOG "** SHORT $text_id $k_token_id $token_text ($token_start-$token_end) ts:$k-$i l:$token_text_length/al:$adj_token_text_length $token_cluster_text ($j-gram) $adj_ngram_length/$adj_ngram_max_sum\n" if $verbose && $tokenization_log_verbose;
	       }
	    }
	 }
      }
   }
   foreach $token_id (keys %{$ht{TOKEN_IN_VALID_TOKEN_CLUSTER_P}->{$text_id}}) {
      $ht{TOKEN_IN_SHORT_TOKEN_CLUSTER_P}->{$text_id}->{$token_id} = 0;
   }
}

sub token_title_text {
   local($this, $text_id, $token_id, *ht, *LOG, $verbose) = @_;

   my $token_text  = $ht{TOKEN_TEXT}->{$text_id}->{$token_id};
   my $token_type  = $ht{TOKEN_TYPE}->{$text_id}->{$token_id};
   my $token_sub_type = $ht{TOKEN_SUB_TYPE}->{$text_id}->{$token_id};
   my $token_start = $ht{ID_START}->{$text_id}->{$token_id};
   my $token_end   = $ht{ID_END}->{$text_id}->{$token_id};
   my $token_span = "$token_start-$token_end";
   my $orig_token_text = $ht{ORIG_TOKEN_TEXT}->{$text_id}->{$token_id};
   my $token_text_modified_p = (defined($orig_token_text) && ($orig_token_text ne "") && ($orig_token_text ne $token_text));
   my $token_text_spell_corrected_p = $token_text_modified_p && defined($token_original_misspelling);
   my $token_ne_type = $ht{TOKEN_NE_TYPE}->{$text_id}->{$token_id}; # e.g. city
   my $token_etym_lang_code = $ht{TOKEN_ETYM}->{$text_id}->{$token_id}; # e.g. lat
   my $token_abbrev_expansion = $ht{TOKEN_ABBREV_EXPANSION}->{$text_id}->{$token_id}; # e.g. kilometer
   my $token_taxon = $ht{TOKEN_TAXON}->{$text_id}->{$token_id}; # e.g. species
   my $token_eng_gloss = $ht{TOKEN_GLOSS}->{$text_id}->{$token_id}->{"eng"} || "";
   my $token_spell_corrected = $ht{TOKEN_SPELL_CORRECTED}->{$text_id}->{$token_id}; # boolean
   my $token_original_misspelling = $ht{TOKEN_ORIGINAL_MISSPELLING}->{$text_id}->{$token_id}; # e.g. recieve
   my $token_script_descr = $ht{TOKEN_SCRIPT_DESCR}->{$text_id}->{$token_id}; # e.g. consists of 3 Greek letters

   my $title_text = "$token_text";
   $title_text .= " &nbsp; ($token_abbrev_expansion)" if $token_abbrev_expansion;
   $title_text .= " &nbsp; (\"$token_eng_gloss\")" if $token_eng_gloss;
   $title_text .= " &nbsp; (spelling corrected)" if $token_text_spell_corrected_p;
   $title_text .= "\n$text_id &nbsp; $token_span";
   if ($token_ne_type) {
      $title_text .= "\nname ($token_ne_type)";
   } elsif ($token_taxon) {
      $title_text .= "\n$token_taxon";
   } elsif ($token_sub_type) {
      $title_text .= "\n$token_sub_type";
   } elsif ($token_abbrev_expansion) {
      $title_text .= "\nABBREV";
   } elsif ($token_type) {
      $title_text .= "\n$token_type";
   }
   if ($token_text_modified_p) {
      my $g_orig_token_text = $this->guard_html($orig_token_text, "strict");
      $title_text .= "\nOriginal text: $g_orig_token_text";
   }
   if (defined($token_original_misspelling)) {
      if ($token_text_modified_p && ($orig_token_text eq $token_original_misspelling)) {
         $title_text .= " &nbsp; (spelling incorrect)";
      } else {
         $title_text .= "\nOriginally misspelled as: $token_original_misspelling";
      }
   }
   if ($token_script_descr) {
      $title_text .= "\n$token_script_descr";
   }
   if ($token_etym_lang_code) {
      my $token_etym_lang_name = $ht{LANG_PRIMARY_NAME}->{$token_etym_lang_code} || $token_etym_lang_code;
      $title_text .= "\nEtymology: $token_etym_lang_name";
   }
   return $title_text;
}

sub write_best_token_path {
   local($this, $text_id, *ht, *OUT, $out_p, *HTML, $html_p, *LOG, $verbose, $control, *lang_codes) = @_;
   # control: $out_p whether or not to actually write to *out; *HTML/$html_p, *LOG/$verbose correspondingly
   
   my $add_mt_tok_at_signs_p = ($control =~ /\badd_mt_tok_at_signs\b/);

   $this->stopwatch("start", "write_best_token_path", *ht, *LOG);
   $this->identify_short_token_clusters_in_best_token_path($text_id, *ht, *LOG, $verbose, *lang_codes) if $html_p || ($verbose && $tokenization_log_verbose);
   my $start_vertex = $ht{ORIG_START}->{$text_id};
   my $end_vertex = $ht{ORIG_END}->{$text_id};
   my $position = $start_vertex;
   my @best_token_id_list = @{$ht{BEST_TOKEN_ID_LIST}->{$text_id}};
   my $last_token_text = "";
   my $last_token_type = "";
   my $last_token_end = $position;
   my $last_add_at_sign2_p = 0;
   my $token_id = "";
   my $token_text = "";
   my $token_type = "";
   my $token_start = "";
   my $token_end = "";
   my $next_token_id = "";
   my $next_token_text = "";
   my $next_token_type = "";
   my $next_token_start = $end_vertex;
   if ($#best_token_id_list >= 0) {
      $next_token_id = $best_token_id_list[0];
      $next_token_text = $ht{TOKEN_TEXT}->{$text_id}->{$next_token_id};
      $next_token_type = $ht{TOKEN_TYPE}->{$text_id}->{$next_token_id};
      $next_token_start =  $ht{ID_START}->{$text_id}->{$next_token_id};
   }
   foreach $i ((0 .. $#best_token_id_list)) {
      my $token_id    = $next_token_id;
      my $token_text  = $next_token_text;
      my $token_type  = $next_token_type;
      my $token_start = $next_token_start;
      my $token_end = $ht{ID_END}->{$text_id}->{$token_id};
      my $token_span = "$token_start-$token_end";
      my $token_sub_type = $ht{TOKEN_SUB_TYPE}->{$text_id}->{$token_id};
      my $token_etym_lang_code = $ht{TOKEN_ETYM}->{$text_id}->{$token_id}; # e.g. lat
      my $token_ne_type = $ht{TOKEN_NE_TYPE}->{$text_id}->{$token_id}; # e.g. city
      my $token_abbrev_expansion = $ht{TOKEN_ABBREV_EXPANSION}->{$text_id}->{$token_id}; # e.g. kilometer
      my $token_taxon = $ht{TOKEN_TAXON}->{$text_id}->{$token_id}; # e.g. species
    # my $token_eng_gloss = $ht{TOKEN_GLOSS}->{$text_id}->{$token_id}->{"eng"} || "";
      my $token_spell_corrected = $ht{TOKEN_SPELL_CORRECTED}->{$text_id}->{$token_id}; # boolean
      my $token_original_misspelling = $ht{TOKEN_ORIGINAL_MISSPELLING}->{$text_id}->{$token_id}; # e.g. recieve
      my $token_script_descr = $ht{TOKEN_SCRIPT_DESCR}->{$text_id}->{$token_id}; # e.g. consists of 3 Greek letters
      my $orig_token_text = $ht{ORIG_TOKEN_TEXT}->{$text_id}->{$token_id};
      if ($i+1 <= $#best_token_id_list) {
         $next_token_id    = $best_token_id_list[$i+1];
         $next_token_text  = $ht{TOKEN_TEXT}->{$text_id}->{$next_token_id};
         $next_token_type  = $ht{TOKEN_TYPE}->{$text_id}->{$next_token_id};
         $next_token_start =   $ht{ID_START}->{$text_id}->{$next_token_id};
      } else {
         $next_token_id    = "";
         $next_token_text  = "";
         $next_token_type  = "";
         $next_token_start = $end_vertex;
      }
      my $n_spaces1 = $token_start - $position; # natural whitespaces before token
      my $n_spaces2 = $next_token_start - $token_end; # natural whitespaces after token
      my $add_space1_p = 0;
      my $add_space2_p = 0;
      my $add_at_sign1_p = 0;
      my $add_at_sign2_p = 0;
      if (($n_spaces1 == 0) && ($last_token_text =~ /\S$/)) {
         $add_space1_p = 1;
         $n_spaces1 = 1;
      }
      if (($n_spaces2 == 0) && ($next_token_text =~ /^\S/)) {
         $add_space2_p = 1;
	 $n_spaces2 = 1;
      }
      if ($add_mt_tok_at_signs_p && $out_p) {
         if (($token_text =~ /^<.*>$/) && ($token_type eq "XML-TAG")) {
	    if ($token_text =~ /^<.*\/>$/) { # open-and-close tag
	       $add_at_sign1_p = 1 if $add_space1_p;
	       $add_at_sign2_p = 1 if $add_space2_p;
	    } elsif ($token_text =~ /^<\//) { # close tag
	       $add_at_sign2_p = 1 if $add_space2_p;
	    } else { # open tag
	       $add_at_sign1_p = 1 if $add_space1_p;
	    }
	 } elsif ($token_text eq ":") {
	    $add_at_sign2_p = 1 if $add_space2_p;
	    if ($add_space1_p) {
	       my $last_token_text_char = $this->last_char_of_string($last_token_text);
	       my $last_token_text_type_char = $ht{TYPE_CHAR}->{$last_token_text_char};
	       $add_at_sign1_p = 1 unless ($last_token_text_type_char =~ /[AaBbcEeGgHhIJjlRsYy]/)
	                               || (($last_token_text_type_char =~ /[1\(\)]/)
				          && (! $add_at_sign2_p));
	    }
	 } elsif ($token_text =~ /^(?:[-_*"]|\xE2\x80[\x93\x94])+$/) {
	    $add_at_sign1_p = 1 if $add_space1_p;
	    $add_at_sign2_p = 1 if $add_space2_p;

	 # possibly temporary:
	 } elsif ($token_text eq "/") {
	    $add_at_sign1_p = 1 if $add_space1_p;
	    $add_at_sign2_p = 1 if $add_space2_p;
	 }

         $add_at_sign1_p = 0 if $last_add_at_sign2_p ;
         $add_at_sign1_p = 0 if $last_token_text =~ /\@$/;
	 $add_at_sign1_p = 0 if $last_token_text =~ /^[\(]$/;
         $add_at_sign2_p = 0 if $next_token_text =~ /^\@/;
	 $add_at_sign2_p = 0 if $next_token_text =~ /^[.,;!?\)]$/;
      }
      # Note: in some cases, add " \@\@ ", e.g. between ASCII and Arabic (?)

      foreach $i ((1 .. $n_spaces1)) {
         print OUT " " if $out_p;
         print HTML " " if $html_p;
      }
      print OUT "\@" if $add_at_sign1_p;
      $position = $token_start;
      if ($html_p) {
         my $title_text = $this->token_title_text($text_id, $token_id, *ht, *LOG, $verbose);
	 my $alt_tokens_p = 0;
	 foreach $alt_token_id (sort { ($ht{ID_START}->{$text_id}->{$a} <=> $ht{ID_START}->{$text_id}->{$b})
	                            || ($ht{ID_END}->{$text_id}->{$b} <=> $ht{ID_END}->{$text_id}->{$a})
	                            || ($ht{TOKEN_TEXT}->{$text_id}->{$a} cmp $ht{TOKEN_TEXT}->{$text_id}->{$b}) }
	                             keys %{$ht{ALT_TOKENS}->{$text_id}->{$token_id}}) {
	    $title_text .= "\n\n" . $this->token_title_text($text_id, $alt_token_id, *ht, *LOG, $verbose);
	    $alt_tokens_p = 1;
	 }
	 my $token_text_modified_p = (defined($orig_token_text) && ($orig_token_text ne "") && ($orig_token_text ne $token_text));
	 my $html_token_type = $token_ne_type || $token_taxon || $token_sub_type || $token_type;
         my $html_id = $this->new_html_id(*ht, $html_token_type);

         my $g_title_text = $this->guard_html_quote($title_text);
         my $g_token_text = $this->guard_html($token_text);
	 my $font_color = "black"; # "NUMBER", "PUNCT", "WORD", "CHAR"
	 $font_color = "#A04010" if $alt_tokens_p;
	 $font_color = "#0000CC" if $this->member($token_type, "LI-TOKEN", "M-NAME", "S-WORD", "ABBREV", "SYMBOL");
	 $font_color = "#0000CC" if (! $alt_tokens_p) && ($token_sub_type || $token_etym_lang_code || $token_ne_type || $token_abbrev_expansion || $token_taxon || $token_original_misspelling);
	 $font_color = "#0000CC" if $this->member($token_type, "WORD") && ($token_text =~ /\S\s+\S/); # multi-word
	 $font_color = "#00AA00" if $this->member($token_type, "URL", "FILENAME", "TIMESTAMP", "EMAIL", "XML-TAG", "HANDLE", "HASHTAG", "IPA", "IP-ADDRESS", "PHONE-NUMBER", "S-NUMBER");
	 $font_color = "#990099" if $this->member($token_type, "NORM-STRING", "ENCODING-CORRECTION", "IGNORABLE", "");
	 $font_color = "#990099" if $token_text_modified_p;
	 $font_color = "#FF6600" if $ht{TOKEN_IN_SHORT_TOKEN_CLUSTER_P}->{$text_id}->{$token_id};
	 my $g2_title_text = $g_title_text;
	 $g2_title_text =~ s/'/\\'/g;
	 $g2_title_text =~ s/"/\\"/g;
	 $g2_title_text =~ s/&/&amp;/g;
       # $g2_title_text =~ s/&lt;(U\+[0-9A-F]+)&gt;/&amp;lt;$1&amp;gt;/gi;
         $g2_title_text =~ s/\n/<br>/g;
	 my $click_clause = " onclick=\"popup_with_token_info('$g2_title_text','$html_id');\"";
         my $style_clause = " style=\"color:$font_color;\"";
         print HTML "<span id=\"$html_id\" title=\"$g_title_text\"$style_clause onmouseover=\"highlight_elem('$html_id','1');\" onmouseout=\"highlight_elem('$html_id','0');\"$click_clause>$g_token_text<\/span>";
      }
      print OUT $token_text if $out_p;
      print OUT "\@" if $add_at_sign2_p;
      $last_token_text = $token_text;
      $last_token_type = $token_type;
      $last_token_end = $token_end;
      $last_add_at_sign2_p = $add_at_sign2_p;
      $position = $token_end; 
   }
   my $n_spaces1 = $end_vertex - $position;
   foreach $i ((1 .. $n_spaces1)) {
      print OUT " " if $out_p;
      print HTML " " if $html_p;
   }
   print OUT "\n" if $out_p;
   print HTML "<br>\n" if $html_p;
   $this->stopwatch("end", "write_best_token_path", *ht, *LOG);
}

sub tokenize_in_lattice {
   local($this, $text, $text_id, *ht, *LOG, $verbose, $offset, *lang_codes) = @_;

   $tokenization_log_verbose = $verbose;
   $this->stopwatch("start", "tokenize-prep", *ht, *LOG);
   $control = "" unless defined($control);
   my $bio_p = ($control =~ /\bbio\b/);

   $this->register_orig_norm_text(*ht, $text, $text_id, $offset, *LOG, $verbose);
   my $text = $ht{NORM_TEXT}->{$text_id};
   my $typed_text = $ht{NORM_TYPED_TEXT}->{$text_id};
 # print LOG "tokenize_in_lattice $text :: $typed_text\n" if $verbose;
   $this->stopwatch("end", "tokenize-prep", *ht, *LOG);

 # $this->print_norm_text(*ht, $text_id, *LOG, 0, "INIT");
 # $this->update_norm_text(*ht, $text_id, 3, 8, "can n't", "0-3:0-3;4-7:2-5", *LOG, 0); # new "can n't" -> old "can't"

 $this->stopwatch("start", "markups", *ht, *LOG);
 $this->stopwatch("start", "markup_encoding_errors", *ht, *LOG);
   $this->markup_encoding_errors(*ht, $text_id, *LOG, 0);
 $this->stopwatch("end", "markup_encoding_errors", *ht, *LOG);
 $this->stopwatch("start", "markup_ignorable_characters", *ht, *LOG);
   $this->markup_ignorable_characters(*ht, $text_id, *LOG, 0);
 $this->stopwatch("end", "markup_ignorable_characters", *ht, *LOG);
 $this->stopwatch("start", "markup_xml_tags", *ht, *LOG);
   $this->markup_xml_tags(*ht, $text_id, *LOG, 0); # includes character references such as &eacute;
 $this->stopwatch("end", "markup_xml_tags", *ht, *LOG);
 $this->stopwatch("start", "markup_urls", *ht, *LOG);
   $this->markup_urls(*ht, $text_id, *LOG, 0);
 $this->stopwatch("end", "markup_urls", *ht, *LOG);
 $this->stopwatch("start", "markup_filenames", *ht, *LOG);
   $this->markup_filenames(*ht, $text_id, *LOG, 0);
 $this->stopwatch("end", "markup_filenames", *ht, *LOG);
 $this->stopwatch("start", "markup_emails", *ht, *LOG);
   $this->markup_emails(*ht, $text_id, *LOG, 0);
 $this->stopwatch("end", "markup_emails", *ht, *LOG);
 $this->stopwatch("start", "markup_handles", *ht, *LOG);
   $this->markup_handles(*ht, $text_id, *LOG, 0);
 $this->stopwatch("end", "markup_handles", *ht, *LOG);
 $this->stopwatch("start", "markup_hashtags", *ht, *LOG);
   $this->markup_hashtags(*ht, $text_id, *LOG, 0);
 $this->stopwatch("end", "markup_hashtags", *ht, *LOG);
 $this->stopwatch("start", "markup_ipas", *ht, *LOG);
   $this->markup_ipas(*ht, $text_id, *LOG, 0);
 $this->stopwatch("end", "markup_ipas", *ht, *LOG);
 $this->stopwatch("start", "markup_abbreviations", *ht, *LOG);
   $this->markup_abbreviations(*ht, $text_id, *LOG, 0, *lang_codes);
 $this->stopwatch("end", "markup_abbreviations", *ht, *LOG);
 $this->stopwatch("start", "markup_phone_numbers", *ht, *LOG);
   $this->markup_phone_numbers(*ht, $text_id, *LOG, 0, *lang_codes); # also covers IP addresses, timestamps, s-numbers
 $this->stopwatch("end", "markup_phone_numbers", *ht, *LOG);
 $this->stopwatch("start", "markup_li_tokens", *ht, *LOG);
   $this->markup_li_tokens(*ht, $text_id, *LOG, 0, *lang_codes);
 $this->stopwatch("end", "markup_li_tokens", *ht, *LOG);
 $this->stopwatch("start", "markup_mnames", *ht, *LOG);
   $this->markup_mnames(*ht, $text_id, *LOG, 0, *lang_codes); # AK-47 TFG-beta2
 $this->stopwatch("end", "markup_mnames", *ht, *LOG);
 $this->stopwatch("start", "markup_s_words", *ht, *LOG);
   $this->markup_s_words(*ht, $text_id, *LOG, 0);
 $this->stopwatch("end", "markup_s_words", *ht, *LOG);
 $this->stopwatch("start", "markup_symbols", *ht, *LOG);
   $this->markup_symbols(*ht, $text_id, *LOG, 0); # covers SYMBOL(s) and PUNCT clusters
 $this->stopwatch("end", "markup_symbols", *ht, *LOG);
 $this->stopwatch("start", "markup_words", *ht, *LOG);
   $this->markup_words(*ht, $text_id, *LOG, 0);
 $this->stopwatch("end", "markup_words", *ht, *LOG);
 $this->stopwatch("start", "markup_numbers", *ht, *LOG);
   $this->markup_numbers(*ht, $text_id, *LOG, 0, *lang_codes); # -123,456.78
 $this->stopwatch("end", "markup_numbers", *ht, *LOG);
 $this->stopwatch("end", "markups", *ht, *LOG);

   $this->find_best_token_path($text_id, *ht, *LOG, $verbose);
   $this->find_alt_tokens($text_id, *ht, *LOG, $verbose);
}

# Obsolete?:
sub white_space_left_context_p {
   local($this, $orig_position, $text_id, *ht) = @_;

   my $orig_start = $ht{ORIG_START}->{$text_id};
   my $position = $orig_position - $orig_start;
 # my @s_chars = @{$ht{ORIG_CHARS}->{$text_id}};
   my @typed_chars = @{$ht{ORIG_TYPED_CHARS}->{$text_id}};
   while ($position > 0) {
      $position--;
      my $typed_char = $typed_chars[$position];
      return 1 if $typed_char =~ /^\s$/;
      return 0 unless $ht{CHAR_IN_ID_BY_TYPE}->{$text_id}->{IGNORABLE}->{($position+$orig_start)};
   }
   return 1;
}

# Obsolete?:
sub write_inter_token_segment {
   local($this, $orig_segment_start, $orig_segment_end, $text_id, *ht, *OUT, $out_p, *HTML, $html_p, *LOG, $verbose) = @_;

   my $orig_start = $ht{ORIG_START}->{$text_id};
   my $segment_start = $orig_segment_start - $orig_start;
   my $segment_end   = $orig_segment_end   - $orig_start;
   my @s_chars = @{$ht{ORIG_CHARS}->{$text_id}};
   my @typed_chars = @{$ht{ORIG_TYPED_CHARS}->{$text_id}};
   # add whitespace?
   my $added_place_marker = "";
   if ($segment_start) {
      unless (($typed_chars[$segment_start] =~ /^\s$/)
           || $this->white_space_left_context_p($orig_segment_start, $text_id, *ht)) {
	 print " " if $stdout_p;
	 print HTML " " if $html_p;
         $added_place_marker = "*";
      }
   }
   my $inter_token_segment_text = join("", @s_chars[$segment_start .. ($segment_end - 1)]);
   $inter_token_segment_text = $this->delete_ignorable_characters($inter_token_segment_text);
   $g_inter_token_segment_text = $this->guard_html($inter_token_segment_text);
   print LOG "write_inter_token_segment $text_id $inter_token_segment_text -> $g_inter_token_segment_text ($segment_start-$segment_end) $added_place_marker\n" if $added_place_marker && $verbose;
   print $inter_token_segment_text if $stdout_p;
   print HTML $this->guard_html($inter_token_segment_text) if $html_p;
}

sub report_interesting_cases {
   local($this,*ht, *LOG, $verbose) = @_;

   if ($verbose) {
      print LOG "Report of interesting cases\n";
      foreach $report_class (("FILENAME_REJECT", "MNAME_ACCEPT", "MNAME_REJECT", "S_WORD_ACCEPT", "S_WORD_REJECT", "URL_ACCEPT", "URL_REJECT", "URL_SUSP_SPAN", "URL_SUSP_TYPE", "PUNCT_CLUSTER_ACCEPT", "IPA_ACCEPT", "IPA_SUSPICIOUS", "IPA_REJECT", "ABBREV_ACCEPT", "ABBREV_REJECT", "IGNORE_REJECT")) {
         print LOG "  $report_class:\n";
	 my $report_class_count_kw = $report_class . "_COUNT";
	 my $report_class_text_id_kw = $report_class . "_TEXT_ID";
         foreach $mname (sort { ($ht{$report_class_count_kw}->{$b} <=> $ht{$report_class_count_kw}->{$a})
                             || ($a cmp $b) }
                              keys %{$ht{$report_class_count_kw}}) {
            my $count = $ht{$report_class_count_kw}->{$mname};
	    unless (($report_class eq "MNAME_REJECT")
	         && ($count <= 2)
		 && ($mname =~ /^([A-Za-z][a-z]{2,}(?:-[A-Za-z][a-z]{2,})*)$/)) {
               my @text_ids = sort keys %{$ht{$report_class_text_id_kw}->{$mname}};
	       print LOG "    $mname ($count) @text_ids\n";
	    }
         }
      }
   }
}

1;
